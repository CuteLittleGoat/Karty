# Kolumny — aktualny układ

## Moduł Second — Tournament of Poker

### Lista graczy
1. Status
2. Nazwa
3. PIN
4. Uprawnienia
5. Akcje

### Losowanie stołów
1. Gracz
2. Status
3. Stół

Dodatkowo dla każdego stołu:
- Gracz
- BUY-IN (tylko odczyt, wartość z sekcji Lista graczy)

### Wpłaty
- Tabela10: Buy-in, REBUY/ADD-ON, SUMA, licz. REBUY/ADD-ON
- Tabela11: %, Rake, BUY-IN, REBUY/ADD-ON, POT
- Tabela12: LP, Stół, Gracz, BUY-IN, REBUY

### Podział puli
- Tabela13: BUY-IN, REBUY/ADD-ON, SUMA, LICZBA REBUY
- Tabela14: %, Rake, BUY-IN, REBUY/ADD-ON, POT
- Tabela15: BUY-IN, PODZIAŁ
- Tabela16: LP, PODZIAŁ PULI, KWOTA, REBUY1..n, MOD1..MOD3, SUMA

### Faza grupowa
- Tabela17: STACK GRACZA, REBUY/ADD-on(w żetonach na os)
- Tabela18: Stoły dynamiczne + ŁĄCZNY STACK
- Tabela19: LP, Stół, Gracz, ELIMINATED, Stack, REBUY/ADD-ON
- Tabela19A: LP, WYELIMINOWANI GRACZE, POZYCJA, WYGRANA
- Tabela19B: LP, Stół, Gracz, Stack, %

### Półfinał
- Tabela21: LP, Gracz, STACK, %, Stół
- Tabela22: LP, Gracz, Stack, Eliminated, %
- Tabela Finałowa: LP, GRACZ, STACK, STÓŁ, %

- Tabela21: `STACK` jest readonly i ma szerokość jak `STACK` w Tabeli Finałowej.
- Tabela Finałowa: `STACK` jest edytowalny (tylko cyfry), domyślna wartość `0`.
- Tabela23: `STACK` synchronizowany 1:1 z `Tabela Finałowa.STACK`.

### Finał
- Tabela23: LP, GRACZ, STACK, %, Eliminated

### Wypłaty
- Tabela24: MIEJSCE, GRACZ, POCZĄTKOWA WYGRANA, KOŃCOWA WYGRANA


### Szerokości kolumn (Lista graczy)
- Kolumna `Nazwa` (2): `min-width: 30ch`.
- Kolumna `PIN` (3): `min-width: 14ch` (zwiększona szerokość dla 5-cyfrowego PIN).
- Kolumna `Uprawnienia` (4): `min-width: 28ch`.
- Kolumna `Akcje` (5): `min-width: 8ch`, wyrównanie do prawej.

### Losowanie stołów — kolumna Status
- Kolumna `Status` zawiera wyłącznie etykietę statusu płatności (układ w `.payment-status-cell`, bez przycisku zmiany).
- Zmiana statusu następuje w sekcji `Lista graczy` przez zaznaczenie/odznaczenie okrągłej kontrolki w kolumnie `Status`.

## Moduł Main — Ranking (Gry admina i Statystyki)
1. Miejsce
2. Gracz
3. Wynik

### Szerokości i zachowanie kolumn (Ranking Main)
- `Miejsce`: stała szerokość `8ch`.
- `Gracz`: stała szerokość `13ch`; nagłówek i wartości są wyrównane do lewej, a nazwy są obcinane wielokropkiem (`ellipsis`), aby cała tabela rankingu mieściła się w panelu bez poziomego przewijania.
- `Wynik`: stała szerokość `6.5ch`, wyrównanie do środka.
- Tabela używa `table-layout: fixed` i `width: 100%`.

### Układ paneli Statystyk (widok gracza, desktop)
- W `Statystyki` (widok gracza) siatka ma trzy kolumny: `Lata` (`20ch`), `Statystyki` (`minmax(0, 1fr)`) i `Ranking` (`34ch`).
- Dzięki temu panel `Ranking` jest po prawej stronie tabel statystyk na desktopie.
- W mobile (`max-width: 720px`) układ przechodzi na jedną kolumnę i panel `Ranking` wraca pod tabelę statystyk.
- Dodatkowo na telefonach w poziomie (`orientation: landscape` + urządzenie dotykowe + `max-height: 500px`) layout także przechodzi na jedną kolumnę, aby panele nie były ustawione obok siebie.


### Losowanie stołów — akcje w bloku stołu
- Przycisk `Usuń` w pojedynczym bloku stołu ma kompaktową szerokość (`.admin-row-delete`) i wyrównanie do prawej krawędzi (`.draw-table-delete`).

## Tournament of Poker (Second) – kolumny
- Panel `Losowanie stołów`: kolumna `Wpisowe` została zastąpiona przez `BUY-IN`.
- Panel `Wpłaty`:
  - `Tabela10`: nieedytowalne komórki obliczane (`BUY-IN`, `REBUY/ADD-ON`, `SUMA`, `LICZ. REBUY/ADD-ON`).
  - `Tabela11`: nieedytowalne komórki obliczane (`%`, `RAKE`, `BUY-IN`, `REBUY/ADD-ON`, `POT`), gdzie `RAKE` liczy się z sumy `BUY-IN + REBUY`.
  - `Tabela12`: kolejność kolumn `LP`, `STÓŁ`, `GRACZ`, `BUY-IN`, `REBUY`; kolumna `REBUY` jako przycisk otwierający modal.
- Panel `Podział puli`:
  - przyciski `Dodaj/Usuń` są pod `Tabela16`,
  - `Tabela15` pokazuje kolumny `BUY-IN` i `PODZIAŁ`, gdzie `BUY-IN` jest kopiowany z `Tabela14.BUY-IN`,
  - `Tabela16` ma `PODZIAŁ PULI` (wiersze 1–3 procentowo, od 4 liczbowo),
  - wszystkie kolumny wejściowe `Tabela16` mają szerokość ustawioną pod 4 znaki,
  - liczba kolumn `REBUY` jest dynamiczna i zależy od liczby uzupełnionych pól `Rebuy` w modalach `Rebuy gracza`,
  - `REBUY1..REBUY30` mają stałe przypisanie do wierszy, a przypisane komórki są readonly i pokazują wartości z modali `Rebuy gracza`,
  - kolumny od `REBUY31` wzwyż są puste domyślnie i edytowalne ręcznie przez użytkownika,
  - kolumny `MOD` są dynamiczne (`MOD1`, `MOD2`, `MOD3`) zależnie od liczby kolumn `REBUY`.
- Panel `Faza grupowa`:
  - `Tabela17` tylko 2 kolumny: `STACK GRACZA`, `REBUY/ADD-ON`.
  - `Tabela19` ma kolumny `LP`, `STÓŁ`, `GRACZ`, `ELIMINATED`, `STACK`, `REBUY/ADD-ON`.
  - `Tabela19A` pokazuje wyeliminowanych graczy.
  - `Tabela19B` pokazuje niewyeliminowanych graczy.


### Modal „Rebuy gracza” (Second)
- Kolumny dynamiczne: `Rebuy1..n` (numeracja globalna dla wszystkich wpisów `Tabela12`, niezależnie od aktualnie przypisanych graczy).
- Szerokość każdej kolumny: `8ch` (jak w module Main).

## Main — kolumny nowych tabel kalkulatora
- Zakładka `Organizacja`:
  - `TABELA1`: `KALKULATOR | ORGANIZACJA | POT`.
  - `TABELA2`: `<dynamiczny nagłówek = wartość ORGANIZACJA> | PODZIAŁ | AKCJE`.
  - `TABELA2`: przycisk `Dodaj` jest pod tabelą po lewej, a `Usuń` jest po prawej stronie w każdym wierszu (kolumna `AKCJE`).
- Zakładki `Żetony ...`:
  - `TABELAA`: `NOMINAŁ | SZTUK | STACK | AKCJE`.
  - `TABELAA`: przycisk `Dodaj` jest pod tabelą po lewej, a `Usuń` jest po prawej stronie każdego wiersza w kolumnie `AKCJE`.
  - `TABELAA`: `Łącznie Stack` nie jest osobnym wierszem tabeli — jest prezentowane jako tekst pod tabelą.
  - `TABELAB`: `L.GRACZY | STACK GRACZA | ŁĄCZNY STACK`.
  - `TABELAC`: `POZOSTAŁE ŻETONY | NOMINAŁ | SZTUK | SUMA | DLA WSZYSTKICH W SZT.`.
