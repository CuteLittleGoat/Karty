const PIN_LENGTH = 5;
const PIN_STORAGE_KEY = "nextGamePinVerified";
const CHAT_PIN_STORAGE_KEY = "chatPinVerified";
const CHAT_PLAYER_ID_STORAGE_KEY = "chatPlayerId";
const CONFIRMATIONS_PIN_STORAGE_KEY = "confirmationsPinVerified";
const CONFIRMATIONS_PLAYER_ID_STORAGE_KEY = "confirmationsPlayerId";
const USER_GAMES_PIN_STORAGE_KEY = "userGamesPinVerified";
const USER_GAMES_PLAYER_ID_STORAGE_KEY = "userGamesPlayerId";
const STATISTICS_PIN_STORAGE_KEY = "statisticsPinVerified";
const STATISTICS_PLAYER_ID_STORAGE_KEY = "statisticsPlayerId";
const PLAYER_ZONE_PIN_STORAGE_KEY = "playerZonePinVerified";
const PLAYER_ZONE_PLAYER_ID_STORAGE_KEY = "playerZonePlayerId";
const PLAYER_ACCESS_UPDATED_EVENT = "player-access-updated";
const PLAYER_ACCESS_COLLECTION = "app_settings";
const PLAYER_ACCESS_DOCUMENT = "player_access";
const RULES_DOCUMENT = "rules";
const ADMIN_MESSAGES_COLLECTION = "admin_messages";
const ADMIN_MESSAGES_DOCUMENT = "admin_messages";
const ADMIN_SECURITY_COLLECTION = "admin_security";
const ADMIN_SECURITY_DOCUMENT = "credentials";
const ADMIN_SECURITY_PASSWORD_FIELD = "passwordHash";
const ADMIN_NOTES_COLLECTION = "admin_notes";
const MAIN_ADMIN_NOTES_DOCUMENT = "main";
const RULES_DEFAULT_TEXT = "";
const DEFAULT_GAME_NOTES_TEMPLATE = "Rodzaj gry:\nPrzewidywani gracze:\nStack:\nWpisowe:\nRebuy:\nAdd-on:\nBlindy:\nOrganizacja:\nPodział puli:";
let refreshUserConfirmationsData = async () => {};

const getPreGameNotes = (game) => {
  if (typeof game?.preGameNotes === "string") {
    return game.preGameNotes;
  }
  return "";
};

const getPostGameNotes = (game) => {
  if (typeof game?.postGameNotes === "string") {
    return game.postGameNotes;
  }
  return "";
};

const legacyNotesCleanupInProgress = new Set();

const clearLegacyNotesField = async ({ firebaseApp, db, collectionName, game }) => {
  const hasLegacyNotes = Object.prototype.hasOwnProperty.call(game ?? {}, "notes");
  if (!hasLegacyNotes || !game?.id) {
    return;
  }

  const cleanupKey = `${collectionName}:${game.id}`;
  if (legacyNotesCleanupInProgress.has(cleanupKey)) {
    return;
  }

  legacyNotesCleanupInProgress.add(cleanupKey);
  try {
    await db.collection(collectionName).doc(game.id).update({
      notes: firebaseApp.firestore.FieldValue.delete()
    });
  } catch (error) {
    legacyNotesCleanupInProgress.delete(cleanupKey);
  }
};
const AVAILABLE_PLAYER_TABS = [
  {
    key: "playerZoneTab",
    label: "Strefa Gracza"
  },
  {
    key: "nextGameTab",
    label: "Najbliższa gra"
  },
  {
    key: "chatTab",
    label: "Czat"
  },
  {
    key: "confirmationsTab",
    label: "Gry do potwierdzenia"
  },
  {
    key: "userGamesTab",
    label: "Gry użytkowników"
  },
  {
    key: "statsTab",
    label: "Statystyki"
  },
];


const PLAYER_ZONE_SECTION_PERMISSION_MAP = {
  nextGameTab: "nextGameTab",
  chatTab: "chatTab",
  confirmationsTab: "confirmationsTab",
  userGamesTab: "userGamesTab",
  statsTab: "statsTab"
};

const CHAT_COLLECTION = "chat_messages";
const CHAT_RETENTION_DAYS = 30;

const TABLES_COLLECTION = "Tables";
const GAMES_COLLECTION = "Tables";
const USER_GAMES_COLLECTION = "UserGames";
const GAME_DETAILS_COLLECTION = "rows";
const TABLES_COLLECTION_CONFIG_KEY = "tablesCollection";
const GAMES_COLLECTION_CONFIG_KEY = "gamesCollection";
const GAME_DETAILS_COLLECTION_CONFIG_KEY = "gameDetailsCollection";
const USER_GAMES_COLLECTION_CONFIG_KEY = "userGamesCollection";
const TABLE_ROWS_COLLECTION = "rows";
const GAME_CONFIRMATIONS_COLLECTION = "confirmations";
const ADMIN_GAMES_STATS_COLLECTION = "admin_games_stats";
const DEFAULT_TABLE_META = {
  gameType: "rodzaj gry",
  gameDate: "data"
};
const DEFAULT_GAME_TYPE = "Cashout";
const TABLE_COLUMNS = [
  { key: "playerName", label: "nazwa gracza" },
  { key: "percentAllGames", label: "% z wszystkich gier" },
  { key: "percentPlayedGames", label: "% procent z rozegranych gier" },
  { key: "payouts", label: "wypłaty" },
  { key: "totalGames", label: "suma rozegranych gier" },
  { key: "summary", label: "podsumowanie (+/-)" },
  { key: "deposits", label: "wpłaty" },
  { key: "meetings", label: "ilość spotkań" },
  { key: "points", label: "punkty" },
  { key: "rebuyTotal", label: "suma rebuy" }
];

const STATS_COLUMN_CONFIG = [
  { key: "playerName", label: "Gracz", editable: false, weight: false, value: (row) => row.playerName },
  { key: "championshipCount", label: "Mistrzostwo", editable: false, weight: false, value: (row) => row.championshipCount },
  { key: "weight1", label: "Waga1", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight1", manual?.weight1) },
  { key: "meetingsCount", label: "Ilość Spotkań", editable: false, weight: false, value: (row) => row.meetingsCount },
  { key: "weight2", label: "Waga2", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight2", manual?.weight2) },
  { key: "participationPercent", label: "% udział", editable: false, weight: false, value: (row) => `${row.participationPercent}%` },
  { key: "points", label: "Punkty", editable: false, weight: false, value: (row) => row.pointsSum },
  { key: "weight3", label: "Waga3", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight3", manual?.weight3) },
  { key: "plusMinusSum", label: "(+/-)", editable: false, weight: false, value: (row) => row.plusMinusSum },
  { key: "weight4", label: "Waga4", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight4", manual?.weight4) },
  { key: "payoutSum", label: "Wypłata", editable: false, weight: false, value: (row) => row.payoutSum },
  { key: "weight5", label: "Waga5", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight5", manual?.weight5) },
  { key: "depositsSum", label: "Wpłaty", editable: false, weight: false, value: (row) => row.depositsSum },
  { key: "weight6", label: "Waga6", editable: true, weight: true, value: (row, manual, getDefault) => getDefault("weight6", manual?.weight6) },
  { key: "playedGamesPoolSum", label: "Suma z rozegranych gier", editable: false, weight: false, value: (row) => row.playedGamesPoolSum },
  { key: "percentAllGames", label: "% Rozegranych gier", editable: false, weight: false, value: (row) => `${row.percentAllGames}%` },
  { key: "percentPlayedGames", label: "% Wszystkich gier", editable: false, weight: false, value: (row) => `${row.percentPlayedGames}%` },
  {
    key: "result",
    label: "Wynik",
    editable: false,
    weight: false,
    value: (row, manual, getDefault, getComputedResultValue) => {
      if (typeof getComputedResultValue !== "function") {
        return "";
      }
      return getComputedResultValue(row, manual);
    }
  }
];
const DEFAULT_VISIBLE_STATS_COLUMNS = STATS_COLUMN_CONFIG
  .filter((column) => !column.weight)
  .map((column) => column.key);
const WEIGHT_STATS_FIELDS = ["weight1", "weight2", "weight3", "weight4", "weight5", "weight6"];

const getDefaultStatsManualFieldValue = (field, value) => {
  if (WEIGHT_STATS_FIELDS.includes(field)) {
    const normalized = typeof value === "string" || typeof value === "number" ? String(value).trim() : "";
    return normalized ? normalized : "1";
  }
  return typeof value === "string" || typeof value === "number" ? String(value) : "";
};

const getComputedStatsResultValue = (row, manualEntry = {}, getDefaultManualFieldValue = getDefaultStatsManualFieldValue) => {
  const weight1 = parseIntegerOrZero(getDefaultManualFieldValue("weight1", manualEntry.weight1));
  const weight2 = parseIntegerOrZero(getDefaultManualFieldValue("weight2", manualEntry.weight2));
  const weight3 = parseIntegerOrZero(getDefaultManualFieldValue("weight3", manualEntry.weight3));
  const weight4 = parseIntegerOrZero(getDefaultManualFieldValue("weight4", manualEntry.weight4));
  const weight5 = parseIntegerOrZero(getDefaultManualFieldValue("weight5", manualEntry.weight5));
  const weight6 = parseIntegerOrZero(getDefaultManualFieldValue("weight6", manualEntry.weight6));
  return (row.championshipCount * weight1)
    + (row.participationPercent * weight2)
    + (row.pointsSum * weight3)
    + (row.plusMinusSum * weight4)
    + (row.payoutSum * weight5)
    + (row.depositsSum * weight6);
};

const sortRankingRowsByResult = (rows) => {
  rows.sort((a, b) => {
    if (b.resultValue !== a.resultValue) {
      return b.resultValue - a.resultValue;
    }
    return a.playerName.localeCompare(b.playerName, "pl");
  });
  return rows;
};

const buildRankingRowsFromStatistics = (playerRows, yearMap, getDefaultManualFieldValue = getDefaultStatsManualFieldValue) => {
  return sortRankingRowsByResult(playerRows.map((statsRow) => {
    const statsIdentifier = typeof statsRow?.statsKey === "string" && statsRow.statsKey.trim()
      ? statsRow.statsKey.trim()
      : getRowPlayerIdentifier(statsRow);
    const manualEntry = yearMap.get(statsIdentifier) ?? {};
    return {
      ...statsRow,
      resultValue: getComputedStatsResultValue(statsRow, manualEntry, getDefaultManualFieldValue)
    };
  }));
};

const renderRankingTable = (rankingBody, playerRows) => {
  if (!rankingBody) {
    return;
  }

  rankingBody.innerHTML = "";

  if (!playerRows.length) {
    const emptyRow = document.createElement("tr");
    const emptyCell = document.createElement("td");
    emptyCell.colSpan = 3;
    emptyCell.textContent = "Brak danych rankingowych dla wybranego roku.";
    emptyRow.appendChild(emptyCell);
    rankingBody.appendChild(emptyRow);
    return;
  }

  playerRows.forEach((entry, index) => {
    const rank = index + 1;
    const tr = document.createElement("tr");
    if (rank <= 8) {
      tr.classList.add("admin-games-ranking-row-gold");
    } else if (rank <= 17) {
      tr.classList.add("admin-games-ranking-row-green");
    } else {
      tr.classList.add("admin-games-ranking-row-red");
    }

    const rankCell = document.createElement("td");
    rankCell.textContent = String(rank);
    const playerCell = document.createElement("td");
    playerCell.textContent = entry.playerName;
    const resultCell = document.createElement("td");
    resultCell.textContent = String(entry.resultValue);
    tr.append(rankCell, playerCell, resultCell);
    rankingBody.appendChild(tr);
  });
};

const adminPlayersState = {
  players: [],
  playerByPin: new Map(),
  editingPlayerId: null
};
let sharedPlayerAccessUnsubscribe = null;
const chatState = {
  unsubscribe: null,
  adminUnsubscribe: null,
  startPlayerSubscription: null,
  stopPlayerSubscription: null
};
const nextGamesState = {
  adminGames: [],
  userGames: [],
  adminUnsubscribe: null,
  userUnsubscribe: null,
  db: null,
  syncToken: 0
};
const debounceTimers = new Map();
const adminRefreshHandlers = new Map();
const ADMIN_GAMES_SELECTED_YEAR_STORAGE_KEY = "adminGamesSelectedYear";
const ADMIN_USER_GAMES_SELECTED_YEAR_STORAGE_KEY = "adminUserGamesSelectedYear";
const USER_GAMES_SELECTED_YEAR_STORAGE_KEY = "userGamesSelectedYear";
const ADMIN_STATISTICS_SELECTED_YEAR_STORAGE_KEY = "adminStatisticsSelectedYear";
const USER_STATISTICS_SELECTED_YEAR_STORAGE_KEY = "userStatisticsSelectedYear";

const getDateSortValue = (value) => {
  if (typeof value !== "string") {
    return Number.POSITIVE_INFINITY;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return Number.POSITIVE_INFINITY;
  }

  const directMatch = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (directMatch) {
    const year = Number(directMatch[1]);
    const month = Number(directMatch[2]);
    const day = Number(directMatch[3]);
    const parsed = new Date(year, month - 1, day).getTime();
    return Number.isFinite(parsed) ? parsed : Number.POSITIVE_INFINITY;
  }

  const parsed = Date.parse(trimmed);
  return Number.isFinite(parsed) ? parsed : Number.POSITIVE_INFINITY;
};

const parseDateFromInput = (value) => {
  if (typeof value !== "string") {
    return null;
  }

  const trimmed = value.trim();
  if (!trimmed) {
    return null;
  }

  const isoMatch = trimmed.match(/^(\d{4})-(\d{2})-(\d{2})$/);
  if (isoMatch) {
    const parsedDate = new Date(Number(isoMatch[1]), Number(isoMatch[2]) - 1, Number(isoMatch[3]));
    return Number.isFinite(parsedDate.getTime()) ? parsedDate : null;
  }

  const dotOrDashMatch = trimmed.match(/^(\d{2})[.-](\d{2})[.-](\d{4})$/);
  if (dotOrDashMatch) {
    const parsedDate = new Date(Number(dotOrDashMatch[3]), Number(dotOrDashMatch[2]) - 1, Number(dotOrDashMatch[1]));
    return Number.isFinite(parsedDate.getTime()) ? parsedDate : null;
  }

  const parsed = new Date(trimmed);
  return Number.isFinite(parsed.getTime()) ? parsed : null;
};

const getStatsKey = (entry = {}) => {
  const playerId = typeof entry?.playerId === "string" ? entry.playerId.trim() : "";
  if (playerId) {
    return `id:${playerId}`;
  }
  const playerName = normalizePlayerName(entry?.playerName);
  return playerName ? `name:${playerName}` : "";
};

const normalizePlayerName = (value) => (typeof value === "string" ? value.trim() : "");

const getRowPlayerIdentifier = (row = {}) => {
  const playerId = typeof row?.playerId === "string" ? row.playerId.trim() : "";
  if (playerId) {
    return `id:${playerId}`;
  }
  const playerName = normalizePlayerName(row?.playerName);
  return playerName ? `name:${playerName}` : "";
};

const getSelectedPlayerIdentifiersForRows = (rows, currentRowId) => {
  const selectedPlayers = new Set();
  if (!Array.isArray(rows)) {
    return selectedPlayers;
  }

  rows.forEach((row) => {
    if (!row || row.id === currentRowId) {
      return;
    }
    const playerIdentifier = getRowPlayerIdentifier(row);
    if (playerIdentifier) {
      selectedPlayers.add(playerIdentifier);
    }
  });

  return selectedPlayers;
};

const getAvailablePlayersForRow = (rows, currentRowId, playerOptions, currentIdentifier = "") => {
  const selectedPlayers = getSelectedPlayerIdentifiersForRows(rows, currentRowId);
  return playerOptions.filter((player) => {
    const playerId = typeof player?.id === "string" ? player.id.trim() : "";
    const playerName = normalizePlayerName(player?.name);
    const playerIdentifier = playerId ? `id:${playerId}` : (playerName ? `name:${playerName}` : "");
    if (!playerIdentifier) {
      return false;
    }
    return playerIdentifier === currentIdentifier || !selectedPlayers.has(playerIdentifier);
  });
};

const getAvailablePlayerNamesForRow = (rows, currentRowId, playerOptions, currentPlayerName = "") => {
  const normalizedOptions = Array.isArray(playerOptions)
    ? playerOptions.map((name) => ({ id: "", name }))
    : [];
  const currentIdentifier = currentPlayerName ? `name:${currentPlayerName}` : "";
  return getAvailablePlayersForRow(rows, currentRowId, normalizedOptions, currentIdentifier)
    .map((player) => normalizePlayerName(player.name))
    .filter(Boolean);
};

const compareByGameDateAsc = (a, b) => {
  const dateDiff = getDateSortValue(a?.gameDate) - getDateSortValue(b?.gameDate);
  if (dateDiff !== 0) {
    return dateDiff;
  }

  const createdA = a?.createdAt?.toMillis?.() ?? 0;
  const createdB = b?.createdAt?.toMillis?.() ?? 0;
  if (createdA !== createdB) {
    return createdA - createdB;
  }

  return String(a?.name ?? "").localeCompare(String(b?.name ?? ""), "pl");
};

const isFocusableFormControl = (element) => {
  return element instanceof HTMLInputElement
    || element instanceof HTMLSelectElement
    || element instanceof HTMLTextAreaElement;
};

const supportsSelectionRange = (element) => {
  if (element instanceof HTMLTextAreaElement) {
    return true;
  }

  if (!(element instanceof HTMLInputElement)) {
    return false;
  }

  const selectableTypes = new Set(["text", "search", "url", "tel", "password", "email", "number"]);
  return selectableTypes.has(element.type);
};

const getFocusedAdminInputState = (container) => {
  if (!container) {
    return null;
  }

  const activeElement = document.activeElement;
  if (!isFocusableFormControl(activeElement) || !container.contains(activeElement)) {
    return null;
  }

  const safeSelectionStart = supportsSelectionRange(activeElement) ? activeElement.selectionStart : null;
  const safeSelectionEnd = supportsSelectionRange(activeElement) ? activeElement.selectionEnd : null;

  return {
    target: activeElement.dataset.focusTarget ?? "",
    tableId: activeElement.dataset.tableId ?? "",
    rowId: activeElement.dataset.rowId ?? "",
    columnKey: activeElement.dataset.columnKey ?? "",
    section: activeElement.dataset.section ?? "",
    selectionStart: safeSelectionStart,
    selectionEnd: safeSelectionEnd
  };
};

const restoreFocusedAdminInputState = (container, focusState) => {
  if (!container || !focusState) {
    return;
  }

  const targetInput = Array.from(container.querySelectorAll("[data-focus-target]"))
    .find((input) => {
      return (
        input.dataset.focusTarget === focusState.target
        && (input.dataset.tableId ?? "") === focusState.tableId
        && (input.dataset.rowId ?? "") === focusState.rowId
        && (input.dataset.columnKey ?? "") === focusState.columnKey
        && (input.dataset.section ?? "") === focusState.section
      );
    });

  if (!targetInput) {
    return;
  }

  targetInput.focus();
  if (supportsSelectionRange(targetInput)
    && typeof focusState.selectionStart === "number"
    && typeof focusState.selectionEnd === "number") {
    targetInput.setSelectionRange(focusState.selectionStart, focusState.selectionEnd);
  }
};

const comparePlayerStatsByPlusMinusDesc = (a, b) => {
  const plusMinusDiff = Number(b?.plusMinusSum ?? 0) - Number(a?.plusMinusSum ?? 0);
  if (plusMinusDiff !== 0) {
    return plusMinusDiff;
  }
  return String(a?.playerName ?? "").localeCompare(String(b?.playerName ?? ""), "pl");
};

const NOTES_COLOR_MAP = {
  gold: "var(--gold)",
  green: "var(--neon)",
  red: "var(--ruby2)",
  white: "var(--ink)"
};

const sanitizeRichTextWithAllowedColors = (rawHtml, allowedColorMap) => {
  if (typeof rawHtml !== "string" || !rawHtml.trim()) {
    return "";
  }

  const parser = new DOMParser();
  const documentFragment = parser.parseFromString(`<div>${rawHtml}</div>`, "text/html");
  const root = documentFragment.body.firstElementChild;
  if (!root) {
    return "";
  }

  const allowedColors = new Set(Object.values(allowedColorMap));
  const cleanNode = (node) => {
    if (node.nodeType === Node.TEXT_NODE) {
      return document.createTextNode(node.textContent ?? "");
    }

    if (node.nodeType !== Node.ELEMENT_NODE) {
      return null;
    }

    const tag = node.tagName.toLowerCase();
    if (tag === "br") {
      return document.createElement("br");
    }

    if (tag === "span") {
      const next = document.createElement("span");
      const colorValue = (node.style.color || "").trim();
      if (allowedColors.has(colorValue)) {
        next.style.color = colorValue;
      }
      Array.from(node.childNodes).forEach((child) => {
        const cleaned = cleanNode(child);
        if (cleaned) {
          next.appendChild(cleaned);
        }
      });
      return next;
    }

    const fragment = document.createDocumentFragment();
    Array.from(node.childNodes).forEach((child) => {
      const cleaned = cleanNode(child);
      if (cleaned) {
        fragment.appendChild(cleaned);
      }
    });
    return fragment;
  };

  const output = document.createElement("div");
  Array.from(root.childNodes).forEach((child) => {
    const cleaned = cleanNode(child);
    if (cleaned) {
      output.appendChild(cleaned);
    }
  });

  return output.innerHTML;
};

const getSummaryNotesModalController = (() => {
  let cachedController = null;

  return () => {
    if (cachedController) {
      return cachedController;
    }

    const modal = document.querySelector("#summaryNotesModal");
    const title = document.querySelector("#summaryNotesTitle");
    const editor = document.querySelector("#summaryNotesInput");
    const status = document.querySelector("#summaryNotesStatus");
    const saveButton = document.querySelector("#summaryNotesSave");
    const clearButton = document.querySelector("#summaryNotesClear");
    const closeButton = document.querySelector("#summaryNotesClose");
    const colorActions = document.querySelector(".summary-notes-color-actions");
    const colorButtons = document.querySelectorAll("[data-notes-color]");

    if (!modal || !title || !editor || !status || !saveButton || !clearButton || !closeButton) {
      cachedController = {
        open: () => {}
      };
      return cachedController;
    }

    const state = {
      gameId: "",
      gameName: "",
      notes: "",
      notesLabel: "Notatki",
      canWrite: false,
      onSave: null,
      triggerButton: null,
      clearButtonLabel: "Usuń",
      clearToDefault: false,
      readOnlyMessage: "Brak uprawnień do edycji notatek.",
      textareaPlaceholder: "Wpisz notatki..."
    };
    let lastSelectionRange = null;

    const rememberEditorSelection = () => {
      const selection = window.getSelection();
      if (!selection || selection.rangeCount === 0) {
        return;
      }
      const range = selection.getRangeAt(0);
      if (!editor.contains(range.commonAncestorContainer)) {
        return;
      }
      lastSelectionRange = range.cloneRange();
    };

    const applyColor = (colorKey) => {
      if (!state.canWrite) {
        status.textContent = state.readOnlyMessage;
        return;
      }

      const selectedColor = NOTES_COLOR_MAP[colorKey];
      const selection = window.getSelection();
      if (!selectedColor || !selection) {
        status.textContent = "Zaznacz fragment tekstu, a potem wybierz kolor.";
        return;
      }

      if ((selection.rangeCount === 0 || selection.isCollapsed) && lastSelectionRange) {
        selection.removeAllRanges();
        selection.addRange(lastSelectionRange.cloneRange());
      }

      if (selection.rangeCount === 0 || selection.isCollapsed) {
        status.textContent = "Zaznacz fragment tekstu, a potem wybierz kolor.";
        return;
      }

      const range = selection.getRangeAt(0);
      if (!editor.contains(range.commonAncestorContainer)) {
        status.textContent = "Kolor możesz nadać tylko tekstowi notatek.";
        return;
      }

      const fragment = range.extractContents();
      const span = document.createElement("span");
      span.style.color = selectedColor;
      span.appendChild(fragment);
      range.insertNode(span);
      selection.removeAllRanges();

      const normalized = sanitizeRichTextWithAllowedColors(editor.innerHTML, NOTES_COLOR_MAP);
      editor.innerHTML = normalized;
      lastSelectionRange = null;
      status.textContent = "Kolor zastosowany. Kliknij Zapisz, aby utrwalić zmiany.";
    };

    const closeModal = () => {
      modal.classList.remove("is-visible");
      modal.setAttribute("aria-hidden", "true");
      document.body.classList.remove("modal-open");
      if (state.triggerButton instanceof HTMLElement) {
        state.triggerButton.focus();
      }
      state.triggerButton = null;
    };

    const open = ({
      gameId,
      gameName,
      notes,
      canWrite,
      onSave,
      triggerButton,
      notesLabel,
      clearButtonLabel,
      clearToDefault,
      readOnlyMessage,
      textareaPlaceholder
    }) => {
      state.gameId = String(gameId ?? "");
      state.gameName = String(gameName ?? "Bez nazwy");
      const rawNotes = typeof notes === "string" ? notes : "";
      const normalizedNotes = sanitizeRichTextWithAllowedColors(rawNotes, NOTES_COLOR_MAP);
      state.notes = normalizedNotes;
      state.notesLabel = String(notesLabel ?? "Notatki");
      state.canWrite = Boolean(canWrite);
      state.onSave = typeof onSave === "function" ? onSave : null;
      state.triggerButton = triggerButton instanceof HTMLElement ? triggerButton : null;
      state.clearButtonLabel = String(clearButtonLabel ?? "Usuń");
      state.clearToDefault = Boolean(clearToDefault);
      state.readOnlyMessage = String(readOnlyMessage ?? "Brak uprawnień do edycji notatek.");
      state.textareaPlaceholder = String(textareaPlaceholder ?? "Wpisz notatki...");

      title.textContent = `${state.notesLabel}: ${state.gameName}`;
      editor.innerHTML = state.notes;
      lastSelectionRange = null;
      editor.dataset.placeholder = state.textareaPlaceholder;
      editor.contentEditable = state.canWrite ? "true" : "false";
      editor.setAttribute("aria-readonly", state.canWrite ? "false" : "true");
      editor.classList.toggle("is-readonly", !state.canWrite);
      saveButton.disabled = !state.canWrite;
      clearButton.disabled = !state.canWrite;
      saveButton.hidden = !state.canWrite;
      clearButton.hidden = !state.canWrite;
      clearButton.textContent = state.clearButtonLabel;
      if (colorActions) {
        colorActions.hidden = !state.canWrite;
      }
      status.textContent = state.canWrite ? "" : state.readOnlyMessage;

      modal.classList.add("is-visible");
      modal.setAttribute("aria-hidden", "false");
      document.body.classList.add("modal-open");
      editor.focus();
    };

    const persist = async (value) => {
      if (!state.canWrite || !state.onSave) {
        return;
      }
      saveButton.disabled = true;
      clearButton.disabled = true;
      status.textContent = "Zapisywanie...";
      try {
        await state.onSave({ gameId: state.gameId, notes: value });
        state.notes = value;
        editor.innerHTML = value;
        status.textContent = "Notatki zapisane.";
      } catch (error) {
        status.textContent = "Nie udało się zapisać notatek.";
      } finally {
        saveButton.disabled = !state.canWrite;
        clearButton.disabled = !state.canWrite;
      }
    };

    saveButton.addEventListener("click", () => {
      const normalizedValue = sanitizeRichTextWithAllowedColors(editor.innerHTML, NOTES_COLOR_MAP);
      editor.innerHTML = normalizedValue;
      void persist(normalizedValue);
    });

    clearButton.addEventListener("click", () => {
      const nextValue = state.clearToDefault
        ? sanitizeRichTextWithAllowedColors(DEFAULT_GAME_NOTES_TEMPLATE, NOTES_COLOR_MAP)
        : "";
      void persist(nextValue);
    });

    colorButtons.forEach((button) => {
      button.addEventListener("mousedown", (event) => {
        event.preventDefault();
      });
      button.addEventListener("click", () => {
        applyColor(button.dataset.notesColor);
      });
    });

    editor.addEventListener("mouseup", rememberEditorSelection);
    editor.addEventListener("keyup", rememberEditorSelection);

    closeButton.addEventListener("click", closeModal);
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        closeModal();
      }
    });

    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && modal.classList.contains("is-visible")) {
        closeModal();
      }
    });

    cachedController = { open };
    return cachedController;
  };
})();

const registerAdminRefreshHandler = (tabId, handler) => {
  if (!tabId || typeof handler !== "function") {
    return;
  }
  adminRefreshHandlers.set(tabId, handler);
};

const getRuntimeMode = () => {
  const params = new URLSearchParams(window.location.search);
  const isPwaLaunch = params.get("pwa") === "1";
  const isUserView = params.get("view") === "user";
  return {
    isPwaLaunch,
    isUserView,
    isPwaUserOnly: isPwaLaunch && isUserView
  };
};

const getAdminMode = () => {
  const params = new URLSearchParams(window.location.search);
  if (getRuntimeMode().isPwaUserOnly) {
    return false;
  }
  return params.get("admin") === "1";
};

const TEMPORARILY_DISABLE_ADMIN_PASSWORD = false;

const getAdminPasswordHash = async () => {
  const firebaseApp = getFirebaseApp();
  if (!firebaseApp?.firestore) {
    throw new Error("FIREBASE_UNAVAILABLE");
  }

  const db = firebaseApp.firestore();
  const snapshot = await db
    .collection(ADMIN_SECURITY_COLLECTION)
    .doc(ADMIN_SECURITY_DOCUMENT)
    .get();

  const storedHash = snapshot.get(ADMIN_SECURITY_PASSWORD_FIELD);
  if (typeof storedHash !== "string" || !storedHash.trim()) {
    throw new Error("PASSWORD_NOT_CONFIGURED");
  }

  return storedHash.trim();
};

const getSha256Hex = async (value) => {
  if (!window.crypto?.subtle || typeof window.TextEncoder !== "function") {
    return "";
  }
  const encoder = new TextEncoder();
  const bytes = encoder.encode(value);
  const digest = await window.crypto.subtle.digest("SHA-256", bytes);
  return Array.from(new Uint8Array(digest))
    .map((byte) => byte.toString(16).padStart(2, "0"))
    .join("");
};

const isAdminPasswordValid = async (candidatePassword, storedHash) => {
  if (candidatePassword === storedHash) {
    return true;
  }
  const sha256Hex = await getSha256Hex(candidatePassword);
  if (!sha256Hex) {
    return false;
  }
  return sha256Hex === storedHash.toLowerCase();
};

const requestAdminPassword = ({ errorMessage = "" } = {}) => new Promise((resolve) => {
  const overlay = document.createElement("div");
  overlay.style.position = "fixed";
  overlay.style.inset = "0";
  overlay.style.background = "rgba(4, 9, 22, 0.82)";
  overlay.style.display = "flex";
  overlay.style.alignItems = "center";
  overlay.style.justifyContent = "center";
  overlay.style.padding = "20px";
  overlay.style.zIndex = "9999";

  const dialog = document.createElement("div");
  dialog.style.width = "min(460px, 100%)";
  dialog.style.background = "#1f2430";
  dialog.style.border = "1px solid rgba(255, 255, 255, 0.16)";
  dialog.style.borderRadius = "16px";
  dialog.style.padding = "20px";
  dialog.style.boxSizing = "border-box";

  const title = document.createElement("h2");
  title.textContent = "Tryb administratora";
  title.style.margin = "0 0 12px";
  title.style.color = "#ffffff";
  title.style.fontSize = "1.2rem";

  const description = document.createElement("p");
  description.textContent = "Podaj hasło administratora, aby otworzyć panel.";
  description.style.margin = "0 0 14px";
  description.style.color = "rgba(255, 255, 255, 0.84)";

  const input = document.createElement("input");
  input.type = "password";
  input.placeholder = "Hasło administratora";
  input.autocomplete = "current-password";
  input.dataset.focusTarget = "true";
  input.dataset.section = "admin-auth";
  input.dataset.columnKey = "password";
  input.style.width = "100%";
  input.style.padding = "11px 12px";
  input.style.borderRadius = "10px";
  input.style.border = "1px solid rgba(255, 255, 255, 0.22)";
  input.style.background = "rgba(8, 12, 22, 0.88)";
  input.style.color = "#ffffff";
  input.style.fontSize = "1rem";
  input.style.boxSizing = "border-box";

  const errorText = document.createElement("p");
  errorText.textContent = errorMessage;
  errorText.style.margin = "10px 0 0";
  errorText.style.minHeight = "1.2em";
  errorText.style.color = "#ff8585";

  const actions = document.createElement("div");
  actions.style.display = "flex";
  actions.style.justifyContent = "flex-end";
  actions.style.gap = "10px";
  actions.style.marginTop = "18px";

  const cancelButton = document.createElement("button");
  cancelButton.type = "button";
  cancelButton.textContent = "Anuluj";
  cancelButton.style.padding = "9px 14px";

  const submitButton = document.createElement("button");
  submitButton.type = "button";
  submitButton.textContent = "Zaloguj";
  submitButton.style.padding = "9px 14px";

  const cleanup = (value) => {
    document.removeEventListener("keydown", onEscape);
    overlay.remove();
    resolve(value);
  };

  const onEscape = (event) => {
    if (event.key === "Escape") {
      cleanup(null);
    }
  };

  cancelButton.addEventListener("click", () => cleanup(null));
  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) {
      cleanup(null);
    }
  });

  submitButton.addEventListener("click", () => {
    const value = input.value.trim();
    if (!value) {
      errorText.textContent = "Pole hasła nie może być puste.";
      input.focus();
      return;
    }
    cleanup(value);
  });

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      event.preventDefault();
      submitButton.click();
    }
  });

  actions.append(cancelButton, submitButton);
  dialog.append(title, description, input, errorText, actions);
  overlay.appendChild(dialog);
  document.body.appendChild(overlay);
  document.addEventListener("keydown", onEscape);
  input.focus();
});

const resolveAdminMode = async () => {
  if (!getAdminMode()) {
    return false;
  }

  if (TEMPORARILY_DISABLE_ADMIN_PASSWORD) {
    return true;
  }

  const getFallbackCredential = () => {
    const fallbackCredential = typeof window.firebaseConfig?.adminPasswordHash === "string"
      ? window.firebaseConfig.adminPasswordHash.trim()
      : "";
    const fallbackPassword = typeof window.firebaseConfig?.adminPassword === "string"
      ? window.firebaseConfig.adminPassword.trim()
      : "";
    return fallbackCredential || fallbackPassword;
  };

  const loadStoredHash = async () => {
    try {
      return await getAdminPasswordHash();
    } catch (error) {
      return getFallbackCredential();
    }
  };

  let storedHash = await loadStoredHash();
  let modalError = "";

  while (true) {
    const candidatePassword = await requestAdminPassword({ errorMessage: modalError });
    if (candidatePassword === null) {
      return false;
    }

    if (!storedHash) {
      storedHash = await loadStoredHash();
      if (!storedHash) {
        modalError = "Nie udało się odczytać hasła administratora. Sprawdź konfigurację i spróbuj ponownie.";
        continue;
      }
    }

    const isValid = await isAdminPasswordValid(candidatePassword, storedHash);
    if (isValid) {
      return true;
    }

    modalError = "Błędne hasło administratora. Spróbuj ponownie.";
  }
};

const LAST_DOCUMENT_DELETE_ERROR_CODE = "LAST_DOCUMENT_DELETE_BLOCKED";

const createLastDocumentDeleteError = () => {
  const error = new Error("Nie można usunąć ostatniego dokumentu z kolekcji.");
  error.code = LAST_DOCUMENT_DELETE_ERROR_CODE;
  return error;
};

const notifyLastDocumentDeleteBlocked = () => {
  window.alert("Nie można usunąć ostatniego dokumentu z kolekcji. Dodaj nowy rekord przed usunięciem obecnego.");
};

const isCollectionProtectedAgainstFullDeletion = (collectionRef) => {
  const collectionPath = collectionRef?.path;
  if (typeof collectionPath !== "string" || !collectionPath.trim()) {
    return false;
  }

  return !collectionPath.includes("/");
};

const isRemovingLastDocument = async ({ collectionRef, candidateDocRefs }) => {
  if (!collectionRef || !Array.isArray(candidateDocRefs) || !candidateDocRefs.length) {
    return false;
  }

  if (!isCollectionProtectedAgainstFullDeletion(collectionRef)) {
    return false;
  }

  const uniqueRefs = [];
  const uniqueKeys = new Set();
  candidateDocRefs.forEach((docRef) => {
    if (!docRef?.id) {
      return;
    }
    const key = `${docRef.parent?.path ?? ""}/${docRef.id}`;
    if (uniqueKeys.has(key)) {
      return;
    }
    uniqueKeys.add(key);
    uniqueRefs.push(docRef);
  });

  if (!uniqueRefs.length) {
    return false;
  }

  const probeSnapshot = await collectionRef.limit(uniqueRefs.length + 1).get();
  if (probeSnapshot.empty || probeSnapshot.size > uniqueRefs.length) {
    return false;
  }

  const sampledIds = new Set(probeSnapshot.docs.map((doc) => doc.id));
  const deletionsInSample = uniqueRefs.filter((docRef) => sampledIds.has(docRef.id));
  return deletionsInSample.length === probeSnapshot.size;
};

const installFirestoreDeleteProtection = (firebaseApp) => {
  if (!firebaseApp?.firestore || firebaseApp.__kartyDeleteProtectionInstalled) {
    return;
  }

  const db = firebaseApp.firestore();
  const testDocRef = db.collection("__karty_delete_protection__").doc("__guard__");

  const documentReferencePrototype = Object.getPrototypeOf(testDocRef);
  if (documentReferencePrototype && typeof documentReferencePrototype.delete === "function" && !documentReferencePrototype.__kartyDeleteProtectionPatched) {
    const originalDelete = documentReferencePrototype.delete;
    documentReferencePrototype.delete = async function patchedDelete(...args) {
      const shouldBlock = await isRemovingLastDocument({
        collectionRef: this.parent,
        candidateDocRefs: [this]
      });

      if (shouldBlock) {
        notifyLastDocumentDeleteBlocked();
        throw createLastDocumentDeleteError();
      }

      return originalDelete.apply(this, args);
    };
    documentReferencePrototype.__kartyDeleteProtectionPatched = true;
  }

  const writeBatchPrototype = Object.getPrototypeOf(db.batch());
  if (writeBatchPrototype && typeof writeBatchPrototype.delete === "function" && typeof writeBatchPrototype.commit === "function" && !writeBatchPrototype.__kartyDeleteProtectionPatched) {
    const originalBatchDelete = writeBatchPrototype.delete;
    const originalBatchCommit = writeBatchPrototype.commit;

    writeBatchPrototype.delete = function patchedBatchDelete(docRef, ...args) {
      if (!this.__kartyPendingDeleteRefs) {
        this.__kartyPendingDeleteRefs = [];
      }
      this.__kartyPendingDeleteRefs.push(docRef);
      return originalBatchDelete.call(this, docRef, ...args);
    };

    writeBatchPrototype.commit = async function patchedBatchCommit(...args) {
      const pendingDeleteRefs = Array.isArray(this.__kartyPendingDeleteRefs) ? this.__kartyPendingDeleteRefs : [];

      if (pendingDeleteRefs.length) {
        const refsByCollectionPath = new Map();
        pendingDeleteRefs.forEach((docRef) => {
          if (!docRef?.parent?.path) {
            return;
          }
          if (!isCollectionProtectedAgainstFullDeletion(docRef.parent)) {
            return;
          }
          if (!refsByCollectionPath.has(docRef.parent.path)) {
            refsByCollectionPath.set(docRef.parent.path, {
              collectionRef: docRef.parent,
              docRefs: []
            });
          }
          refsByCollectionPath.get(docRef.parent.path).docRefs.push(docRef);
        });

        for (const { collectionRef, docRefs } of refsByCollectionPath.values()) {
          const shouldBlock = await isRemovingLastDocument({ collectionRef, candidateDocRefs: docRefs });
          if (shouldBlock) {
            notifyLastDocumentDeleteBlocked();
            throw createLastDocumentDeleteError();
          }
        }
      }

      this.__kartyPendingDeleteRefs = [];
      return originalBatchCommit.apply(this, args);
    };

    writeBatchPrototype.__kartyDeleteProtectionPatched = true;
  }

  firebaseApp.__kartyDeleteProtectionInstalled = true;
};


const getFirebaseApp = () => {
  if (!window.firebase || !window.firebase.initializeApp) {
    return null;
  }

  if (!window.firebaseConfig || !window.firebaseConfig.projectId) {
    return null;
  }

  if (!window.firebase.apps.length) {
    window.firebase.initializeApp(window.firebaseConfig);
  }

  installFirestoreDeleteProtection(window.firebase);

  return window.firebase;
};

const parseDefaultTableNumber = (name) => {
  if (!name || typeof name !== "string") {
    return null;
  }
  const match = name.trim().match(/^Gra\s+(\d+)$/i);
  if (!match) {
    return null;
  }
  const numberValue = Number(match[1]);
  return Number.isInteger(numberValue) ? numberValue : null;
};

const getNextTableName = (tables) => {
  const usedNumbers = new Set();
  tables.forEach((table) => {
    const numberValue = parseDefaultTableNumber(table.name);
    if (numberValue) {
      usedNumbers.add(numberValue);
    }
  });

  let candidate = 1;
  while (usedNumbers.has(candidate)) {
    candidate += 1;
  }
  return `Gra ${candidate}`;
};

const getFormattedCurrentDate = () => {
  const now = new Date();
  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, "0");
  const day = String(now.getDate()).padStart(2, "0");
  return `${year}-${month}-${day}`;
};

const applyIntegerInputHints = (input) => {
  if (!(input instanceof HTMLInputElement)) {
    return;
  }
  input.type = "text";
  input.inputMode = "numeric";
  input.pattern = "[0-9]*";
  input.autocomplete = "off";
};

const sanitizeIntegerInput = (value) => {
  if (typeof value !== "string") {
    return "";
  }
  const normalized = value.replace(/\s+/g, "").replace(/,/g, "");
  const withoutMinus = normalized.replace(/-/g, "");
  if (!withoutMinus.length) {
    return normalized.startsWith("-") ? "-" : "";
  }
  const digits = withoutMinus.replace(/\D/g, "");
  if (!digits.length) {
    return normalized.startsWith("-") ? "-" : "";
  }
  return normalized.startsWith("-") ? `-${digits}` : digits;
};

const parseIntegerOrZero = (value) => {
  const normalized = sanitizeIntegerInput(typeof value === "number" ? `${value}` : value ?? "");
  if (!normalized || normalized === "-") {
    return 0;
  }
  const parsed = Number.parseInt(normalized, 10);
  return Number.isFinite(parsed) ? parsed : 0;
};

const getNextGameNameForDate = (games, gameDate) => {
  const sameDayGames = games.filter((game) => (game.gameDate ?? "") === gameDate);
  return getNextTableName(sameDayGames);
};

const getValidatedNewGamePayload = ({ games, additionalPayload = {} }) => {
  const gameType = DEFAULT_GAME_TYPE;
  const gameDate = getFormattedCurrentDate();
  const name = getNextGameNameForDate(games, gameDate);

  const hasMissingRequiredField = [gameType, gameDate, name]
    .some((value) => typeof value !== "string" || !value.trim());

  if (hasMissingRequiredField) {
    return null;
  }

  return {
    gameType,
    gameDate,
    name,
    ...additionalPayload
  };
};

const deleteCollectionDocuments = async (collectionRef) => {
  let snapshot = await collectionRef.limit(250).get();
  while (!snapshot.empty) {
    const batch = collectionRef.firestore.batch();
    snapshot.docs.forEach((doc) => {
      batch.delete(doc.ref);
    });
    await batch.commit();
    snapshot = await collectionRef.limit(250).get();
  }
};

const deleteGameCompletely = async ({ db, collectionName, gameId }) => {
  const gameRef = db.collection(collectionName).doc(gameId);
  await deleteCollectionDocuments(gameRef.collection(GAME_DETAILS_COLLECTION));
  await deleteCollectionDocuments(gameRef.collection(GAME_CONFIRMATIONS_COLLECTION));
  await gameRef.delete();
};

const normalizeNumber = (value) => {
  if (typeof value === "number") {
    return Number.isFinite(value) ? value : 0;
  }
  if (value === null || value === undefined) {
    return 0;
  }
  const normalized = value.toString().replace(/\s/g, "").replace(",", ".");
  const parsed = Number.parseFloat(normalized);
  return Number.isFinite(parsed) ? parsed : 0;
};

const formatNumber = (value) => {
  if (!Number.isFinite(value)) {
    return "0";
  }
  return value.toLocaleString("pl-PL", { maximumFractionDigits: 2 });
};

const getTablesCollectionName = () => {
  const configured =
    window.firebaseConfig && typeof window.firebaseConfig[TABLES_COLLECTION_CONFIG_KEY] === "string"
      ? window.firebaseConfig[TABLES_COLLECTION_CONFIG_KEY].trim()
      : "";
  return configured || TABLES_COLLECTION;
};

const getGamesCollectionName = () => {
  const configured =
    window.firebaseConfig && typeof window.firebaseConfig[GAMES_COLLECTION_CONFIG_KEY] === "string"
      ? window.firebaseConfig[GAMES_COLLECTION_CONFIG_KEY].trim()
      : "";
  return configured || GAMES_COLLECTION;
};

const getGameDetailsCollectionName = () => {
  const configured =
    window.firebaseConfig && typeof window.firebaseConfig[GAME_DETAILS_COLLECTION_CONFIG_KEY] === "string"
      ? window.firebaseConfig[GAME_DETAILS_COLLECTION_CONFIG_KEY].trim()
      : "";
  return configured || GAME_DETAILS_COLLECTION;
};

const getUserGamesCollectionName = () => {
  const configured =
    window.firebaseConfig && typeof window.firebaseConfig[USER_GAMES_COLLECTION_CONFIG_KEY] === "string"
      ? window.firebaseConfig[USER_GAMES_COLLECTION_CONFIG_KEY].trim()
      : "";
  return configured || USER_GAMES_COLLECTION;
};

const getActiveGamesForConfirmations = async (db, gamesCollectionName, source = "default") => {
  const queryOptions = source === "default" ? undefined : { source };
  const collectionRef = db.collection(gamesCollectionName);

  const toSortedActiveGames = (snapshot) => {
    return snapshot.docs
      .map((doc) => ({ id: doc.id, ...doc.data() }))
      .filter((game) => !Boolean(game.isClosed))
      .sort(compareByGameDateAsc);
  };

  try {
    const orderedSnapshot = await collectionRef.orderBy("createdAt", "asc").get(queryOptions);
    return toSortedActiveGames(orderedSnapshot);
  } catch (orderedError) {
    const fallbackSnapshot = await collectionRef.get(queryOptions);
    return toSortedActiveGames(fallbackSnapshot);
  }
};

const getActiveGamesForConfirmationsFromCollections = async (db, collectionNames, source = "default") => {
  const uniqueCollectionNames = Array.from(new Set(collectionNames.filter((name) => typeof name === "string" && name.trim())));
  const result = [];

  for (const collectionName of uniqueCollectionNames) {
    const games = await getActiveGamesForConfirmations(db, collectionName, source);
    games.forEach((game) => {
      result.push({
        collectionName,
        game
      });
    });
  }

  return result.sort((a, b) => compareByGameDateAsc(a.game, b.game));
};


const formatFirestoreError = (error) => {
  if (!error) {
    return "";
  }
  const parts = [];
  if (error.code) {
    parts.push(`kod: ${error.code}`);
  }
  if (error.message) {
    parts.push(`opis: ${error.message}`);
  }
  return parts.length ? `(${parts.join(", ")})` : "";
};

const scheduleDebouncedUpdate = (key, callback, delay = 400) => {
  const existing = debounceTimers.get(key);
  if (existing) {
    clearTimeout(existing);
  }
  const timeoutId = setTimeout(() => {
    debounceTimers.delete(key);
    callback();
  }, delay);
  debounceTimers.set(key, timeoutId);
};

const hasPendingDebounceWithPrefix = (prefix) => {
  if (!prefix) {
    return false;
  }

  for (const key of debounceTimers.keys()) {
    if (typeof key === "string" && key.startsWith(prefix)) {
      return true;
    }
  }
  return false;
};

const isEditingSection = (sectionNames) => {
  if (!Array.isArray(sectionNames) || !sectionNames.length) {
    return false;
  }

  const activeElement = document.activeElement;
  if (!isFocusableFormControl(activeElement)) {
    return false;
  }

  return sectionNames.includes(activeElement.dataset.section ?? "");
};

const sanitizePin = (value) => value.replace(/\D/g, "").slice(0, PIN_LENGTH);
const isPinValid = (value) => /^\d{5}$/.test(value);
const generateRandomPin = () => `${Math.floor(Math.random() * 10 ** PIN_LENGTH)}`.padStart(PIN_LENGTH, "0");

const getPinGateState = () => sessionStorage.getItem(PIN_STORAGE_KEY) === "1";

const setPinGateState = (isVerified) => {
  sessionStorage.setItem(PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const getChatPinGateState = () => sessionStorage.getItem(CHAT_PIN_STORAGE_KEY) === "1";

const setChatPinGateState = (isVerified) => {
  sessionStorage.setItem(CHAT_PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const setChatVerifiedPlayerId = (playerId) => {
  if (playerId) {
    sessionStorage.setItem(CHAT_PLAYER_ID_STORAGE_KEY, playerId);
    return;
  }
  sessionStorage.removeItem(CHAT_PLAYER_ID_STORAGE_KEY);
};

const getChatVerifiedPlayer = () => {
  const playerId = sessionStorage.getItem(CHAT_PLAYER_ID_STORAGE_KEY);
  if (!playerId) {
    return null;
  }
  return adminPlayersState.players.find((player) => player.id === playerId) ?? null;
};

const getConfirmationsPinGateState = () => sessionStorage.getItem(CONFIRMATIONS_PIN_STORAGE_KEY) === "1";

const setConfirmationsPinGateState = (isVerified) => {
  sessionStorage.setItem(CONFIRMATIONS_PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const setConfirmationsVerifiedPlayerId = (playerId) => {
  if (playerId) {
    sessionStorage.setItem(CONFIRMATIONS_PLAYER_ID_STORAGE_KEY, playerId);
    return;
  }
  sessionStorage.removeItem(CONFIRMATIONS_PLAYER_ID_STORAGE_KEY);
};

const getConfirmationsVerifiedPlayer = () => {
  const playerId = sessionStorage.getItem(CONFIRMATIONS_PLAYER_ID_STORAGE_KEY);
  if (!playerId) {
    return null;
  }
  return adminPlayersState.players.find((player) => player.id === playerId) ?? null;
};

const getUserGamesPinGateState = () => sessionStorage.getItem(USER_GAMES_PIN_STORAGE_KEY) === "1";

const setUserGamesPinGateState = (isVerified) => {
  sessionStorage.setItem(USER_GAMES_PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const setUserGamesVerifiedPlayerId = (playerId) => {
  if (playerId) {
    sessionStorage.setItem(USER_GAMES_PLAYER_ID_STORAGE_KEY, playerId);
    return;
  }
  sessionStorage.removeItem(USER_GAMES_PLAYER_ID_STORAGE_KEY);
};

const getUserGamesVerifiedPlayer = () => {
  const playerId = sessionStorage.getItem(USER_GAMES_PLAYER_ID_STORAGE_KEY);
  if (!playerId) {
    return null;
  }
  return adminPlayersState.players.find((player) => player.id === playerId) ?? null;
};

const getStatisticsPinGateState = () => sessionStorage.getItem(STATISTICS_PIN_STORAGE_KEY) === "1";

const setStatisticsPinGateState = (isVerified) => {
  sessionStorage.setItem(STATISTICS_PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const setStatisticsVerifiedPlayerId = (playerId) => {
  if (playerId) {
    sessionStorage.setItem(STATISTICS_PLAYER_ID_STORAGE_KEY, playerId);
    return;
  }
  sessionStorage.removeItem(STATISTICS_PLAYER_ID_STORAGE_KEY);
};

const getStatisticsVerifiedPlayer = () => {
  const playerId = sessionStorage.getItem(STATISTICS_PLAYER_ID_STORAGE_KEY);
  if (!playerId) {
    return null;
  }
  return adminPlayersState.players.find((player) => player.id === playerId) ?? null;
};

const getPlayerZonePinGateState = () => sessionStorage.getItem(PLAYER_ZONE_PIN_STORAGE_KEY) === "1";

const setPlayerZonePinGateState = (isVerified) => {
  sessionStorage.setItem(PLAYER_ZONE_PIN_STORAGE_KEY, isVerified ? "1" : "0");
};

const setPlayerZoneVerifiedPlayerId = (playerId) => {
  if (playerId) {
    sessionStorage.setItem(PLAYER_ZONE_PLAYER_ID_STORAGE_KEY, playerId);
    return;
  }
  sessionStorage.removeItem(PLAYER_ZONE_PLAYER_ID_STORAGE_KEY);
};

const getPlayerZoneVerifiedPlayer = () => {
  const playerId = sessionStorage.getItem(PLAYER_ZONE_PLAYER_ID_STORAGE_KEY);
  if (!playerId) {
    return null;
  }
  return adminPlayersState.players.find((player) => player.id === playerId) ?? null;
};

const addDays = (dateValue, days) => {
  const baseDate = new Date(dateValue);
  const shiftedDate = new Date(baseDate.getTime());
  shiftedDate.setDate(shiftedDate.getDate() + days);
  return shiftedDate;
};

const toFirestoreDate = (value) => {
  if (!value) {
    return null;
  }

  if (typeof value.toDate === "function") {
    return value.toDate();
  }

  if (value instanceof Date) {
    return value;
  }

  return null;
};

const formatChatTimestamp = (value) => {
  const dateValue = toFirestoreDate(value);
  if (!dateValue) {
    return "w trakcie wysyłki...";
  }

  return dateValue.toLocaleString("pl-PL", {
    day: "2-digit",
    month: "2-digit",
    year: "numeric",
    hour: "2-digit",
    minute: "2-digit"
  });
};

const isPlayerAllowedForTab = (player, tabKey) => {
  if (!player || !Array.isArray(player.permissions)) {
    return false;
  }
  return player.permissions.includes(tabKey);
};

const updatePinVisibility = () => {
  const gate = document.querySelector("#nextGamePinGate");
  const content = document.querySelector("#nextGameContent");
  if (!gate || !content) {
    return;
  }

  const isVerified = getPinGateState();
  gate.style.display = isVerified ? "none" : "block";
  content.classList.toggle("is-visible", isVerified);
};

const initPinGate = () => {
  const input = document.querySelector("#nextGamePinInput");
  const submitButton = document.querySelector("#nextGamePinSubmit");
  const status = document.querySelector("#nextGamePinStatus");

  if (!input || !submitButton || !status) {
    return;
  }

  input.addEventListener("input", () => {
    input.value = sanitizePin(input.value);
  });

  const verifyPin = () => {
    const pinValue = sanitizePin(input.value);
    if (!isPinValid(pinValue)) {
      status.textContent = "Wpisz komplet 5 cyfr.";
      return;
    }

    const player = adminPlayersState.playerByPin.get(pinValue);

    if (player && isPlayerAllowedForTab(player, "nextGameTab")) {
      setPinGateState(true);
      status.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      updatePinVisibility();
    } else {
      status.textContent = "Błędny PIN lub brak uprawnień do zakładki „Najbliższa gra”.";
    }
  };

  submitButton.addEventListener("click", verifyPin);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      verifyPin();
    }
  });

  updatePinVisibility();
};

const renderNextGamesTable = (tableBody, games, emptyMessage, options = {}) => {
  if (!tableBody) {
    return;
  }

  const {
    canDeleteCompletely = false,
    onDeleteCompletely = null
  } = options;

  const createCell = (value) => {
    const cell = document.createElement("td");
    cell.textContent = String(value ?? "");
    return cell;
  };

  tableBody.innerHTML = "";
  if (!games.length) {
    const emptyRow = document.createElement("tr");
    const emptyCell = document.createElement("td");
    emptyCell.colSpan = canDeleteCompletely ? 5 : 4;
    emptyCell.textContent = emptyMessage;
    emptyRow.appendChild(emptyCell);
    tableBody.appendChild(emptyRow);
    return;
  }

  games.forEach((game) => {
    const row = document.createElement("tr");
    row.appendChild(createCell(game.gameType || ""));
    row.appendChild(createCell(game.gameDate || ""));
    row.appendChild(createCell(game.name || ""));
    row.appendChild(createCell(game.allConfirmed ? "Tak" : "Nie"));

    if (canDeleteCompletely) {
      const deleteCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger";
      deleteButton.textContent = "Usuń Całkowicie";
      deleteButton.addEventListener("click", () => {
        if (typeof onDeleteCompletely === "function") {
          void onDeleteCompletely(game);
        }
      });
      deleteCell.appendChild(deleteButton);
      row.appendChild(deleteCell);
    }

    tableBody.appendChild(row);
  });
};

const getAllPlayersConfirmedForGame = async ({ db, collectionName, gameId, gameDetailsCollectionName }) => {
  if (!db || !collectionName || !gameId || !gameDetailsCollectionName) {
    return false;
  }

  const gameRef = db.collection(collectionName).doc(gameId);
  const [rowsSnapshot, confirmationsSnapshot] = await Promise.all([
    gameRef.collection(gameDetailsCollectionName).get(),
    gameRef.collection(GAME_CONFIRMATIONS_COLLECTION).get()
  ]);

  const playerIdentifiers = Array.from(new Set(rowsSnapshot.docs
    .map((doc) => getRowPlayerIdentifier(doc.data()))
    .filter(Boolean)));

  if (!playerIdentifiers.length) {
    return false;
  }

  const confirmedPlayers = new Set();
  confirmationsSnapshot.docs.forEach((doc) => {
    const confirmation = doc.data();
    const playerId = typeof confirmation?.playerId === "string" ? confirmation.playerId.trim() : "";
    const playerName = normalizePlayerName(confirmation?.playerName);
    const identifier = playerId ? `id:${playerId}` : (playerName ? `name:${playerName}` : "");
    if (identifier && confirmation?.confirmed === true) {
      confirmedPlayers.add(identifier);
    }
  });

  return playerIdentifiers.every((identifier) => confirmedPlayers.has(identifier));
};

const getUniquePlayersFromRows = (rows = []) => {
  const playersMap = new Map();
  rows.forEach((row) => {
    const identifier = getRowPlayerIdentifier(row);
    if (!identifier || playersMap.has(identifier)) {
      return;
    }
    playersMap.set(identifier, {
      identifier,
      playerName: normalizePlayerName(row?.playerName)
    });
  });
  return Array.from(playersMap.values());
};

const getConfirmedPlayerIdentifiersFromConfirmations = (confirmations = []) => {
  const confirmedPlayers = new Set();
  confirmations.forEach((confirmation) => {
    const playerId = typeof confirmation?.playerId === "string" ? confirmation.playerId.trim() : "";
    const playerName = normalizePlayerName(confirmation?.playerName);
    const identifier = playerId ? `id:${playerId}` : (playerName ? `name:${playerName}` : "");
    if (identifier && confirmation?.confirmed === true) {
      confirmedPlayers.add(identifier);
    }
  });
  return confirmedPlayers;
};

const getConfirmedCountLabel = (rows = [], confirmations = []) => {
  const players = getUniquePlayersFromRows(rows);
  const confirmedPlayers = getConfirmedPlayerIdentifiersFromConfirmations(confirmations);
  const confirmedCount = players.reduce((count, player) => (confirmedPlayers.has(player.identifier) ? count + 1 : count), 0);
  return `${confirmedCount}/${players.length}`;
};

const getConfirmationStatusesForRows = (rows = [], confirmations = []) => {
  const confirmedPlayers = getConfirmedPlayerIdentifiersFromConfirmations(confirmations);
  return getUniquePlayersFromRows(rows).map((player) => ({
    playerName: player.playerName,
    confirmed: confirmedPlayers.has(player.identifier)
  }));
};

let confirmationsStatusModalController = null;
const getConfirmationsStatusModalController = () => {
  if (confirmationsStatusModalController) {
    return confirmationsStatusModalController;
  }

  const modal = document.createElement("div");
  modal.className = "modal-overlay";
  modal.setAttribute("aria-hidden", "true");
  modal.innerHTML = `
    <div class="modal-card modal-card-sm" role="dialog" aria-modal="true" aria-labelledby="confirmationsStatusModalTitle">
      <div class="modal-header">
        <h3 id="confirmationsStatusModalTitle">Status potwierdzeń</h3>
        <button type="button" class="icon-button" data-confirmations-status-close aria-label="Zamknij okno">×</button>
      </div>
      <div class="modal-body">
        <p class="status-text" data-confirmations-status-meta></p>
        <div class="admin-table-scroll">
          <table class="admin-data-table">
            <thead>
              <tr>
                <th>Gracz</th>
                <th>Status</th>
              </tr>
            </thead>
            <tbody data-confirmations-status-body></tbody>
          </table>
        </div>
      </div>
    </div>
  `;
  document.body.appendChild(modal);

  const closeButton = modal.querySelector("[data-confirmations-status-close]");
  const meta = modal.querySelector("[data-confirmations-status-meta]");
  const body = modal.querySelector("[data-confirmations-status-body]");
  let activeContextId = "";

  const close = () => {
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    activeContextId = "";
    if (!document.querySelector(".modal-overlay.is-visible")) {
      document.body.classList.remove("modal-open");
    }
  };

  const open = ({ contextId, title, rows, confirmations }) => {
    activeContextId = contextId || "";
    if (meta) {
      meta.textContent = title || "Status potwierdzeń";
    }
    if (body) {
      body.innerHTML = "";
      const statuses = getConfirmationStatusesForRows(rows, confirmations);
      if (!statuses.length) {
        const emptyRow = document.createElement("tr");
        const emptyCell = document.createElement("td");
        emptyCell.colSpan = 2;
        emptyCell.textContent = "Brak zapisanych graczy.";
        emptyRow.appendChild(emptyCell);
        body.appendChild(emptyRow);
      } else {
        statuses.forEach((entry) => {
          const tr = document.createElement("tr");
          if (entry.confirmed) {
            tr.classList.add("confirmed-row");
          }

          const nameCell = document.createElement("td");
          nameCell.textContent = entry.playerName;

          const statusCell = document.createElement("td");
          statusCell.textContent = entry.confirmed ? "Potwierdzony" : "Niepotwierdzony";

          tr.append(nameCell, statusCell);
          body.appendChild(tr);
        });
      }
    }

    modal.classList.add("is-visible");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };

  closeButton?.addEventListener("click", close);
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      close();
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal.classList.contains("is-visible")) {
      close();
    }
  });

  confirmationsStatusModalController = {
    open,
    close,
    isOpenFor: (contextId) => Boolean(contextId) && modal.classList.contains("is-visible") && activeContextId === contextId
  };
  return confirmationsStatusModalController;
};

const isGameOwnedByPlayer = (game, player) => {
  if (!game || !player) {
    return false;
  }
  const byPlayerId = typeof game.createdByPlayerId === "string" && game.createdByPlayerId === player.id;
  const byPin = typeof game.createdByPlayerPin === "string" && game.createdByPlayerPin === player.pin;
  return byPlayerId || byPin;
};

const synchronizeNextGamesConfirmations = async () => {
  if (!nextGamesState.db) {
    syncNextGamesViews();
    return;
  }

  const token = nextGamesState.syncToken + 1;
  nextGamesState.syncToken = token;
  const gameDetailsCollectionName = getGameDetailsCollectionName();

  const enrichWithConfirmations = async (game) => {
    const allConfirmed = await getAllPlayersConfirmedForGame({
      db: nextGamesState.db,
      collectionName: game.collectionName,
      gameId: game.id,
      gameDetailsCollectionName
    });
    return {
      ...game,
      allConfirmed
    };
  };

  const [adminGames, userGames] = await Promise.all([
    Promise.all([]),
    Promise.all(nextGamesState.userGames.map(enrichWithConfirmations))
  ]);

  if (nextGamesState.syncToken !== token) {
    return;
  }

  nextGamesState.adminGames = adminGames;
  nextGamesState.userGames = userGames;
  syncNextGamesViews();
};

const getCombinedOpenGames = () => {
  const todayStart = new Date();
  todayStart.setHours(0, 0, 0, 0);

  const isTodayOrFutureGame = (game) => {
    const dateValue = parseDateFromInput(game?.gameDate);
    if (!dateValue) {
      return false;
    }
    dateValue.setHours(0, 0, 0, 0);
    return dateValue.getTime() >= todayStart.getTime();
  };

  return [...nextGamesState.userGames]
    .filter((game) => !game.isClosed && isTodayOrFutureGame(game))
    .sort((a, b) => {
      const left = getDateSortValue(a.gameDate);
      const right = getDateSortValue(b.gameDate);
      if (!Number.isFinite(left) && !Number.isFinite(right)) {
        return 0;
      }
      if (!Number.isFinite(left)) {
        return 1;
      }
      if (!Number.isFinite(right)) {
        return -1;
      }
      return left - right;
    });
};

const syncNextGamesViews = () => {
  const games = getCombinedOpenGames();
  renderNextGamesTable(
    document.querySelector("#nextGameTableBody"),
    games,
    "Brak otwartych gier do wyświetlenia."
  );

  const handleAdminDeleteCompletely = async (game) => {
    if (!game?.id || !game?.collectionName || !nextGamesState.db) {
      return;
    }

    try {
      await deleteGameCompletely({
        db: nextGamesState.db,
        collectionName: game.collectionName,
        gameId: game.id
      });
    } catch (error) {
      // Brak dodatkowego statusu UI w tym widoku — błąd można sprawdzić w konsoli przeglądarki.
    }
  };

  renderNextGamesTable(
    document.querySelector("#adminNextGameTableBody"),
    games,
    "Brak otwartych gier do wyświetlenia.",
    {
      canDeleteCompletely: true,
      onDeleteCompletely: handleAdminDeleteCompletely
    }
  );
};

const initNextGamesView = () => {
  const firebaseApp = getFirebaseApp();
  const userTableBody = document.querySelector("#nextGameTableBody");
  const adminTableBody = document.querySelector("#adminNextGameTableBody");

  if (!userTableBody && !adminTableBody) {
    return;
  }

  if (!firebaseApp) {
    renderNextGamesTable(userTableBody, [], "Uzupełnij konfigurację Firebase, aby wyświetlić gry.");
    renderNextGamesTable(adminTableBody, [], "Uzupełnij konfigurację Firebase, aby wyświetlić gry.");
    return;
  }

  const db = firebaseApp.firestore();
  nextGamesState.db = db;

  const mapSnapshot = (snapshot, collectionName) => snapshot.docs.map((doc) => ({
    id: doc.id,
    collectionName,
    gameType: typeof doc.data()?.gameType === "string" ? doc.data().gameType : "",
    gameDate: typeof doc.data()?.gameDate === "string" ? doc.data().gameDate : "",
    name: typeof doc.data()?.name === "string" ? doc.data().name : "",
    isClosed: Boolean(doc.data()?.isClosed)
  }));

  if (typeof nextGamesState.adminUnsubscribe === "function") {
    nextGamesState.adminUnsubscribe();
  }
  if (typeof nextGamesState.userUnsubscribe === "function") {
    nextGamesState.userUnsubscribe();
  }

  nextGamesState.adminGames = [];
  nextGamesState.adminUnsubscribe = null;

  nextGamesState.userUnsubscribe = db.collection(USER_GAMES_COLLECTION)
    .onSnapshot((snapshot) => {
      nextGamesState.userGames = mapSnapshot(snapshot, USER_GAMES_COLLECTION);
      void synchronizeNextGamesConfirmations();
    });

  registerAdminRefreshHandler("adminNextGameTab", async () => {
    const [userGamesSnapshot] = await Promise.all([
      db.collection(USER_GAMES_COLLECTION).get({ source: "server" })
    ]);
    nextGamesState.adminGames = [];
    nextGamesState.userGames = mapSnapshot(userGamesSnapshot, USER_GAMES_COLLECTION);
    await synchronizeNextGamesConfirmations();
  });
};

const updateChatVisibility = () => {
  const gate = document.querySelector("#chatPinGate");
  const content = document.querySelector("#chatContent");
  if (!gate || !content) {
    return;
  }

  const isVerified = getChatPinGateState();
  gate.style.display = isVerified ? "none" : "block";
  content.classList.toggle("is-visible", isVerified);
};

const sortChatDocumentsByCreatedAtAsc = (documents) => {
  return [...documents].sort((docA, docB) => {
    const createdAtA = docA?.data()?.createdAt;
    const createdAtB = docB?.data()?.createdAt;

    const millisA = typeof createdAtA?.toMillis === "function" ? createdAtA.toMillis() : 0;
    const millisB = typeof createdAtB?.toMillis === "function" ? createdAtB.toMillis() : 0;

    if (millisA !== millisB) {
      return millisA - millisB;
    }
    return docA.id.localeCompare(docB.id, "pl");
  });
};

const scrollContainerToBottom = (container) => {
  if (!container) {
    return;
  }
  requestAnimationFrame(() => {
    container.scrollTop = container.scrollHeight;
  });
};

const scrollChatListsToBottom = () => {
  scrollContainerToBottom(document.querySelector("#chatMessages"));
  scrollContainerToBottom(document.querySelector("#adminChatList"));
};

const renderPlayerChatMessages = (documents) => {
  const chatMessages = document.querySelector("#chatMessages");
  if (!chatMessages) {
    return;
  }

  const sortedDocuments = sortChatDocumentsByCreatedAtAsc(documents);
  chatMessages.innerHTML = "";
  if (!sortedDocuments.length) {
    const empty = document.createElement("p");
    empty.className = "chat-empty";
    empty.textContent = "Brak wiadomości na czacie.";
    chatMessages.appendChild(empty);
    return;
  }

  sortedDocuments.forEach((doc) => {
    const data = doc.data();
    const item = document.createElement("article");
    item.className = "chat-message-item";

    const header = document.createElement("header");
    header.className = "chat-message-header";

    const author = document.createElement("strong");
    author.textContent = typeof data.authorName === "string" ? data.authorName : "Gracz";

    const timestamp = document.createElement("span");
    timestamp.className = "chat-message-date";
    timestamp.textContent = formatChatTimestamp(data.createdAt);

    const text = document.createElement("p");
    text.className = "chat-message-text";
    text.textContent = typeof data.text === "string" ? data.text : "";

    header.appendChild(author);
    header.appendChild(timestamp);
    item.appendChild(header);
    item.appendChild(text);
    chatMessages.appendChild(item);
  });

  scrollContainerToBottom(chatMessages);
};

const initChatTab = () => {
  const input = document.querySelector("#chatPinInput");
  const submitButton = document.querySelector("#chatPinSubmit");
  const pinStatus = document.querySelector("#chatPinStatus");
  const sendButton = document.querySelector("#chatMessageSend");
  const messageInput = document.querySelector("#chatMessageInput");
  const messageStatus = document.querySelector("#chatMessageStatus");
  const firebaseApp = getFirebaseApp();

  if (!input || !submitButton || !pinStatus || !sendButton || !messageInput || !messageStatus) {
    return;
  }

  if (!firebaseApp) {
    submitButton.disabled = true;
    sendButton.disabled = true;
    messageStatus.textContent = "Uzupełnij konfigurację Firebase, aby korzystać z czatu.";
    return;
  }

  const db = firebaseApp.firestore();

  const stopSubscription = () => {
    if (typeof chatState.unsubscribe === "function") {
      chatState.unsubscribe();
      chatState.unsubscribe = null;
    }
  };

  chatState.stopPlayerSubscription = stopSubscription;

  const startSubscription = () => {
    const player = getChatVerifiedPlayer();
    if (!getChatPinGateState() || !player || !isPlayerAllowedForTab(player, "chatTab")) {
      stopSubscription();
      return;
    }

    stopSubscription();
    chatState.unsubscribe = db.collection(CHAT_COLLECTION)
      .orderBy("createdAt", "asc")
      .limit(200)
      .onSnapshot(
        (snapshot) => {
          renderPlayerChatMessages(snapshot.docs);
          messageStatus.textContent = "";
        },
        () => {
          messageStatus.textContent = "Nie udało się pobrać wiadomości czatu.";
        }
      );
  };

  chatState.startPlayerSubscription = startSubscription;

  const verifyPin = () => {
    const pinValue = sanitizePin(input.value);
    if (!isPinValid(pinValue)) {
      pinStatus.textContent = "Wpisz komplet 5 cyfr.";
      return;
    }

    const player = adminPlayersState.playerByPin.get(pinValue);
    if (player && isPlayerAllowedForTab(player, "chatTab")) {
      setChatPinGateState(true);
      setChatVerifiedPlayerId(player.id);
      pinStatus.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      updateChatVisibility();
      startSubscription();
      return;
    }

    pinStatus.textContent = "Błędny PIN lub brak uprawnień do zakładki „Czat”.";
  };

  input.addEventListener("input", () => {
    input.value = sanitizePin(input.value);
  });

  submitButton.addEventListener("click", verifyPin);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      verifyPin();
    }
  });

  sendButton.addEventListener("click", async () => {
    const text = messageInput.value.trim();
    const player = getChatVerifiedPlayer();

    if (!getChatPinGateState() || !player || !isPlayerAllowedForTab(player, "chatTab")) {
      messageStatus.textContent = "Twoja sesja czatu wygasła. Zweryfikuj PIN ponownie.";
      setChatPinGateState(false);
      setChatVerifiedPlayerId("");
      stopSubscription();
      updateChatVisibility();
      return;
    }

    if (!text) {
      messageStatus.textContent = "Wpisz treść wiadomości.";
      return;
    }

    sendButton.disabled = true;
    messageStatus.textContent = "Wysyłanie...";

    try {
      await db.collection(CHAT_COLLECTION).add({
        text,
        authorName: player.name || "Gracz",
        authorId: player.id,
        createdAt: firebaseApp.firestore.FieldValue.serverTimestamp(),
        expireAt: firebaseApp.firestore.Timestamp.fromDate(addDays(new Date(), CHAT_RETENTION_DAYS)),
        source: "web-player"
      });
      messageInput.value = "";
      messageStatus.textContent = "Wiadomość wysłana.";
    } catch (error) {
      messageStatus.textContent = "Nie udało się wysłać wiadomości.";
    } finally {
      sendButton.disabled = false;
    }
  });

  updateChatVisibility();
  if (getChatPinGateState() && getChatVerifiedPlayer()) {
    startSubscription();
  }
};

const updateConfirmationsVisibility = () => {
  const gate = document.querySelector("#confirmationsPinGate");
  const content = document.querySelector("#confirmationsContent");
  if (!gate || !content) {
    return;
  }

  const isVerified = getConfirmationsPinGateState();
  gate.style.display = isVerified ? "none" : "block";
  content.classList.toggle("is-visible", isVerified);
};

const initUserConfirmations = () => {
  const input = document.querySelector("#confirmationsPinInput");
  const submitButton = document.querySelector("#confirmationsPinSubmit");
  const pinStatus = document.querySelector("#confirmationsPinStatus");
  const status = document.querySelector("#confirmationsStatus");
  const body = document.querySelector("#confirmationsBody");
  const detailsModal = document.querySelector("#confirmationsDetailsModal");
  const detailsMeta = document.querySelector("#confirmationsDetailsMeta");
  const detailsBody = document.querySelector("#confirmationsDetailsBody");
  const detailsClose = document.querySelector("#confirmationsDetailsClose");
  const firebaseApp = getFirebaseApp();

  if (!input || !submitButton || !pinStatus || !status || !body) {
    return;
  }

  if (!firebaseApp) {
    submitButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby korzystać z potwierdzeń.";
    return;
  }

  const db = firebaseApp.firestore();
  const summaryNotesModal = getSummaryNotesModalController();
  const confirmationsStatusModal = getConfirmationsStatusModalController();

  const openConfirmationsStatusModal = (gameId) => {
    const game = state.games.find((entry) => entry.id === gameId);
    if (!game) {
      return;
    }
    const rows = state.detailsByGame.get(gameId) ?? [];
    const confirmations = state.confirmationsByGame.get(gameId) ?? [];
    confirmationsStatusModal.open({
      contextId: `${gamesCollectionName}:${gameId}`,
      title: `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`,
      rows,
      confirmations
    });
  };

  const closeDetailsModal = () => {
    if (!detailsModal) {
      return;
    }
    detailsModal.classList.remove("is-visible");
    detailsModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const openDetailsModal = async ({ collectionName, game }) => {
    if (!detailsModal || !detailsMeta || !detailsBody) {
      return;
    }

    detailsBody.innerHTML = "";
    const rowsSnapshot = await db.collection(collectionName).doc(game.id).collection(gameDetailsCollectionName).orderBy("createdAt", "asc").get();
    const rows = rowsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    const gamePool = rows.reduce((sum, row) => sum + parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy), 0);
    detailsMeta.textContent = `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"} | Pula: ${gamePool}`;

    if (!rows.length) {
      const emptyRow = document.createElement("tr");
      const emptyCell = document.createElement("td");
      emptyCell.colSpan = 8;
      emptyCell.textContent = "Brak graczy w tej grze.";
      emptyRow.appendChild(emptyCell);
      detailsBody.appendChild(emptyRow);
    }

    rows.forEach((row, index) => {
      const tr = document.createElement("tr");
      const lpCell = document.createElement("td");
      lpCell.textContent = String(index + 1);
      const playerCell = document.createElement("td");
      playerCell.textContent = row.playerName || "-";
      const entryFeeCell = document.createElement("td");
      entryFeeCell.textContent = String(parseIntegerOrZero(row.entryFee));
      const rebuyCell = document.createElement("td");
      rebuyCell.textContent = String(parseIntegerOrZero(row.rebuy));
      const payoutCell = document.createElement("td");
      payoutCell.textContent = String(parseIntegerOrZero(row.payout));
      const profitCell = document.createElement("td");
      profitCell.textContent = String(parseIntegerOrZero(row.payout) - (parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy)));
      const pointsCell = document.createElement("td");
      pointsCell.textContent = String(parseIntegerOrZero(row.points));
      const championshipCell = document.createElement("td");
      championshipCell.textContent = row.championship ? "Tak" : "Nie";
      tr.append(lpCell, playerCell, entryFeeCell, rebuyCell, payoutCell, profitCell, pointsCell, championshipCell);
      detailsBody.appendChild(tr);
    });

    detailsModal.classList.add("is-visible");
    detailsModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };
  const userGamesCollectionName = getUserGamesCollectionName();
  const gameDetailsCollectionName = getGameDetailsCollectionName();

  const readData = async (source = "default") => {
    const verifiedPlayer = getConfirmationsVerifiedPlayer();
    if (!verifiedPlayer || !isPlayerAllowedForTab(verifiedPlayer, "confirmationsTab")) {
      status.textContent = "Twoja sesja wygasła. Zweryfikuj PIN ponownie.";
      setConfirmationsPinGateState(false);
      setConfirmationsVerifiedPlayerId("");
      updateConfirmationsVisibility();
      return;
    }

    status.textContent = source === "server" ? "Odświeżanie danych..." : "Pobieranie danych...";
    body.innerHTML = "";

    try {
      const games = await getActiveGamesForConfirmationsFromCollections(db, [userGamesCollectionName], source);

      const visibleGames = [];
      for (const entry of games) {
        const { collectionName, game } = entry;
        const rowsSnapshot = await db.collection(collectionName)
          .doc(game.id)
          .collection(gameDetailsCollectionName)
          .get(source === "default" ? undefined : { source });

        const hasPlayer = rowsSnapshot.docs.some((rowDoc) => {
          const rowData = rowDoc.data() ?? {};
          const rowPlayerId = typeof rowData.playerId === "string" ? rowData.playerId.trim() : "";
          if (rowPlayerId) {
            return rowPlayerId === verifiedPlayer.id;
          }
          const playerName = normalizePlayerName(rowData.playerName);
          return playerName && playerName === normalizePlayerName(verifiedPlayer.name);
        });

        if (!hasPlayer) {
          continue;
        }

        const confirmationDoc = await db.collection(collectionName)
          .doc(game.id)
          .collection(GAME_CONFIRMATIONS_COLLECTION)
          .doc(verifiedPlayer.id)
          .get(source === "default" ? undefined : { source });

        visibleGames.push({
          collectionName,
          game,
          confirmation: confirmationDoc.exists ? confirmationDoc.data() : null
        });
      }

      if (!visibleGames.length) {
        const emptyRow = document.createElement("tr");
        const emptyCell = document.createElement("td");
        emptyCell.colSpan = 4;
        emptyCell.textContent = "Brak gier do potwierdzenia.";
        emptyRow.appendChild(emptyCell);
        body.appendChild(emptyRow);
        status.textContent = "Brak aktywnych gier do potwierdzenia.";
        return;
      }

      visibleGames.forEach(({ collectionName, game, confirmation }) => {
        const tr = document.createElement("tr");
        if (confirmation?.confirmed) {
          tr.classList.add("confirmed-row");
        }

        const gameTypeCell = document.createElement("td");
        gameTypeCell.textContent = game.gameType || "-";

        const dateCell = document.createElement("td");
        dateCell.textContent = game.gameDate || "-";

        const nameCell = document.createElement("td");
        nameCell.textContent = game.name || "-";

        const actionsCell = document.createElement("td");
        const actionsWrap = document.createElement("div");
        actionsWrap.className = "confirmations-actions";

        const confirmButton = document.createElement("button");
        confirmButton.type = "button";
        confirmButton.className = "primary";
        confirmButton.textContent = "Potwierdź";
        confirmButton.addEventListener("click", async () => {
          await db.collection(collectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).doc(verifiedPlayer.id).set({
            playerId: verifiedPlayer.id,
            playerName: verifiedPlayer.name || "",
            confirmed: true,
            updatedBy: "player",
            updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
          tr.classList.add("confirmed-row");
          void synchronizeNextGamesConfirmations();
        });

        const cancelButton = document.createElement("button");
        cancelButton.type = "button";
        cancelButton.className = "danger";
        cancelButton.textContent = "Anuluj";
        cancelButton.addEventListener("click", async () => {
          await db.collection(collectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).doc(verifiedPlayer.id).set({
            playerId: verifiedPlayer.id,
            playerName: verifiedPlayer.name || "",
            confirmed: false,
            updatedBy: "player",
            updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
          }, { merge: true });
          tr.classList.remove("confirmed-row");
          void synchronizeNextGamesConfirmations();
        });

        const detailsButton = document.createElement("button");
        detailsButton.type = "button";
        detailsButton.className = "secondary";
        detailsButton.textContent = "Szczegóły";
        detailsButton.addEventListener("click", async () => {
          await openDetailsModal({ collectionName, game });
        });

        const notesButton = document.createElement("button");
        notesButton.type = "button";
        notesButton.className = "secondary";
        notesButton.textContent = "Notatki do gry";
        notesButton.addEventListener("click", () => {
          summaryNotesModal.open({
            gameId: game.id,
            gameName: game.name || "Bez nazwy",
            notes: getPreGameNotes(game),
            canWrite: false,
            onSave: null,
            notesLabel: "Notatki do gry",
            clearButtonLabel: "Domyślne",
            clearToDefault: true,
            readOnlyMessage: "Podgląd notatek do gry (tylko odczyt).",
            triggerButton: notesButton
          });
        });

        actionsWrap.append(confirmButton, cancelButton, detailsButton, notesButton);
        actionsCell.appendChild(actionsWrap);
        tr.append(gameTypeCell, dateCell, nameCell, actionsCell);
        body.appendChild(tr);
      });

      status.textContent = `Załadowano ${visibleGames.length} gier.`;
    } catch (error) {
      status.textContent = "Nie udało się pobrać gier do potwierdzenia.";
    }
  };

  let refreshInProgress = false;
  refreshUserConfirmationsData = async (source = "server") => {
    if (refreshInProgress) {
      return;
    }
    refreshInProgress = true;
    try {
      await readData(source);
    } finally {
      refreshInProgress = false;
    }
  };

  const verifyPin = async () => {
    const pinValue = sanitizePin(input.value);
    if (!isPinValid(pinValue)) {
      pinStatus.textContent = "Wpisz komplet 5 cyfr.";
      return;
    }

    const player = adminPlayersState.playerByPin.get(pinValue);
    if (player && isPlayerAllowedForTab(player, "confirmationsTab")) {
      setConfirmationsPinGateState(true);
      setConfirmationsVerifiedPlayerId(player.id);
      pinStatus.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      updateConfirmationsVisibility();
      await readData();
      return;
    }

    pinStatus.textContent = "Błędny PIN lub brak uprawnień do zakładki „Gry do potwierdzenia”.";
  };

  input.addEventListener("input", () => {
    input.value = sanitizePin(input.value);
  });

  submitButton.addEventListener("click", () => {
    void verifyPin();
  });

  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      void verifyPin();
    }
  });

  if (detailsClose) {
    detailsClose.addEventListener("click", closeDetailsModal);
  }
  if (detailsModal) {
    detailsModal.addEventListener("click", (event) => {
      if (event.target === detailsModal) {
        closeDetailsModal();
      }
    });
  }

  updateConfirmationsVisibility();
  if (getConfirmationsPinGateState() && getConfirmationsVerifiedPlayer()) {
    void refreshUserConfirmationsData("default");
  }
};

const updateUserGamesVisibility = () => {
  const gate = document.querySelector("#userGamesPinGate");
  const content = document.querySelector("#userGamesContent");
  if (!gate || !content) {
    return;
  }

  const isVerified = getUserGamesPinGateState();
  gate.style.display = isVerified ? "none" : "block";
  content.classList.toggle("is-visible", isVerified);
};

const initUserGamesTab = () => {
  const input = document.querySelector("#userGamesPinInput");
  const submitButton = document.querySelector("#userGamesPinSubmit");
  const pinStatus = document.querySelector("#userGamesPinStatus");

  if (!input || !submitButton || !pinStatus) {
    return;
  }

  const verifyPin = () => {
    const pinValue = sanitizePin(input.value);
    if (!isPinValid(pinValue)) {
      pinStatus.textContent = "Wpisz komplet 5 cyfr.";
      return;
    }

    const player = adminPlayersState.playerByPin.get(pinValue);
    if (player && isPlayerAllowedForTab(player, "userGamesTab")) {
      setUserGamesPinGateState(true);
      setUserGamesVerifiedPlayerId(player.id);
      pinStatus.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      updateUserGamesVisibility();
      window.dispatchEvent(new CustomEvent("user-games-access-updated"));
      return;
    }

    pinStatus.textContent = "Błędny PIN lub brak uprawnień do zakładki „Gry użytkowników”.";
  };

  input.addEventListener("input", () => {
    input.value = sanitizePin(input.value);
  });

  submitButton.addEventListener("click", verifyPin);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      verifyPin();
    }
  });

  updateUserGamesVisibility();

  if (getUserGamesPinGateState()) {
    const verifiedPlayer = getUserGamesVerifiedPlayer();
    if (!verifiedPlayer || !isPlayerAllowedForTab(verifiedPlayer, "userGamesTab")) {
      setUserGamesPinGateState(false);
      setUserGamesVerifiedPlayerId("");
      updateUserGamesVisibility();
      window.dispatchEvent(new CustomEvent("user-games-access-updated"));
    }
  }
};

const updateStatisticsVisibility = () => {
  const gate = document.querySelector("#statisticsPinGate");
  const content = document.querySelector("#statisticsContent");
  if (!gate || !content) {
    return;
  }

  const isVerified = getStatisticsPinGateState();
  gate.style.display = isVerified ? "none" : "block";
  content.classList.toggle("is-visible", isVerified);
};

const synchronizeStatisticsAccessState = () => {
  if (!getStatisticsPinGateState()) {
    updateStatisticsVisibility();
    return;
  }

  const verifiedPlayer = getStatisticsVerifiedPlayer();
  if (!verifiedPlayer || !isPlayerAllowedForTab(verifiedPlayer, "statsTab")) {
    setStatisticsPinGateState(false);
    setStatisticsVerifiedPlayerId("");
  }

  updateStatisticsVisibility();
  window.dispatchEvent(new CustomEvent("statistics-access-updated"));
};

const initStatisticsTab = () => {
  const input = document.querySelector("#statisticsPinInput");
  const submitButton = document.querySelector("#statisticsPinSubmit");
  const pinStatus = document.querySelector("#statisticsPinStatus");

  if (!input || !submitButton || !pinStatus) {
    return;
  }

  const verifyPin = () => {
    const pinValue = sanitizePin(input.value);
    if (!isPinValid(pinValue)) {
      pinStatus.textContent = "Wpisz komplet 5 cyfr.";
      return;
    }

    const player = adminPlayersState.playerByPin.get(pinValue);
    if (player && isPlayerAllowedForTab(player, "statsTab")) {
      setStatisticsPinGateState(true);
      setStatisticsVerifiedPlayerId(player.id);
      pinStatus.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      updateStatisticsVisibility();
      window.dispatchEvent(new CustomEvent("statistics-access-updated"));
      return;
    }

    pinStatus.textContent = "Błędny PIN lub brak uprawnień do zakładki „Statystyki”.";
  };

  input.addEventListener("input", () => {
    input.value = sanitizePin(input.value);
  });

  submitButton.addEventListener("click", verifyPin);
  input.addEventListener("keydown", (event) => {
    if (event.key === "Enter") {
      verifyPin();
    }
  });

  updateStatisticsVisibility();

  synchronizeStatisticsAccessState();
};

const initUserGamesManager = ({
  yearsListSelector,
  addGameButtonSelector,
  gamesTableBodySelector,
  summariesContainerSelector,
  statusSelector,
  modalSelector,
  modalMetaSelector,
  modalBodySelector,
  modalEntryFeeBulkButtonSelector,
  modalCloseSelector,
  modalAddRowButtonSelector,
  selectedYearStorageKey,
  canWrite,
  createGamePayload,
  canAccessGame = () => true,
  canEditGame = () => true
}) => {
  const yearsList = document.querySelector(yearsListSelector);
  const addGameButton = document.querySelector(addGameButtonSelector);
  const gamesTableBody = document.querySelector(gamesTableBodySelector);
  const summariesContainer = document.querySelector(summariesContainerSelector);
  const status = document.querySelector(statusSelector);
  const modal = document.querySelector(modalSelector);
  const modalMeta = document.querySelector(modalMetaSelector);
  const modalBody = document.querySelector(modalBodySelector);
  const modalEntryFeeBulkButton = modalEntryFeeBulkButtonSelector ? document.querySelector(modalEntryFeeBulkButtonSelector) : null;
  const modalClose = document.querySelector(modalCloseSelector);
  const modalAddRowButton = document.querySelector(modalAddRowButtonSelector);

  if (!yearsList || !gamesTableBody || !summariesContainer || !status || !addGameButton || !modal || !modalMeta || !modalBody || !modalAddRowButton) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    status.textContent = "Uzupełnij konfigurację Firebase, aby zarządzać grami użytkowników.";
    addGameButton.disabled = true;
    return;
  }

  const db = firebaseApp.firestore();
  const gamesCollectionName = getUserGamesCollectionName();
  const gameDetailsCollectionName = getGameDetailsCollectionName();
  const state = {
    years: [],
    selectedYear: loadSavedSelectedGamesYear(selectedYearStorageKey),
    games: [],
    detailsByGame: new Map(),
    detailsUnsubscribers: new Map(),
    confirmationsByGame: new Map(),
    confirmationUnsubscribers: new Map(),
    activeGameIdInModal: null,
    playerOptions: []
  };

  const summaryNotesModal = getSummaryNotesModalController();
  const confirmationsStatusModal = getConfirmationsStatusModalController();

  const openConfirmationsStatusModal = (gameId) => {
    const game = state.games.find((entry) => entry.id === gameId);
    if (!game) {
      return;
    }
    const rows = state.detailsByGame.get(gameId) ?? [];
    const confirmations = state.confirmationsByGame.get(gameId) ?? [];
    confirmationsStatusModal.open({
      contextId: `${gamesCollectionName}:${gameId}`,
      title: `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`,
      rows,
      confirmations
    });
  };

  const detailRebuyModal = document.createElement("div");
  detailRebuyModal.className = "modal-overlay";
  detailRebuyModal.setAttribute("aria-hidden", "true");
  detailRebuyModal.innerHTML = `
    <div class="modal-card modal-card-sm" role="dialog" aria-modal="true" aria-labelledby="gameDetailsRebuyTitle">
      <div class="modal-card-header modal-header-close-right">
        <h3 id="gameDetailsRebuyTitle">Rebuy gracza</h3>
        <button type="button" class="icon-button" data-game-rebuy-close aria-label="Zamknij okno">×</button>
      </div>
      <div class="admin-table-scroll">
        <table class="admin-data-table game-details-rebuy-table" data-game-rebuy-table></table>
      </div>
      <div class="admin-table-actions" data-game-rebuy-actions></div>
    </div>
  `;
  document.body.appendChild(detailRebuyModal);
  const detailRebuyModalTable = detailRebuyModal.querySelector("[data-game-rebuy-table]");
  const detailRebuyModalActions = detailRebuyModal.querySelector("[data-game-rebuy-actions]");
  const detailRebuyModalClose = detailRebuyModal.querySelector("[data-game-rebuy-close]");
  let activeRebuyDetail = null;

  const closeDetailRebuyModal = () => {
    activeRebuyDetail = null;
    detailRebuyModal.classList.remove("is-visible");
    detailRebuyModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const getDetailRowRebuyState = (row) => {
    const legacyRebuy = sanitizeIntegerInput(row.rebuy ?? "");
    const values = Array.isArray(row.rebuys) && row.rebuys.length > 0
      ? row.rebuys.map((value) => sanitizeIntegerInput(value))
      : (legacyRebuy ? [legacyRebuy] : []);
    const indexes = Array.isArray(row.rebuyIndexes) && row.rebuyIndexes.length === values.length
      ? row.rebuyIndexes
        .map((value) => Number.parseInt(String(value), 10))
        .map((value, index) => (Number.isFinite(value) && value > 0 ? value : index + 1))
      : values.map((_, index) => index + 1);
    const maxIndex = indexes.reduce((maxValue, value) => Math.max(maxValue, value), 0);
    const nextIndex = maxIndex + 1;

    return { values, indexes, nextIndex };
  };

  const getDetailRowRebuySum = (row) => getDetailRowRebuyState(row).values.reduce((sum, value) => sum + parseIntegerOrZero(value), 0);

  const persistDetailRowRebuyValues = async (gameId, rowId, rebuyState) => {
    const sanitizedValues = rebuyState.values.map((value) => sanitizeIntegerInput(value));
    const sanitizedIndexes = rebuyState.indexes
      .map((value) => Number.parseInt(String(value), 10))
      .filter((value) => Number.isFinite(value) && value > 0);
    const maxIndex = sanitizedIndexes.reduce((maxValue, value) => Math.max(maxValue, value), 0);
    const nextIndex = maxIndex + 1;
    const rebuySum = sanitizedValues.reduce((sum, value) => sum + parseIntegerOrZero(value), 0);
    await db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(rowId).update({
      rebuys: sanitizedValues,
      rebuyIndexes: sanitizedIndexes,
      rebuyNextIndex: nextIndex,
      rebuy: sanitizedValues.length ? String(rebuySum) : ""
    });
  };

  const renderDetailRebuyModal = () => {
    if (!activeRebuyDetail || !detailRebuyModalTable || !detailRebuyModalActions) {
      return;
    }
    const game = state.games.find((entry) => entry.id === activeRebuyDetail.gameId);
    const row = (state.detailsByGame.get(activeRebuyDetail.gameId) ?? []).find((entry) => entry.id === activeRebuyDetail.rowId);
    if (!game || !row) {
      closeDetailRebuyModal();
      return;
    }
    const writeEnabled = hasWriteAccessToGame(game);
    const rowRebuyState = getDetailRowRebuyState(row);
    let headerHtml = "<thead><tr>";
    rowRebuyState.indexes.forEach((columnIndex) => {
      headerHtml += `<th>Rebuy${columnIndex}</th>`;
    });
    headerHtml += "</tr></thead>";
    detailRebuyModalTable.innerHTML = headerHtml;

    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");
    rowRebuyState.values.forEach((value, index) => {
      const td = document.createElement("td");
      const input = document.createElement("input");
      applyIntegerInputHints(input);
      input.className = "admin-input";
      input.value = value;
      input.disabled = !writeEnabled;
      input.addEventListener("input", () => {
        if (!hasWriteAccessToGame(game)) {
          return;
        }
        rowRebuyState.values[index] = sanitizeIntegerInput(input.value);
        input.value = rowRebuyState.values[index];
        scheduleDebouncedUpdate(`user-detail-rebuy-${activeRebuyDetail.gameId}-${row.id}`, () => (
          persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState)
        ));
      });
      td.appendChild(input);
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
    detailRebuyModalTable.appendChild(tbody);

    detailRebuyModalActions.innerHTML = "";
    const addButton = document.createElement("button");
    addButton.type = "button";
    addButton.className = "secondary";
    addButton.textContent = "Dodaj Rebuy";
    addButton.disabled = !writeEnabled;
    addButton.addEventListener("click", async () => {
      if (!hasWriteAccessToGame(game)) {
        return;
      }
      rowRebuyState.values.push("");
      rowRebuyState.indexes.push(rowRebuyState.nextIndex);
      rowRebuyState.nextIndex += 1;
      await persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState);
      renderDetailRebuyModal();
    });

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "danger";
    removeButton.textContent = "Usuń Rebuy";
    removeButton.disabled = !writeEnabled || rowRebuyState.values.length === 0;
    removeButton.addEventListener("click", async () => {
      if (!hasWriteAccessToGame(game) || rowRebuyState.values.length === 0) {
        return;
      }
      rowRebuyState.values = rowRebuyState.values.slice(0, -1);
      rowRebuyState.indexes = rowRebuyState.indexes.slice(0, -1);
      await persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState);
      renderDetailRebuyModal();
    });

    detailRebuyModalActions.append(addButton, removeButton);
  };

  const openDetailRebuyModal = (gameId, rowId) => {
    activeRebuyDetail = { gameId, rowId };
    detailRebuyModal.classList.add("is-visible");
    detailRebuyModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    renderDetailRebuyModal();
  };

  const closeModal = () => {
    closeDetailRebuyModal();
    state.activeGameIdInModal = null;
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const getGamesForSelectedYear = () => {
    if (!state.selectedYear) {
      return [];
    }
    return state.games
      .filter((game) => canAccessGame(game))
      .filter((game) => extractYearFromDate(game.gameDate) === state.selectedYear)
      .sort(compareByGameDateAsc);
  };

  const hasWriteAccessToGame = (game) => canWrite() && canEditGame(game);

  const syncYearsAfterLocalGameUpdate = (gameId, nextValues) => {
    const targetGame = state.games.find((game) => game.id === gameId);
    if (!targetGame) {
      return;
    }
    Object.assign(targetGame, nextValues);
    synchronizeYearsFromGames();
  };

  const getDetailRows = (gameId) => {
    const rows = state.detailsByGame.get(gameId) ?? [];
    return rows.map((row) => {
      const entryFee = parseIntegerOrZero(row.entryFee);
      const rebuy = parseIntegerOrZero(row.rebuy);
      const payout = parseIntegerOrZero(row.payout);
      return {
        ...row,
        entryFee,
        rebuy,
        payout,
        profit: payout - (entryFee + rebuy),
        points: parseIntegerOrZero(row.points),
        championship: Boolean(row.championship)
      };
    });
  };

  const hasIncludedSummaryOrStatsData = (row) => {
    const normalizedEntryFee = sanitizeIntegerInput(typeof row.entryFee === "number" ? `${row.entryFee}` : row.entryFee ?? "");
    const normalizedPoints = sanitizeIntegerInput(typeof row.points === "number" ? `${row.points}` : row.points ?? "");
    const hasEntryFee = Boolean(normalizedEntryFee) && normalizedEntryFee !== "-" && parseIntegerOrZero(normalizedEntryFee) > 0;
    const hasPoints = Boolean(normalizedPoints) && normalizedPoints !== "-";
    return hasEntryFee || hasPoints;
  };

  const getGameSummaryMetrics = (gameId) => {
    const rows = getDetailRows(gameId).filter((row) => hasIncludedSummaryOrStatsData(row));
    const pool = rows.reduce((sum, row) => sum + row.entryFee + row.rebuy, 0);
    const payoutSum = rows.reduce((sum, row) => sum + row.payout, 0);
    const sortedRows = [...rows].sort((a, b) => b.profit - a.profit);

    return {
      pool,
      payoutSum,
      hasPayoutMismatch: payoutSum !== pool,
      rows: sortedRows.map((row) => ({
        ...row,
        poolSharePercent: pool === 0 ? 0 : Math.round((row.payout / pool) * 100)
      }))
    };
  };

  const renderYears = () => {
    yearsList.innerHTML = "";
    if (!state.years.length) {
      const info = document.createElement("p");
      info.className = "status-text";
      info.textContent = "Brak lat. Dodaj pierwszą grę, aby rok pojawił się automatycznie.";
      yearsList.appendChild(info);
      return;
    }

    state.years.forEach((year) => {
      const yearButton = document.createElement("button");
      yearButton.type = "button";
      yearButton.className = `admin-games-year-button ${state.selectedYear === year ? "is-active" : ""}`.trim();
      yearButton.textContent = String(year);
      yearButton.addEventListener("click", () => {
        state.selectedYear = year;
        saveSelectedGamesYear(state.selectedYear, selectedYearStorageKey);
        renderYears();
        renderGamesTable();
        renderSummaries();
      });
      yearsList.appendChild(yearButton);
    });
  };

  const renderSummaries = () => {
    const previousScrollLeftByGameId = new Map();
    summariesContainer.querySelectorAll("[data-summary-game-id]").forEach((element) => {
      previousScrollLeftByGameId.set(element.dataset.summaryGameId ?? "", element.scrollLeft);
    });
    summariesContainer.innerHTML = "";
    const games = getGamesForSelectedYear();

    games.forEach((game) => {
      const wrapper = document.createElement("section");
      wrapper.className = "admin-games-section admin-game-summary";

      const heading = document.createElement("div");
      heading.className = "admin-game-summary-heading";

      const notesButton = document.createElement("button");
      notesButton.type = "button";
      notesButton.className = "secondary";
      notesButton.textContent = "Notatki po grze";
      notesButton.addEventListener("click", () => {
        summaryNotesModal.open({
          gameId: game.id,
          gameName: game.name || "Bez nazwy",
          notes: getPostGameNotes(game),
          canWrite: hasWriteAccessToGame(game),
          onSave: async ({ notes }) => {
            await db.collection(gamesCollectionName).doc(game.id).update({
              postGameNotes: notes,
              notes: firebaseApp.firestore.FieldValue.delete()
            });
            const target = state.games.find((entry) => entry.id === game.id);
            if (target) {
              target.postGameNotes = notes;
            }
          },
          notesLabel: "Notatki po grze",
          clearButtonLabel: "Usuń",
          clearToDefault: false,
          textareaPlaceholder: "Wpisz notatki po grze...",
          triggerButton: notesButton
        });
      });

      const title = document.createElement("h3");
      title.textContent = `Podsumowanie gry ${game.name || "Bez nazwy"}`;
      heading.append(notesButton, title);

      const metrics = getGameSummaryMetrics(game.id);
      const mismatchWarning = document.createElement("p");
      mismatchWarning.className = "status-text status-text-danger";
      mismatchWarning.textContent = "Nie zgadza się suma wypłat oraz wpisowych i rebuy/add-on";

      const poolInfo = document.createElement("p");
      poolInfo.className = "status-text";
      poolInfo.textContent = `Pula: ${metrics.pool}`;

      const gameTypeInfo = document.createElement("p");
      gameTypeInfo.className = "status-text";
      gameTypeInfo.textContent = `Rodzaj gry: ${game.gameType || "-"}`;

      const tableScroll = document.createElement("div");
      tableScroll.className = "admin-table-scroll";
      tableScroll.dataset.summaryGameId = game.id;
      const table = document.createElement("table");
      table.className = "admin-data-table";
      table.innerHTML = `
        <thead>
          <tr>
            <th>Gracz</th>
            <th>Wpisowe</th>
            <th>Rebuy/Add-on</th>
            <th>Wypłata</th>
            <th>+/-</th>
            <th>% puli</th>
            <th>Punkty</th>
            <th>Mistrzostwo</th>
          </tr>
        </thead>
      `;
      const tbody = document.createElement("tbody");

      if (!metrics.rows.length) {
        const emptyRow = document.createElement("tr");
        const emptyCell = document.createElement("td");
        emptyCell.colSpan = 8;
        emptyCell.textContent = "Brak danych do podsumowania.";
        emptyRow.appendChild(emptyCell);
        tbody.appendChild(emptyRow);
      } else {
        metrics.rows.forEach((row) => {
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <td>${row.playerName || ""}</td>
            <td>${row.entryFee}</td>
            <td>${row.rebuy}</td>
            <td>${row.payout}</td>
            <td>${row.profit}</td>
            <td>${row.poolSharePercent}</td>
            <td>${row.points}</td>
            <td>${row.championship ? "✓" : ""}</td>
          `;
          tbody.appendChild(tr);
        });
      }

      table.appendChild(tbody);
      tableScroll.appendChild(table);
      tableScroll.scrollLeft = previousScrollLeftByGameId.get(game.id) ?? 0;

      if (metrics.hasPayoutMismatch) {
        wrapper.append(heading, mismatchWarning, gameTypeInfo, poolInfo, tableScroll);
      } else {
        wrapper.append(heading, gameTypeInfo, poolInfo, tableScroll);
      }
      summariesContainer.appendChild(wrapper);
    });
  };

  const renderGamesTable = () => {
    const focusState = getFocusedAdminInputState(gamesTableBody);
    gamesTableBody.innerHTML = "";

    if (!state.selectedYear) {
      status.textContent = "Wybierz rok z listy po lewej stronie.";
      return;
    }

    const games = getGamesForSelectedYear();
    status.textContent = `Wybrany rok: ${state.selectedYear}. Liczba gier: ${games.length}.`;

    if (!games.length) {
      const emptyRow = document.createElement("tr");
      const emptyCell = document.createElement("td");
      emptyCell.colSpan = 6;
      emptyCell.textContent = "Brak gier z datą w wybranym roku.";
      emptyRow.appendChild(emptyCell);
      gamesTableBody.appendChild(emptyRow);
      return;
    }

    games.forEach((game) => {
      const row = document.createElement("tr");
      const writeEnabled = hasWriteAccessToGame(game);

      const gameTypeCell = document.createElement("td");
      const gameTypeSelect = document.createElement("select");
      gameTypeSelect.className = "admin-input";
      gameTypeSelect.dataset.focusTarget = "game-list";
      gameTypeSelect.dataset.section = "games-table";
      gameTypeSelect.dataset.tableId = game.id;
      gameTypeSelect.dataset.columnKey = "gameType";
      ["Cashout", "Turniej"].forEach((label) => {
        const option = document.createElement("option");
        option.value = label;
        option.textContent = label;
        gameTypeSelect.appendChild(option);
      });
      gameTypeSelect.value = game.gameType === "Turniej" ? "Turniej" : "Cashout";
      gameTypeSelect.disabled = !writeEnabled;
      gameTypeSelect.addEventListener("change", () => {
        if (!hasWriteAccessToGame(game)) return;
        void db.collection(gamesCollectionName).doc(game.id).update({ gameType: gameTypeSelect.value });
      });
      gameTypeCell.appendChild(gameTypeSelect);

      const dateCell = document.createElement("td");
      const dateInput = document.createElement("input");
      dateInput.type = "date";
      dateInput.className = "admin-input";
      dateInput.dataset.focusTarget = "game-list";
      dateInput.dataset.section = "games-table";
      dateInput.dataset.tableId = game.id;
      dateInput.dataset.columnKey = "gameDate";
      dateInput.value = game.gameDate ?? getFormattedCurrentDate();
      dateInput.disabled = !writeEnabled;
      dateInput.addEventListener("change", () => {
        if (!hasWriteAccessToGame(game)) return;
        const nextDate = dateInput.value || getFormattedCurrentDate();
        const currentName = typeof game.name === "string" ? game.name.trim() : "";
        const updatePayload = { gameDate: nextDate };
        if (!currentName || parseDefaultTableNumber(currentName)) {
          const otherGames = state.games.filter((entry) => entry.id !== game.id);
          updatePayload.name = getNextGameNameForDate(otherGames, nextDate);
        }
        syncYearsAfterLocalGameUpdate(game.id, updatePayload);
        void db.collection(gamesCollectionName).doc(game.id).update(updatePayload);
      });
      dateCell.appendChild(dateInput);

      const nameCell = document.createElement("td");
      const nameWrap = document.createElement("div");
      nameWrap.className = "admin-games-name-control";
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.className = "admin-input";
      nameInput.dataset.focusTarget = "game-list";
      nameInput.dataset.section = "games-table";
      nameInput.dataset.tableId = game.id;
      nameInput.dataset.columnKey = "name";
      nameInput.value = game.name ?? "";
      nameInput.placeholder = "Nazwa gry";
      nameInput.disabled = !writeEnabled;
      nameInput.addEventListener("input", () => {
        if (!hasWriteAccessToGame(game)) return;
        const value = nameInput.value;
        scheduleDebouncedUpdate(`user-game-name-${game.id}`, () => {
          void db.collection(gamesCollectionName).doc(game.id).update({ name: value });
        });
      });
      const detailsButton = document.createElement("button");
      detailsButton.type = "button";
      detailsButton.className = "secondary";
      detailsButton.textContent = "Szczegóły";
      detailsButton.addEventListener("click", () => {
        state.activeGameIdInModal = game.id;
        renderModal(game.id);
        modal.classList.add("is-visible");
        modal.setAttribute("aria-hidden", "false");
        document.body.classList.add("modal-open");
      });
      const notesButton = document.createElement("button");
      notesButton.type = "button";
      notesButton.className = "secondary";
      notesButton.textContent = "Notatki do gry";
      notesButton.addEventListener("click", () => {
        summaryNotesModal.open({
          gameId: game.id,
          gameName: game.name || "Bez nazwy",
          notes: getPreGameNotes(game),
          canWrite: hasWriteAccessToGame(game),
          onSave: async ({ notes }) => {
            await db.collection(gamesCollectionName).doc(game.id).update({
              preGameNotes: notes,
              notes: firebaseApp.firestore.FieldValue.delete()
            });
            const target = state.games.find((entry) => entry.id === game.id);
            if (target) {
              target.preGameNotes = notes;
            }
          },
          notesLabel: "Notatki do gry",
          clearButtonLabel: "Domyślne",
          clearToDefault: true,
          textareaPlaceholder: "Wpisz notatki do gry...",
          triggerButton: notesButton
        });
      });
      nameWrap.append(nameInput, detailsButton, notesButton);
      nameCell.appendChild(nameWrap);

      const closedCell = document.createElement("td");
      const closedInput = document.createElement("input");
      closedInput.type = "checkbox";
      closedInput.checked = Boolean(game.isClosed);
      closedInput.disabled = !writeEnabled;
      closedInput.addEventListener("change", () => {
        if (!hasWriteAccessToGame(game)) return;
        void db.collection(gamesCollectionName).doc(game.id).update({ isClosed: closedInput.checked });
      });
      closedCell.appendChild(closedInput);

      const confirmationsCell = document.createElement("td");
      const detailRows = state.detailsByGame.get(game.id) ?? [];
      const confirmations = state.confirmationsByGame.get(game.id) ?? [];
      const confirmationsWrap = document.createElement("div");
      confirmationsWrap.className = "admin-confirmations-count-control";
      const confirmationsLabel = document.createElement("span");
      confirmationsLabel.textContent = getConfirmedCountLabel(detailRows, confirmations);
      const confirmationsButton = document.createElement("button");
      confirmationsButton.type = "button";
      confirmationsButton.className = "secondary";
      confirmationsButton.textContent = "Statusy";
      confirmationsButton.addEventListener("click", () => openConfirmationsStatusModal(game.id));
      confirmationsWrap.append(confirmationsLabel, confirmationsButton);
      confirmationsCell.appendChild(confirmationsWrap);

      const deleteCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger";
      deleteButton.textContent = "Usuń";
      deleteButton.disabled = !writeEnabled;
      deleteButton.addEventListener("click", async () => {
        if (!hasWriteAccessToGame(game)) return;
        const gameRef = db.collection(gamesCollectionName).doc(game.id);
        const detailsSnapshot = await gameRef.collection(gameDetailsCollectionName).get();
        const confirmationsSnapshot = await gameRef.collection(GAME_CONFIRMATIONS_COLLECTION).get();
        const batch = db.batch();
        detailsSnapshot.forEach((doc) => batch.delete(doc.ref));
        confirmationsSnapshot.forEach((doc) => batch.delete(doc.ref));
        batch.delete(gameRef);
        await batch.commit();
      });
      deleteCell.appendChild(deleteButton);

      row.append(gameTypeCell, dateCell, nameCell, closedCell, confirmationsCell, deleteCell);
      gamesTableBody.appendChild(row);
    });

    restoreFocusedAdminInputState(gamesTableBody, focusState);
  };

  const renderModal = (gameId) => {
    const game = state.games.find((entry) => entry.id === gameId);
    if (!game) {
      return;
    }

    const focusState = getFocusedAdminInputState(modalBody);
    modalMeta.textContent = `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`;
    modalBody.innerHTML = "";

    const rows = state.detailsByGame.get(gameId) ?? [];
    const confirmations = state.confirmationsByGame.get(gameId) ?? [];
    const gamePool = rows.reduce((sum, row) => sum + parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy), 0);
    modalMeta.textContent = `${modalMeta.textContent} | Pula: ${gamePool} | Ilość graczy: ${rows.length}`;
    rows.forEach((row, index) => { 
      const tr = document.createElement("tr");
      const writeEnabled = hasWriteAccessToGame(game);
      const lpCell = document.createElement("td");
      lpCell.textContent = String(index + 1);

      const playerCell = document.createElement("td");
      const playerSelect = document.createElement("select");
      playerSelect.className = "admin-input";
      playerSelect.dataset.focusTarget = "game-details-row";
      playerSelect.dataset.section = "games-modal";
      playerSelect.dataset.tableId = gameId;
      playerSelect.dataset.rowId = row.id;
      playerSelect.dataset.columnKey = "playerId";
      const currentPlayerName = normalizePlayerName(row.playerName);
      const currentPlayerId = typeof row.playerId === "string" ? row.playerId.trim() : "";
      const currentIdentifier = currentPlayerId ? `id:${currentPlayerId}` : (currentPlayerName ? `name:${currentPlayerName}` : "");
      const options = [...state.playerOptions];
      const availableOptions = getAvailablePlayersForRow(rows, row.id, options, currentIdentifier);
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.textContent = "Wybierz gracza";
      playerSelect.appendChild(emptyOption);
      if (currentIdentifier && !availableOptions.some((option) => `id:${option.id}` === currentIdentifier)) {
        const legacyOption = document.createElement("option");
        legacyOption.value = currentPlayerId;
        legacyOption.textContent = `${currentPlayerName} (usunięty)`;
        legacyOption.disabled = true;
        legacyOption.selected = true;
        playerSelect.appendChild(legacyOption);
      }
      availableOptions.forEach((player) => {
        const option = document.createElement("option");
        option.value = player.id;
        option.textContent = player.name;
        playerSelect.appendChild(option);
      });
      playerSelect.value = currentPlayerId;
      playerSelect.disabled = !writeEnabled;
      playerSelect.addEventListener("change", () => {
        if (!hasWriteAccessToGame(game)) return;
        const selectedPlayer = options.find((option) => option.id === playerSelect.value) ?? null;
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({
          playerId: selectedPlayer?.id ?? "",
          playerName: selectedPlayer?.name ?? ""
        });
      });
      playerCell.appendChild(playerSelect);

      const createNumericCell = (key) => {
        const td = document.createElement("td");
        const input = document.createElement("input");
        applyIntegerInputHints(input);
        input.className = "admin-input";
        input.dataset.focusTarget = "game-details-row";
        input.dataset.section = "games-modal";
        input.dataset.tableId = gameId;
        input.dataset.rowId = row.id;
        input.dataset.columnKey = key;
        const rawValue = row[key] ?? "";
        input.value = rawValue;
        input.disabled = !writeEnabled;
        input.addEventListener("input", () => {
          if (!hasWriteAccessToGame(game)) return;
          input.value = sanitizeIntegerInput(input.value);
          scheduleDebouncedUpdate(`user-detail-${gameId}-${row.id}-${key}`, () => {
            void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({ [key]: input.value });
          });
        });
        td.appendChild(input);
        return td;
      };

      const entryFeeCell = createNumericCell("entryFee");
      const rebuyCell = document.createElement("td");
      const rebuyButton = document.createElement("button");
      rebuyButton.type = "button";
      rebuyButton.className = "secondary";
      rebuyButton.textContent = formatNumber(getDetailRowRebuySum(row));
      rebuyButton.disabled = !writeEnabled;
      rebuyButton.addEventListener("click", () => {
        openDetailRebuyModal(gameId, row.id);
      });
      rebuyCell.appendChild(rebuyButton);
      const payoutCell = createNumericCell("payout");

      const profitCell = document.createElement("td");
      profitCell.textContent = String(parseIntegerOrZero(row.payout) - (parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy)));

      const pointsCell = createNumericCell("points");

      const championshipCell = document.createElement("td");
      const championshipInput = document.createElement("input");
      championshipInput.type = "checkbox";
      championshipInput.dataset.focusTarget = "game-details-row";
      championshipInput.dataset.section = "games-modal";
      championshipInput.dataset.tableId = gameId;
      championshipInput.dataset.rowId = row.id;
      championshipInput.dataset.columnKey = "championship";
      championshipInput.checked = Boolean(row.championship);
      championshipInput.disabled = !writeEnabled;
      championshipInput.addEventListener("change", () => {
        if (!hasWriteAccessToGame(game)) return;
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({ championship: championshipInput.checked });
      });
      championshipCell.appendChild(championshipInput);

      const deleteCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-row-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.disabled = !writeEnabled;
      deleteButton.addEventListener("click", () => {
        if (!hasWriteAccessToGame(game)) return;
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).delete();
      });
      deleteCell.appendChild(deleteButton);

      tr.append(lpCell, playerCell, entryFeeCell, rebuyCell, payoutCell, profitCell, pointsCell, championshipCell, deleteCell);
      modalBody.appendChild(tr);
    });

    modalAddRowButton.disabled = !hasWriteAccessToGame(game);
    restoreFocusedAdminInputState(modalBody, focusState);
  };

  const synchronizeYearsFromGames = () => {
    const visibleGames = state.games.filter((game) => canAccessGame(game));
    state.years = normalizeYearList(visibleGames.map((game) => extractYearFromDate(game.gameDate)).filter((year) => Number.isInteger(year)));
    if (!state.selectedYear || !state.years.includes(state.selectedYear)) {
      state.selectedYear = state.years[0] ?? null;
    }
    saveSelectedGamesYear(state.selectedYear, selectedYearStorageKey);
    renderYears();
    renderGamesTable();
    renderSummaries();
  };

  window.addEventListener("user-games-access-updated", () => {
    synchronizeYearsFromGames();
  });

  db.collection(PLAYER_ACCESS_COLLECTION).doc(PLAYER_ACCESS_DOCUMENT).onSnapshot((snapshot) => {
    const players = Array.isArray(snapshot.data()?.players) ? snapshot.data().players : [];
    state.playerOptions = players
      .map((player, index) => ({
        id: typeof player?.id === "string" && player.id.trim() ? player.id.trim() : `player-${index + 1}`,
        name: normalizePlayerName(player?.name)
      }))
      .filter((player) => player.id && player.name);
    if (state.activeGameIdInModal) {
      renderModal(state.activeGameIdInModal);
    }
  });

  db.collection(gamesCollectionName).orderBy("createdAt", "asc").onSnapshot((snapshot) => {
    state.games = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    state.games.forEach((game) => {
      void clearLegacyNotesField({ firebaseApp, db, collectionName: gamesCollectionName, game });
    });

    const activeIds = new Set(state.games.map((game) => game.id));
    state.detailsUnsubscribers.forEach((unsubscribe, gameId) => {
      if (!activeIds.has(gameId)) {
        unsubscribe();
        state.detailsUnsubscribers.delete(gameId);
        state.detailsByGame.delete(gameId);
      }
    });
    state.confirmationUnsubscribers.forEach((unsubscribe, gameId) => {
      if (!activeIds.has(gameId)) {
        unsubscribe();
        state.confirmationUnsubscribers.delete(gameId);
        state.confirmationsByGame.delete(gameId);
      }
    });

    state.games.forEach((game) => {
      if (state.detailsUnsubscribers.has(game.id)) {
        return;
      }
      const unsubscribe = db.collection(gamesCollectionName).doc(game.id).collection(gameDetailsCollectionName).orderBy("createdAt", "asc").onSnapshot((rowSnapshot) => {
        state.detailsByGame.set(game.id, rowSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
        if (state.activeGameIdInModal === game.id) {
          renderModal(game.id);
        }
        renderGamesTable();
        renderSummaries();
      });
      state.detailsUnsubscribers.set(game.id, unsubscribe);

      const confirmationUnsubscribe = db.collection(gamesCollectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).onSnapshot((confirmationSnapshot) => {
        state.confirmationsByGame.set(game.id, confirmationSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
        if (state.activeGameIdInModal === game.id) {
          renderModal(game.id);
        }
        if (confirmationsStatusModal.isOpenFor(`${gamesCollectionName}:${game.id}`)) {
          openConfirmationsStatusModal(game.id);
        }
        renderGamesTable();
      });
      state.confirmationUnsubscribers.set(game.id, confirmationUnsubscribe);
    });

    synchronizeYearsFromGames();
  });

  addGameButton.addEventListener("click", async () => {
    if (!canWrite()) {
      status.textContent = "Zweryfikuj PIN do zakładki „Gry użytkowników”, aby dodawać gry.";
      return;
    }
    addGameButton.disabled = true;
    status.textContent = "Dodawanie gry...";
    try {
      const newGamePayload = getValidatedNewGamePayload({
        games: state.games,
        additionalPayload: {
          isClosed: false,
          preGameNotes: DEFAULT_GAME_NOTES_TEMPLATE,
          postGameNotes: "",
          createdAt: firebaseApp.firestore.FieldValue.serverTimestamp(),
          ...createGamePayload()
        }
      });

      if (!newGamePayload) {
        status.textContent = "Nie można utworzyć gry bez pól: Rodzaj gry, Data i Nazwa.";
        return;
      }

      await db.collection(gamesCollectionName).add(newGamePayload);
      status.textContent = `Dodano grę "${newGamePayload.name}" z datą ${newGamePayload.gameDate}.`;
    } catch (error) {
      status.textContent = "Nie udało się dodać gry użytkownika.";
    } finally {
      addGameButton.disabled = false;
    }
  });

  modalAddRowButton.addEventListener("click", async () => {
    if (!state.activeGameIdInModal || !canWrite()) {
      return;
    }
    const activeGame = state.games.find((game) => game.id === state.activeGameIdInModal);
    if (!activeGame || !hasWriteAccessToGame(activeGame)) {
      return;
    }
    await db.collection(gamesCollectionName).doc(state.activeGameIdInModal).collection(gameDetailsCollectionName).add({
      playerName: "",
      entryFee: "",
      rebuy: "",
      payout: "0",
      points: "",
      championship: false,
      createdAt: firebaseApp.firestore.FieldValue.serverTimestamp()
    });
  });

  if (modalEntryFeeBulkButton) {
    modalEntryFeeBulkButton.addEventListener("click", async () => {
      if (!canWrite()) {
        return;
      }
      if (!state.activeGameIdInModal) {
        status.textContent = "Otwórz szczegóły gry, aby zbiorczo ustawić wpisowe.";
        return;
      }
      const activeGame = state.games.find((game) => game.id === state.activeGameIdInModal);
      if (!activeGame || !hasWriteAccessToGame(activeGame)) {
        status.textContent = "Brak uprawnień do edycji tej gry.";
        return;
      }
      const promptValue = window.prompt("Podaj wartość wpisowego dla wszystkich graczy.", "0");
      if (promptValue === null) {
        return;
      }
      const normalized = sanitizeIntegerInput(promptValue);
      if (!normalized || normalized === "-") {
        status.textContent = "Podaj poprawną wartość liczbową wpisowego.";
        return;
      }
      const rows = state.detailsByGame.get(state.activeGameIdInModal) ?? [];
      await Promise.all(rows.map((row) => db.collection(gamesCollectionName)
        .doc(state.activeGameIdInModal)
        .collection(gameDetailsCollectionName)
        .doc(row.id)
        .update({ entryFee: normalized })));
      status.textContent = `Ustawiono wpisowe ${normalized} dla ${rows.length} wierszy.`;
    });
  }


  detailRebuyModalClose?.addEventListener("click", closeDetailRebuyModal);
  detailRebuyModal.addEventListener("click", (event) => {
    if (event.target === detailRebuyModal) {
      closeDetailRebuyModal();
    }
  });
  modalClose.addEventListener("click", closeModal);
  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && detailRebuyModal.classList.contains("is-visible")) {
      closeDetailRebuyModal();
      return;
    }
    if (event.key === "Escape" && modal.classList.contains("is-visible")) {
      closeModal();
    }
  });
};

const initAdminUserGames = () => {
  initUserGamesManager({
    yearsListSelector: "#adminUserGamesYearsList",
    addGameButtonSelector: "#adminUserGamesAddGame",
    gamesTableBodySelector: "#adminUserGamesTableBody",
    summariesContainerSelector: "#adminUserGamesSummaries",
    statusSelector: "#adminUserGamesStatus",
    modalSelector: "#userGameDetailsModal",
    modalMetaSelector: "#userGameDetailsMeta",
    modalBodySelector: "#userGameDetailsBody",
    modalEntryFeeBulkButtonSelector: "#userGameDetailsModal .game-entry-fee-bulk-button",
    modalCloseSelector: "#userGameDetailsClose",
    modalAddRowButtonSelector: "#userGameDetailsAddRow",
    selectedYearStorageKey: ADMIN_USER_GAMES_SELECTED_YEAR_STORAGE_KEY,
    canWrite: () => true,
    createGamePayload: () => ({
      createdByPlayerId: "admin",
      createdByPlayerName: "Administrator"
    })
  });
};

const initPlayerUserGames = () => {
  initUserGamesManager({
    yearsListSelector: "#userGamesYearsList",
    addGameButtonSelector: "#userGamesAddGame",
    gamesTableBodySelector: "#userGamesTableBody",
    summariesContainerSelector: "#userGamesSummaries",
    statusSelector: "#userGamesStatus",
    modalSelector: "#playerUserGameDetailsModal",
    modalMetaSelector: "#playerUserGameDetailsMeta",
    modalBodySelector: "#playerUserGameDetailsBody",
    modalEntryFeeBulkButtonSelector: "#playerUserGameDetailsModal .game-entry-fee-bulk-button",
    modalCloseSelector: "#playerUserGameDetailsClose",
    modalAddRowButtonSelector: "#playerUserGameDetailsAddRow",
    selectedYearStorageKey: USER_GAMES_SELECTED_YEAR_STORAGE_KEY,
    canWrite: () => {
      const player = getUserGamesVerifiedPlayer();
      return getUserGamesPinGateState() && Boolean(player) && isPlayerAllowedForTab(player, "userGamesTab");
    },
    canAccessGame: (game) => {
      const player = getUserGamesVerifiedPlayer();
      return isGameOwnedByPlayer(game, player);
    },
    canEditGame: (game) => {
      const player = getUserGamesVerifiedPlayer();
      return isGameOwnedByPlayer(game, player);
    },
    createGamePayload: () => {
      const player = getUserGamesVerifiedPlayer();
      return {
        createdByPlayerId: player?.id || "",
        createdByPlayerName: player?.name || "",
        createdByPlayerPin: player?.pin || ""
      };
    }
  });
};


const initAdminConfirmations = () => {
  const list = document.querySelector("#adminConfirmationsList");
  const status = document.querySelector("#adminConfirmationsStatus");
  const firebaseApp = getFirebaseApp();

  if (!list || !status) {
    return;
  }

  if (!firebaseApp) {
    status.textContent = "Uzupełnij konfigurację Firebase, aby zarządzać potwierdzeniami.";
    return;
  }

  const db = firebaseApp.firestore();
  const userGamesCollectionName = getUserGamesCollectionName();
  const gameDetailsCollectionName = getGameDetailsCollectionName();

  const refreshData = async (source = "default") => {
    list.innerHTML = "";
    status.textContent = source === "server" ? "Odświeżanie danych..." : "Pobieranie danych...";

    try {
      const games = await getActiveGamesForConfirmationsFromCollections(db, [userGamesCollectionName], source);

      if (!games.length) {
        status.textContent = "Brak aktywnych gier do potwierdzenia.";
        return;
      }

      for (const entry of games) {
        const { collectionName, game } = entry;
        const wrapper = document.createElement("section");
        wrapper.className = "admin-confirmation-game";

        const title = document.createElement("h4");
        title.textContent = game.name || "Bez nazwy";

        const meta = document.createElement("p");
        meta.className = "admin-confirmation-game-meta";
        meta.textContent = `Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`;

        const tableScroll = document.createElement("div");
        tableScroll.className = "admin-table-scroll";
        const table = document.createElement("table");
        table.className = "admin-data-table";
        table.innerHTML = `
          <thead>
            <tr>
              <th>Gracz</th>
              <th>Status</th>
              <th>Akcje</th>
            </tr>
          </thead>
        `;
        const tbody = document.createElement("tbody");

        const rowsSnapshot = await db.collection(collectionName).doc(game.id).collection(gameDetailsCollectionName).get(
          source === "default" ? undefined : { source }
        );
        const players = Array.from(rowsSnapshot.docs
          .reduce((map, doc) => {
            const rowData = doc.data() ?? {};
            const playerIdentifier = getRowPlayerIdentifier(rowData);
            if (!playerIdentifier || map.has(playerIdentifier)) {
              return map;
            }

            map.set(playerIdentifier, {
              identifier: playerIdentifier,
              playerId: typeof rowData.playerId === "string" ? rowData.playerId.trim() : "",
              playerName: normalizePlayerName(rowData.playerName)
            });
            return map;
          }, new Map())
          .values());

        if (!players.length) {
          const tr = document.createElement("tr");
          const td = document.createElement("td");
          td.colSpan = 3;
          td.textContent = "Brak zapisanych graczy.";
          tr.appendChild(td);
          tbody.appendChild(tr);
        } else {
          const confirmationSnapshot = await db.collection(collectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).get(
            source === "default" ? undefined : { source }
          );
          const confirmationsByIdentifier = new Map();
          confirmationSnapshot.docs.forEach((doc) => {
            const data = doc.data();
            const identifier = getRowPlayerIdentifier(data);
            if (identifier) {
              confirmationsByIdentifier.set(identifier, { ...data, id: doc.id });
            }
          });

          players.forEach((player) => {
            const tr = document.createElement("tr");
            const confirmation = confirmationsByIdentifier.get(player.identifier) ?? null;
            const confirmationDocId = player.playerId || confirmation?.id || player.playerName;
            if (confirmation?.confirmed) {
              tr.classList.add("confirmed-row");
            }

            const nameCell = document.createElement("td");
            nameCell.textContent = player.playerName || "-";

            const statusCell = document.createElement("td");
            statusCell.textContent = confirmation?.confirmed ? "Potwierdzono" : "Niepotwierdzono";

            const actionsCell = document.createElement("td");
            const actionsWrap = document.createElement("div");
            actionsWrap.className = "confirmations-actions";

            const confirmButton = document.createElement("button");
            confirmButton.type = "button";
            confirmButton.className = "primary";
            confirmButton.textContent = "Potwierdź";
            confirmButton.addEventListener("click", async () => {
              if (!confirmationDocId) {
                return;
              }
              await db.collection(collectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).doc(confirmationDocId).set({
                playerId: player.playerId || "",
                playerName: player.playerName,
                confirmed: true,
                updatedBy: "admin",
                updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
              }, { merge: true });
              tr.classList.add("confirmed-row");
              statusCell.textContent = "Potwierdzono";
              void synchronizeNextGamesConfirmations();
            });

            const cancelButton = document.createElement("button");
            cancelButton.type = "button";
            cancelButton.className = "danger";
            cancelButton.textContent = "Anuluj";
            cancelButton.addEventListener("click", async () => {
              if (!confirmationDocId) {
                return;
              }
              await db.collection(collectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).doc(confirmationDocId).set({
                playerId: player.playerId || "",
                playerName: player.playerName,
                confirmed: false,
                updatedBy: "admin",
                updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
              }, { merge: true });
              tr.classList.remove("confirmed-row");
              statusCell.textContent = "Niepotwierdzono";
              void synchronizeNextGamesConfirmations();
            });

            actionsWrap.append(confirmButton, cancelButton);
            actionsCell.appendChild(actionsWrap);
            tr.append(nameCell, statusCell, actionsCell);
            tbody.appendChild(tr);
          });
        }

        table.appendChild(tbody);
        tableScroll.appendChild(table);
        wrapper.append(title, meta, tableScroll);
        list.appendChild(wrapper);
      }

      status.textContent = `Załadowano ${games.length} aktywnych gier (UserGames).`;
    } catch (error) {
      status.textContent = "Nie udało się pobrać listy potwierdzeń.";
    }
  };

  void refreshData();
  registerAdminRefreshHandler("adminConfirmationsTab", async () => {
    await refreshData("server");
  });
};

const initUserTabs = () => {
  const tabButtons = document.querySelectorAll(".tab-button");
  const panels = document.querySelectorAll(".tab-panel");
  const zoneButtons = document.querySelectorAll(".player-zone-button");
  const zonePanels = document.querySelectorAll(".player-zone-panel");
  const zoneGate = document.querySelector("#playerZonePinGate");
  const zoneContent = document.querySelector("#playerZoneContent");
  const zoneStatus = document.querySelector("#playerZoneSectionsStatus");
  const zonePinInput = document.querySelector("#playerZonePinInput");
  const zonePinStatus = document.querySelector("#playerZonePinStatus");
  const zonePinSubmit = document.querySelector("#playerZonePinSubmit");
  const userPanelRefreshButton = document.querySelector("#userPanelRefresh");
  const userPanelRefreshStatus = document.querySelector("#userPanelRefreshStatus");

  if (!tabButtons.length) {
    return;
  }

  const syncPlayerZoneSectionAccess = (player) => {
    const hasSectionAccess = (sectionKey) => Boolean(player) && isPlayerAllowedForTab(player, sectionKey);

    const isZoneVerified = getPlayerZonePinGateState();
    setPinGateState(isZoneVerified && hasSectionAccess("nextGameTab"));
    setChatPinGateState(isZoneVerified && hasSectionAccess("chatTab"));
    setConfirmationsPinGateState(isZoneVerified && hasSectionAccess("confirmationsTab"));
    setUserGamesPinGateState(isZoneVerified && hasSectionAccess("userGamesTab"));
    setStatisticsPinGateState(isZoneVerified && hasSectionAccess("statsTab"));

    const playerId = player?.id || "";
    setChatVerifiedPlayerId(hasSectionAccess("chatTab") ? playerId : "");
    setConfirmationsVerifiedPlayerId(hasSectionAccess("confirmationsTab") ? playerId : "");
    setUserGamesVerifiedPlayerId(hasSectionAccess("userGamesTab") ? playerId : "");
    setStatisticsVerifiedPlayerId(hasSectionAccess("statsTab") ? playerId : "");

    if (hasSectionAccess("chatTab") && typeof chatState.startPlayerSubscription === "function") {
      chatState.startPlayerSubscription();
    }

    if (!hasSectionAccess("chatTab") && typeof chatState.stopPlayerSubscription === "function") {
      chatState.stopPlayerSubscription();
    }

    updatePinVisibility();
    updateChatVisibility();
    updateConfirmationsVisibility();
    updateUserGamesVisibility();
    window.dispatchEvent(new CustomEvent("user-games-access-updated"));
    synchronizeStatisticsAccessState();
  };

  const setActiveZoneSection = (target) => {
    zoneButtons.forEach((button) => {
      const isActive = button.getAttribute("data-zone-target") === target;
      button.classList.toggle("is-active", isActive);
    });
    zonePanels.forEach((panel) => {
      panel.classList.toggle("is-active", panel.id === target);
    });

    if (target === "chatTab") {
      scrollChatListsToBottom();
    }

    if (target === "confirmationsTab") {
      void refreshUserConfirmationsData("server");
    }
  };

  const renderPlayerZoneSections = () => {
    const player = getPlayerZoneVerifiedPlayer();
    const isZoneVerified = getPlayerZonePinGateState();
    const allowedButtons = [];

    zoneButtons.forEach((button) => {
      const target = button.getAttribute("data-zone-target") || "";
      const permissionKey = PLAYER_ZONE_SECTION_PERMISSION_MAP[target];
      const isAllowed = Boolean(player) && isZoneVerified && Boolean(permissionKey) && isPlayerAllowedForTab(player, permissionKey);
      button.style.display = isAllowed ? "block" : "none";
      if (isAllowed) {
        allowedButtons.push(button);
      }
    });

    if (!allowedButtons.length) {
      if (zoneStatus && isZoneVerified) {
        zoneStatus.textContent = "Brak uprawnień do sekcji w Strefie Gracza.";
      }
      setActiveZoneSection("");
      return;
    }

    if (zoneStatus) {
      zoneStatus.textContent = "";
    }

    const currentActive = Array.from(allowedButtons).find((button) => button.classList.contains("is-active"));
    const target = (currentActive || allowedButtons[0]).getAttribute("data-zone-target") || "";
    setActiveZoneSection(target);
  };

  const updatePlayerZoneVisibility = () => {
    if (!zoneGate || !zoneContent) {
      return;
    }
    const isVerified = getPlayerZonePinGateState();
    zoneGate.style.display = isVerified ? "none" : "block";
    zoneContent.classList.toggle("is-visible", isVerified);
    renderPlayerZoneSections();
  };

  if (zonePinInput && zonePinStatus && zonePinSubmit) {
    zonePinInput.addEventListener("input", () => {
      zonePinInput.value = sanitizePin(zonePinInput.value);
    });

    const verifyZonePin = () => {
      const pinValue = sanitizePin(zonePinInput.value);
      if (!isPinValid(pinValue)) {
        zonePinStatus.textContent = "Wpisz komplet 5 cyfr.";
        return;
      }
      const player = adminPlayersState.playerByPin.get(pinValue);
      if (player && isPlayerAllowedForTab(player, "playerZoneTab")) {
        setPlayerZonePinGateState(true);
        setPlayerZoneVerifiedPlayerId(player.id || "");
        syncPlayerZoneSectionAccess(player);
        zonePinStatus.textContent = `PIN poprawny. Witaj ${player.name || "graczu"}.`;
      } else {
        syncPlayerZoneSectionAccess(null);
        zonePinStatus.textContent = "Błędny PIN lub brak uprawnień do zakładki „Strefa Gracza”.";
      }
      updatePlayerZoneVisibility();
    };

    zonePinSubmit.addEventListener("click", verifyZonePin);
    zonePinInput.addEventListener("keydown", (event) => {
      if (event.key === "Enter") {
        verifyZonePin();
      }
    });
  }

  const setActiveTab = (target) => {
    if (!target) {
      return;
    }

    tabButtons.forEach((btn) => btn.classList.toggle("is-active", btn.getAttribute("data-target") === target));
    panels.forEach((panel) => panel.classList.toggle("is-active", panel.id === target));

    if (target === "playerZoneTab") {
      updatePlayerZoneVisibility();
    }
  };

  zoneButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const target = button.getAttribute("data-zone-target") || "";
      if (target) {
        setActiveZoneSection(target);
      }
    });
  });

  window.addEventListener(PLAYER_ACCESS_UPDATED_EVENT, () => {
    if (!getPlayerZonePinGateState()) {
      syncPlayerZoneSectionAccess(null);
      updatePlayerZoneVisibility();
      return;
    }

    const verifiedPlayer = getPlayerZoneVerifiedPlayer();
    syncPlayerZoneSectionAccess(verifiedPlayer);
    updatePlayerZoneVisibility();
  });

  if (!getPlayerZonePinGateState()) {
    syncPlayerZoneSectionAccess(null);
  } else {
    syncPlayerZoneSectionAccess(getPlayerZoneVerifiedPlayer());
  }

  setActiveTab("updatesTab");

  if (userPanelRefreshButton) {
    userPanelRefreshButton.addEventListener("click", async () => {
      const activePanel = document.querySelector(".tab-panel.is-active");
      const activeTabId = activePanel?.id;
      const activeZonePanel = document.querySelector(".player-zone-panel.is-active");
      const activeZoneTabId = activeZonePanel?.id;
      userPanelRefreshButton.disabled = true;
      if (userPanelRefreshStatus) {
        userPanelRefreshStatus.textContent = "Odświeżanie danych...";
      }

      const setUserRefreshStatus = (message) => {
        if (userPanelRefreshStatus) {
          userPanelRefreshStatus.textContent = message;
        }
      };

      try {
        if (activeTabId === "updatesTab") {
          const firebaseApp = getFirebaseApp();
          if (!firebaseApp) {
            setUserRefreshStatus("Brak połączenia z Firebase.");
            return;
          }
          await firebaseApp.firestore().collection(ADMIN_MESSAGES_COLLECTION).doc(ADMIN_MESSAGES_DOCUMENT).get({ source: "server" });
          setUserRefreshStatus("Aktualności zostały odświeżone.");
          return;
        }

        if (activeTabId === "rulesTab") {
          const firebaseApp = getFirebaseApp();
          if (!firebaseApp) {
            setUserRefreshStatus("Brak połączenia z Firebase.");
            return;
          }
          await firebaseApp.firestore().collection(PLAYER_ACCESS_COLLECTION).doc(RULES_DOCUMENT).get({ source: "server" });
          setUserRefreshStatus("Regulamin został odświeżony.");
          return;
        }

        if (activeTabId !== "playerZoneTab") {
          setUserRefreshStatus("Ta zakładka nie ma danych do odświeżenia.");
          return;
        }

        if (activeZoneTabId === "confirmationsTab") {
          await refreshUserConfirmationsData("server");
          setUserRefreshStatus("Potwierdzenia zostały odświeżone.");
          return;
        }

        if (activeZoneTabId === "statsTab") {
          synchronizeStatisticsAccessState();
          setUserRefreshStatus("Statystyki zostały odświeżone.");
          return;
        }

        if (activeZoneTabId === "chatTab") {
          if (typeof chatState.stopPlayerSubscription === "function") {
            chatState.stopPlayerSubscription();
          }
          if (typeof chatState.startPlayerSubscription === "function") {
            chatState.startPlayerSubscription();
          }
          setUserRefreshStatus("Czat został odświeżony.");
          return;
        }

        setUserRefreshStatus("Dane tej sekcji odświeżają się automatycznie.");
      } catch (error) {
        setUserRefreshStatus("Nie udało się odświeżyć danych.");
      } finally {
        userPanelRefreshButton.disabled = false;
      }
    });
  }

  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setActiveTab(button.getAttribute("data-target"));
    });
  });
};

const extractYearFromDate = (value) => {
  if (typeof value !== "string") {
    return null;
  }

  const yearMatches = value.match(/(?:19|20)\d{2}/g);
  if (!yearMatches || !yearMatches.length) {
    return null;
  }

  const yearValue = Number(yearMatches[yearMatches.length - 1]);
  return Number.isInteger(yearValue) ? yearValue : null;
};

const normalizeYearList = (years) => {
  if (!Array.isArray(years)) {
    return [];
  }

  const unique = new Set();
  years.forEach((year) => {
    const numericYear = Number(year);
    if (Number.isInteger(numericYear) && numericYear > 1900 && numericYear < 3000) {
      unique.add(numericYear);
    }
  });

  return Array.from(unique).sort((a, b) => b - a);
};

const normalizeStatsYearsAccess = (statsYearsAccess) => {
  return normalizeYearList(statsYearsAccess);
};

const normalizePlayerRecord = (player, index) => ({
  id: typeof player.id === "string" && player.id.trim() ? player.id.trim() : `player-${index + 1}`,
  name: typeof player.name === "string" ? player.name : "",
  pin: sanitizePin(typeof player.pin === "string" ? player.pin : ""),
  appEnabled: Boolean(player.appEnabled),
  permissions: Array.isArray(player.permissions)
    ? player.permissions.filter((permission) =>
        AVAILABLE_PLAYER_TABS.some((availableTab) => availableTab.key === permission)
      )
    : [],
  statsYearsAccess: normalizeStatsYearsAccess(player.statsYearsAccess)
});

const rebuildAdminPlayersPinMap = () => {
  const nextMap = new Map();
  adminPlayersState.players.forEach((player) => {
    if (isPinValid(player.pin) && !nextMap.has(player.pin)) {
      nextMap.set(player.pin, player);
    }
  });
  adminPlayersState.playerByPin = nextMap;
};

const initSharedPlayerAccess = () => {
  if (typeof sharedPlayerAccessUnsubscribe === "function") {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    return;
  }

  const db = firebaseApp.firestore();
  sharedPlayerAccessUnsubscribe = db.collection(PLAYER_ACCESS_COLLECTION)
    .doc(PLAYER_ACCESS_DOCUMENT)
    .onSnapshot((snapshot) => {
      if (isEditingSection(["players"]) || hasPendingDebounceWithPrefix("players:")) {
        return;
      }

      const rawPlayers = Array.isArray(snapshot.data()?.players) ? snapshot.data().players : [];
      adminPlayersState.players = rawPlayers.map(normalizePlayerRecord);
      rebuildAdminPlayersPinMap();
      synchronizeStatisticsAccessState();
      window.dispatchEvent(new CustomEvent(PLAYER_ACCESS_UPDATED_EVENT));
      window.dispatchEvent(new CustomEvent("statistics-access-updated"));
    });
};

const getAllowedStatisticsYearsForPlayer = (player, availableYears) => {
  const sourceYears = normalizeYearList(availableYears);
  if (!player || !isPlayerAllowedForTab(player, "statsTab")) {
    return [];
  }

  const allowedYears = normalizeStatsYearsAccess(player.statsYearsAccess);
  if (!allowedYears.length) {
    return [];
  }

  const allowedSet = new Set(allowedYears);
  return sourceYears.filter((year) => allowedSet.has(year));
};

const loadSavedSelectedGamesYear = (storageKey = ADMIN_GAMES_SELECTED_YEAR_STORAGE_KEY) => {
  const rawValue = Number(localStorage.getItem(storageKey));
  return Number.isInteger(rawValue) && rawValue > 1900 && rawValue < 3000 ? rawValue : null;
};

const saveSelectedGamesYear = (year, storageKey = ADMIN_GAMES_SELECTED_YEAR_STORAGE_KEY) => {
  if (!Number.isInteger(year) || year < 1900 || year > 2999) {
    localStorage.removeItem(storageKey);
    return;
  }
  localStorage.setItem(storageKey, String(year));
};

const initAdminPanelTabs = () => {
  const tabButtons = document.querySelectorAll(".admin-panel-tab");
  const tabPanels = document.querySelectorAll(".admin-panel-content");
  if (!tabButtons.length || !tabPanels.length) {
    return;
  }

  const setActiveTab = (target) => {
    tabButtons.forEach((button) => {
      button.classList.toggle("is-active", button.getAttribute("data-target") === target);
    });
    tabPanels.forEach((panel) => {
      panel.classList.toggle("is-active", panel.id === target);
    });

    if (target === "adminChatTab") {
      scrollChatListsToBottom();
    }
  };

  tabButtons.forEach((button) => {
    button.addEventListener("click", () => {
      setActiveTab(button.getAttribute("data-target"));
    });
  });
};


const initAdminCalculator = () => {
  const rootTable1 = document.querySelector("#adminCalculatorTable1");
  const rootTable2 = document.querySelector("#adminCalculatorTable2");
  const rootTable3 = document.querySelector("#adminCalculatorTable3");
  const rootTable4 = document.querySelector("#adminCalculatorTable4");
  const rootTable5 = document.querySelector("#adminCalculatorTable5");
  const status = document.querySelector("#adminCalculatorStatus");
  const calculatorContent = document.querySelector(".admin-calculator-content");
  const modeButtons = Array.from(document.querySelectorAll(".admin-calculator-switch-button"));

  if (!rootTable1 || !rootTable2 || !rootTable3 || !rootTable4 || !rootTable5 || !modeButtons.length) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  const CALCULATOR_COLLECTION = "calculators";
  const TOURNAMENT_MODES = new Set(["tournament1", "tournament2"]);
  const ORGANIZATION_MODE = "organization";
  const CHIPS_MODES = new Set(["chips-cash1", "chips-cash2", "chips-tournament1", "chips-tournament2"]);
  const ALL_CALCULATOR_MODES = ["tournament1", "tournament2", "cash", ORGANIZATION_MODE, ...CHIPS_MODES];

  const createInitialState = () => ({
    table1Row: { id: `table1-${Date.now()}-0`, buyIn: "", rebuy: "" },
    table2Rows: [{ id: `table2-${Date.now()}-0`, playerId: "", playerName: "", eliminated: false, rebuys: [], rebuyIndexes: [] }],
    table3Row: { percent: "" },
    table5SplitPercents: [],
    table5Mods: [],
    eliminatedOrder: []
  });

  const createInitialCashState = () => ({
    table8Row: { rake: "" },
    table9Rows: [{ id: `table9-${Date.now()}-0`, playerId: "", playerName: "", buyIn: "0", payout: "0", rebuys: [], rebuyIndexes: [] }]
  });

  const createInitialOrganizationState = () => ({
    table1: { percent: "", base: "" },
    table2Rows: [{ id: `org-table2-${Date.now()}-0`, percent: "" }]
  });

  const createInitialChipsState = () => ({
    tableAARows: [{ id: `chips-aa-${Date.now()}-0`, nominal: "", count: "" }],
    tableAB: { playersCount: "", playerStack: "" },
    tableACRows: [{ id: `chips-ac-${Date.now()}-0`, count: "" }]
  });

  const state = {
    mode: "tournament1",
    playerOptions: [],
    tournament1: createInitialState(),
    tournament2: createInitialState(),
    cash: createInitialCashState(),
    organization: createInitialOrganizationState(),
    "chips-cash1": createInitialChipsState(),
    "chips-cash2": createInitialChipsState(),
    "chips-tournament1": createInitialChipsState(),
    "chips-tournament2": createInitialChipsState(),
    rebuyModal: {
      mode: null,
      rowId: null
    }
  };

  const getModeState = () => state[state.mode];
  const getCalculatorDocId = (mode) => {
    if (mode === "tournament1") {
      return "tournament";
    }
    return mode;
  };
  const getCalculatorDocRef = (mode) => firebaseApp.firestore().collection(CALCULATOR_COLLECTION).doc(getCalculatorDocId(mode));
  const sanitizeInteger = (value) => String(value ?? "").replace(/[^0-9]/g, "");
  const sanitizeSignedInteger = (value) => {
    const normalized = String(value ?? "").replace(/\s+/g, "");
    const hasLeadingMinus = normalized.startsWith("-");
    const digits = normalized.replace(/\D/g, "");
    if (!digits) {
      return hasLeadingMinus ? "-" : "";
    }
    return `${hasLeadingMinus ? "-" : ""}${digits}`;
  };
  const parseInteger = (value) => {
    const normalized = sanitizeInteger(value);
    return normalized ? Number.parseInt(normalized, 10) : 0;
  };
  const parseSignedInteger = (value) => {
    const normalized = sanitizeSignedInteger(value);
    return normalized && normalized !== "-" ? Number.parseInt(normalized, 10) : 0;
  };
  const formatNumber = (value) => {
    const normalized = Number.isFinite(value) ? value : 0;
    return String(Math.ceil(normalized));
  };
  const formatPercentDisplay = (value) => {
    const normalized = sanitizeInteger(value);
    return normalized ? `${normalized}%` : "";
  };

  const normalizeRebuyIndexes = (rawIndexes, valuesLength) => {
    if (Array.isArray(rawIndexes) && rawIndexes.length === valuesLength) {
      return rawIndexes.map((value, index) => {
        const parsed = Number.parseInt(String(value ?? ""), 10);
        return Number.isInteger(parsed) && parsed > 0 ? parsed : index + 1;
      });
    }
    return Array.from({ length: valuesLength }, (_, index) => index + 1);
  };

  const normalizeCalculatorModeState = (mode, rawState) => {
    if (mode === ORGANIZATION_MODE) {
      const source = rawState && typeof rawState === "object" ? rawState : {};
      const table1 = source.table1 && typeof source.table1 === "object" ? source.table1 : {};
      const table2Rows = Array.isArray(source.table2Rows)
        ? source.table2Rows.map((row, index) => {
          const rowSource = row && typeof row === "object" ? row : {};
          return {
            id: typeof rowSource.id === "string" && rowSource.id.trim() ? rowSource.id.trim() : `org-table2-${Date.now()}-${index}`,
            percent: sanitizeInteger(rowSource.percent)
          };
        }).filter((row) => row.id)
        : [];
      return {
        table1: {
          percent: sanitizeInteger(table1.percent),
          base: sanitizeInteger(table1.base)
        },
        table2Rows: table2Rows.length ? table2Rows : [{ id: `org-table2-${Date.now()}-0`, percent: "" }]
      };
    }

    if (CHIPS_MODES.has(mode)) {
      const source = rawState && typeof rawState === "object" ? rawState : {};
      const tableAARows = Array.isArray(source.tableAARows)
        ? source.tableAARows.map((row, index) => {
          const rowSource = row && typeof row === "object" ? row : {};
          return {
            id: typeof rowSource.id === "string" && rowSource.id.trim() ? rowSource.id.trim() : `chips-aa-${Date.now()}-${index}`,
            nominal: sanitizeInteger(rowSource.nominal),
            count: sanitizeInteger(rowSource.count)
          };
        }).filter((row) => row.id)
        : [];
      const tableAB = source.tableAB && typeof source.tableAB === "object" ? source.tableAB : {};
      const tableACRows = Array.isArray(source.tableACRows)
        ? source.tableACRows.map((row, index) => {
          const rowSource = row && typeof row === "object" ? row : {};
          return {
            id: typeof rowSource.id === "string" && rowSource.id.trim() ? rowSource.id.trim() : `chips-ac-${Date.now()}-${index}`,
            count: sanitizeInteger(rowSource.count)
          };
        }).filter((row) => row.id)
        : [];
      return {
        tableAARows: tableAARows.length ? tableAARows : [{ id: `chips-aa-${Date.now()}-0`, nominal: "", count: "" }],
        tableAB: {
          playersCount: sanitizeInteger(tableAB.playersCount),
          playerStack: sanitizeInteger(tableAB.playerStack)
        },
        tableACRows: tableACRows.length ? tableACRows : [{ id: `chips-ac-${Date.now()}-0`, count: "" }]
      };
    }

    if (mode === "cash") {
      const baseCashState = createInitialCashState();
      const source = rawState && typeof rawState === "object" ? rawState : {};
      const table8Source = source.table8Row && typeof source.table8Row === "object" ? source.table8Row : {};

      const table9Rows = Array.isArray(source.table9Rows)
        ? source.table9Rows
          .map((row, index) => {
            const rowSource = row && typeof row === "object" ? row : {};
            const normalizedRebuys = Array.isArray(rowSource.rebuys)
              ? rowSource.rebuys.map((value) => sanitizeInteger(value))
              : [];
            return {
              id: typeof rowSource.id === "string" && rowSource.id.trim()
                ? rowSource.id.trim()
                : `table9-${Date.now()}-${index}`,
              playerId: typeof rowSource.playerId === "string" ? rowSource.playerId : "",
              playerName: typeof rowSource.playerName === "string" ? rowSource.playerName : "",
              buyIn: sanitizeInteger(rowSource.buyIn),
              payout: sanitizeInteger(rowSource.payout),
              rebuys: normalizedRebuys,
              rebuyIndexes: normalizeRebuyIndexes(rowSource.rebuyIndexes, normalizedRebuys.length)
            };
          })
          .filter((row) => row.id)
        : [];

      return {
        table8Row: {
          rake: sanitizeInteger(table8Source.rake)
        },
        table9Rows: table9Rows.length ? table9Rows : baseCashState.table9Rows
      };
    }

    const baseState = createInitialState();
    const source = rawState && typeof rawState === "object" ? rawState : {};
    const table1Source = source.table1Row && typeof source.table1Row === "object" ? source.table1Row : {};
    const table3Source = source.table3Row && typeof source.table3Row === "object" ? source.table3Row : {};

    const table2Rows = Array.isArray(source.table2Rows)
      ? source.table2Rows
        .map((row, index) => {
          const rowSource = row && typeof row === "object" ? row : {};
          const normalizedRebuys = Array.isArray(rowSource.rebuys)
            ? rowSource.rebuys.map((value) => sanitizeInteger(value))
            : [];
          return {
            id: typeof rowSource.id === "string" && rowSource.id.trim()
              ? rowSource.id.trim()
              : `table2-${Date.now()}-${index}`,
            playerId: typeof rowSource.playerId === "string" ? rowSource.playerId : "",
            playerName: typeof rowSource.playerName === "string" ? rowSource.playerName : "",
            eliminated: Boolean(rowSource.eliminated),
            rebuys: normalizedRebuys,
            rebuyIndexes: normalizeRebuyIndexes(rowSource.rebuyIndexes, normalizedRebuys.length)
          };
        })
        .filter((row) => row.id)
      : [];

    const ensuredTable2Rows = table2Rows.length ? table2Rows : baseState.table2Rows;
    const validIds = new Set(ensuredTable2Rows.map((row) => row.id));

    return {
      table1Row: {
        id: baseState.table1Row.id,
        buyIn: sanitizeInteger(table1Source.buyIn),
        rebuy: sanitizeInteger(table1Source.rebuy)
      },
      table2Rows: ensuredTable2Rows,
      table3Row: {
        percent: sanitizeInteger(table3Source.percent)
      },
      table5SplitPercents: Array.isArray(source.table5SplitPercents)
        ? source.table5SplitPercents.map((value) => sanitizeInteger(value))
        : [],
      table5Mods: Array.isArray(source.table5Mods)
        ? source.table5Mods.map((value) => sanitizeSignedInteger(value))
        : [],
      eliminatedOrder: Array.isArray(source.eliminatedOrder)
        ? source.eliminatedOrder.filter((id) => typeof id === "string" && validIds.has(id))
        : []
    };
  };

  const serializeCalculatorModeState = (mode, modeState) => {
    if (mode === ORGANIZATION_MODE) {
      return {
        table1: {
          percent: sanitizeInteger(modeState.table1?.percent),
          base: sanitizeInteger(modeState.table1?.base)
        },
        table2Rows: Array.isArray(modeState.table2Rows)
          ? modeState.table2Rows.map((row, index) => ({
            id: typeof row.id === "string" && row.id.trim() ? row.id.trim() : `org-table2-${Date.now()}-${index}`,
            percent: sanitizeInteger(row.percent)
          }))
          : []
      };
    }

    if (CHIPS_MODES.has(mode)) {
      return {
        tableAARows: Array.isArray(modeState.tableAARows)
          ? modeState.tableAARows.map((row, index) => ({
            id: typeof row.id === "string" && row.id.trim() ? row.id.trim() : `chips-aa-${Date.now()}-${index}`,
            nominal: sanitizeInteger(row.nominal),
            count: sanitizeInteger(row.count)
          }))
          : [],
        tableAB: {
          playersCount: sanitizeInteger(modeState.tableAB?.playersCount),
          playerStack: sanitizeInteger(modeState.tableAB?.playerStack)
        },
        tableACRows: Array.isArray(modeState.tableACRows)
          ? modeState.tableACRows.map((row, index) => ({
            id: typeof row.id === "string" && row.id.trim() ? row.id.trim() : `chips-ac-${Date.now()}-${index}`,
            count: sanitizeInteger(row.count)
          }))
          : []
      };
    }

    if (mode === "cash") {
      return {
        table8Row: {
          rake: sanitizeInteger(modeState.table8Row?.rake)
        },
        table9Rows: Array.isArray(modeState.table9Rows)
          ? modeState.table9Rows.map((row, index) => ({
            id: typeof row.id === "string" && row.id.trim() ? row.id.trim() : `table9-${Date.now()}-${index}`,
            playerId: typeof row.playerId === "string" ? row.playerId : "",
            playerName: typeof row.playerName === "string" ? row.playerName : "",
            buyIn: sanitizeInteger(row.buyIn),
            payout: sanitizeInteger(row.payout),
            rebuys: Array.isArray(row.rebuys) ? row.rebuys.map((value) => sanitizeInteger(value)) : [],
            rebuyIndexes: normalizeRebuyIndexes(row.rebuyIndexes, Array.isArray(row.rebuys) ? row.rebuys.length : 0)
          }))
          : []
      };
    }

    return {
      table1Row: {
        buyIn: sanitizeInteger(modeState.table1Row.buyIn),
        rebuy: sanitizeInteger(modeState.table1Row.rebuy)
      },
      table2Rows: modeState.table2Rows.map((row, index) => ({
        id: typeof row.id === "string" && row.id.trim() ? row.id.trim() : `table2-${Date.now()}-${index}`,
        playerId: typeof row.playerId === "string" ? row.playerId : "",
        playerName: typeof row.playerName === "string" ? row.playerName : "",
        eliminated: Boolean(row.eliminated),
        rebuys: Array.isArray(row.rebuys) ? row.rebuys.map((value) => sanitizeInteger(value)) : [],
        rebuyIndexes: normalizeRebuyIndexes(row.rebuyIndexes, Array.isArray(row.rebuys) ? row.rebuys.length : 0)
      })),
      table3Row: {
        percent: sanitizeInteger(modeState.table3Row.percent)
      },
      table5SplitPercents: Array.isArray(modeState.table5SplitPercents)
        ? modeState.table5SplitPercents.map((value) => sanitizeInteger(value))
        : [],
      table5Mods: Array.isArray(modeState.table5Mods)
        ? modeState.table5Mods.map((value) => sanitizeSignedInteger(value))
        : [],
      eliminatedOrder: Array.isArray(modeState.eliminatedOrder)
        ? modeState.eliminatedOrder.filter((id) => typeof id === "string")
        : []
    };
  };

  const persistCalculatorModeState = (mode) => {
    if (!firebaseApp || !ALL_CALCULATOR_MODES.includes(mode)) {
      return Promise.resolve();
    }

    const modeState = mode === "cash" ? state.cash : state[mode];
    const payload = serializeCalculatorModeState(mode, modeState);
    return getCalculatorDocRef(mode).set({
      ...payload,
      updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
    }, { merge: true });
  };

  const schedulePersistCalculatorModeState = (mode) => {
    scheduleDebouncedUpdate(`admin-calculator-${mode}`, () => {
      void persistCalculatorModeState(mode).catch(() => {
        if (status) {
          status.textContent = "Nie udało się zapisać danych kalkulatora.";
        }
      });
    });
  };

  const createHeader = (title) => {
    const heading = document.createElement("h4");
    heading.textContent = title;
    return heading;
  };

  const createScroll = () => {
    const scroll = document.createElement("div");
    scroll.className = "admin-table-scroll";
    return scroll;
  };

  const createReadonlyCell = (value) => {
    const td = document.createElement("td");
    const input = document.createElement("input");
    input.type = "text";
    input.className = "admin-input";
    input.value = value;
    input.disabled = true;
    td.appendChild(input);
    return td;
  };

  const getModalModeState = () => {
    if (state.rebuyModal.mode === "cash") {
      return state.cash;
    }
    if (TOURNAMENT_MODES.has(state.rebuyModal.mode)) {
      return state[state.rebuyModal.mode];
    }
    return null;
  };

  const getRebuyRowsForMode = (modeState, mode) => (mode === "cash" ? modeState.table9Rows : modeState.table2Rows);

  const getRebuyRow = () => {
    const modeState = getModalModeState();
    if (!modeState || !state.rebuyModal.rowId) {
      return null;
    }
    const rows = getRebuyRowsForMode(modeState, state.rebuyModal.mode);
    return rows.find((row) => row.id === state.rebuyModal.rowId) ?? null;
  };

  const ensureRowRebuyIndexes = (row) => {
    row.rebuys = Array.isArray(row.rebuys) ? row.rebuys : [];
    row.rebuyIndexes = normalizeRebuyIndexes(row.rebuyIndexes, row.rebuys.length);
    if (row.rebuyIndexes.length !== row.rebuys.length) {
      row.rebuyIndexes = normalizeRebuyIndexes([], row.rebuys.length);
    }
    return row.rebuyIndexes;
  };

  const ensureModeRebuyIndexes = (modeState, mode) => {
    const rows = getRebuyRowsForMode(modeState, mode);
    rows.forEach((row) => {
      ensureRowRebuyIndexes(row);
    });
  };

  const getAllRebuyEntriesForMode = (modeState, mode) => {
    ensureModeRebuyIndexes(modeState, mode);
    return getRebuyRowsForMode(modeState, mode)
      .flatMap((row) => row.rebuys.map((value, index) => ({
        rowId: row.id,
        index: row.rebuyIndexes[index],
        value: sanitizeInteger(value)
      })))
      .filter((entry) => Number.isInteger(entry.index) && entry.index > 0)
      .sort((a, b) => a.index - b.index);
  };

  const getNextGlobalRebuyIndex = (modeState, mode) => {
    const entries = getAllRebuyEntriesForMode(modeState, mode);
    const maxIndex = entries.reduce((max, entry) => Math.max(max, entry.index), 0);
    return maxIndex + 1;
  };

  const compactRebuyIndexesAfterRemoval = (modeState, mode, removedIndex) => {
    if (!Number.isInteger(removedIndex) || removedIndex <= 0) {
      return;
    }
    const rows = getRebuyRowsForMode(modeState, mode);
    rows.forEach((row) => {
      ensureRowRebuyIndexes(row);
      row.rebuyIndexes = row.rebuyIndexes.map((index) => (index > removedIndex ? index - 1 : index));
    });
  };

  const getRowRebuySum = (row) => {
    ensureRowRebuyIndexes(row);
    return row.rebuys.reduce((sum, value) => sum + parseInteger(value), 0);
  };
  const getRowRebuyCount = (row) => {
    ensureRowRebuyIndexes(row);
    return row.rebuys.filter((value) => sanitizeInteger(value) !== "").length;
  };

  const getCalculatorMetrics = () => {
    const modeState = getModeState();
    const buyInValue = parseInteger(modeState.table1Row.buyIn);
    const totalBuyIn = modeState.table2Rows.reduce((sum) => sum + buyInValue, 0);
    const totalRebuy = modeState.table2Rows.reduce((sum, row) => sum + getRowRebuySum(row), 0);
    const rebuyEntriesCount = modeState.table2Rows.reduce((count, row) => count + getRowRebuyCount(row), 0);
    const sumValue = totalBuyIn + totalRebuy;
    const percentValue = parseInteger(modeState.table3Row.percent);
    const percentDecimal = percentValue / 100;
    const rake = sumValue * percentDecimal;
    const entryFee = totalBuyIn - (totalBuyIn * percentDecimal);
    const rebuyAfterRake = totalRebuy - (totalRebuy * percentDecimal);
    const pot = entryFee + rebuyAfterRake;

    return {
      buyInValue,
      totalBuyIn,
      totalRebuy,
      rebuyEntriesCount,
      sumValue,
      percentValue,
      percentDecimal,
      rake,
      entryFee,
      rebuyAfterRake,
      pot
    };
  };

  const getDefaultPrizeSplitPercent = (index) => {
    if (index === 0) {
      return "50";
    }
    if (index === 1) {
      return "30";
    }
    if (index === 2) {
      return "20";
    }
    return "";
  };

  const syncTable5ConfigWithRows = (modeState) => {
    if (!modeState || !Array.isArray(modeState.table2Rows)) {
      return;
    }

    const targetLength = modeState.table2Rows.length;
    const currentPercents = Array.isArray(modeState.table5SplitPercents) ? modeState.table5SplitPercents : [];
    const currentMods = Array.isArray(modeState.table5Mods) ? modeState.table5Mods : [];

    modeState.table5SplitPercents = Array.from({ length: targetLength }, (_, index) => {
      const normalizedValue = sanitizeInteger(currentPercents[index]);
      return normalizedValue !== "" ? normalizedValue : getDefaultPrizeSplitPercent(index);
    });

    modeState.table5Mods = Array.from({ length: targetLength }, (_, index) => sanitizeSignedInteger(currentMods[index]));
  };

  const getTable5SplitPercentValue = (modeState, index) => {
    syncTable5ConfigWithRows(modeState);
    const rawValue = sanitizeInteger(modeState.table5SplitPercents[index]);
    return rawValue;
  };

  const getTable5ModValue = (modeState, index) => sanitizeSignedInteger(modeState.table5Mods[index]);

  const getVisibleGlobalRebuyValues = (modeState, percentDecimal) => getAllRebuyEntriesForMode(modeState, state.mode)
    .filter((entry) => entry.value !== "")
    .map((entry) => {
      const rebuyValue = parseInteger(entry.value);
      return rebuyValue - (rebuyValue * percentDecimal);
    });

  const getTable5TargetLpForRebuyColumn = (columnIndex) => {
    let remaining = columnIndex;
    let groupSize = 4;

    while (remaining > groupSize) {
      remaining -= groupSize;
      groupSize += 1;
    }

    return remaining;
  };

  const getTable5Rows = () => {
    const modeState = getModeState();
    syncTable5ConfigWithRows(modeState);
    const metrics = getCalculatorMetrics();
    const visibleRebuyValues = getVisibleGlobalRebuyValues(modeState, metrics.percentDecimal);
    return modeState.table2Rows.map((row, index) => {
      const splitPercent = parseInteger(getTable5SplitPercentValue(modeState, index));
      const amount = metrics.entryFee * (splitPercent / 100);
      const rebuyValues = visibleRebuyValues.map((value, rebuyIndex) => (
        getTable5TargetLpForRebuyColumn(rebuyIndex + 1) === index + 1 ? value : null
      ));
      const rebuySum = rebuyValues.reduce((sum, value) => sum + value, 0);
      const modValue = parseSignedInteger(getTable5ModValue(modeState, index));
      return {
        id: row.id,
        lp: index + 1,
        playerName: row.playerName,
        splitPercent,
        amount,
        rebuyValues,
        rebuySum,
        modValue,
        total: amount + rebuySum + modValue
      };
    });
  };

  const getTable4Rows = () => {
    const modeState = getModeState();
    const table5Rows = getTable5Rows();
    const rowById = new Map(modeState.table2Rows.map((row) => [row.id, row]));
    const activeEliminatedIds = modeState.table2Rows
      .filter((row) => row.eliminated)
      .map((row) => row.id);
    const orderedEliminatedIds = modeState.eliminatedOrder
      .filter((id) => activeEliminatedIds.includes(id));

    activeEliminatedIds.forEach((id) => {
      if (!orderedEliminatedIds.includes(id)) {
        orderedEliminatedIds.push(id);
      }
    });

    const playerNameByLp = new Map();
    orderedEliminatedIds.forEach((id, index) => {
      const lp = modeState.table2Rows.length - index;
      const row = rowById.get(id);
      if (lp > 0 && row) {
        playerNameByLp.set(lp, row.playerName);
      }
    });

    return modeState.table2Rows.map((row, index) => {
      const lp = index + 1;
      return {
        id: row.id,
        lp,
        playerName: playerNameByLp.get(lp) ?? "",
        win: table5Rows[index]?.total ?? 0
      };
    });
  };


  const getCashMetrics = () => {
    const cashState = state.cash;
    const totalBuyIn = cashState.table9Rows.reduce((sum, row) => sum + parseInteger(row.buyIn), 0);
    const totalRebuy = cashState.table9Rows.reduce((sum, row) => sum + getRowRebuySum(row), 0);
    const rakePercent = parseInteger(cashState.table8Row.rake);
    const rakeDecimal = rakePercent / 100;
    const totalBeforeRake = totalBuyIn + totalRebuy;
    const rakeValue = totalBeforeRake * rakeDecimal;
    const buyInAfterPercent = totalBuyIn * (1 - rakeDecimal);
    const rebuyAfterPercent = totalRebuy * (1 - rakeDecimal);
    const totalAfterPercent = buyInAfterPercent + rebuyAfterPercent;
    const pot = totalAfterPercent;

    return {
      totalBuyIn,
      totalRebuy,
      rakePercent,
      rakeDecimal,
      buyInAfterPercent,
      rebuyAfterPercent,
      totalAfterPercent,
      rakeValue,
      pot
    };
  };

  const getCashTable10Rows = () => {
    const metrics = getCashMetrics();
    const sumValue = metrics.totalAfterPercent;
    return state.cash.table9Rows
      .map((row) => {
        const payout = parseInteger(row.payout);
        const rebuy = getRowRebuySum(row);
        const buyIn = parseInteger(row.buyIn);
        const plusMinus = payout - (buyIn + rebuy);
        const poolPercent = sumValue > 0 ? (payout / sumValue) * 100 : 0;
        return {
          playerName: row.playerName,
          payout,
          plusMinus,
          poolPercent
        };
      })
      .sort((a, b) => {
        if (b.plusMinus !== a.plusMinus) {
          return b.plusMinus - a.plusMinus;
        }
        return String(a.playerName).localeCompare(String(b.playerName), "pl");
      });
  };

  const rebuyModal = document.createElement("div");
  rebuyModal.id = "adminCalculatorRebuyModal";
  rebuyModal.className = "modal-overlay";
  rebuyModal.setAttribute("aria-hidden", "true");
  rebuyModal.innerHTML = `
    <div class="modal-card modal-card-sm" role="dialog" aria-modal="true" aria-labelledby="adminCalculatorRebuyTitle">
      <div class="modal-header">
        <h3 id="adminCalculatorRebuyTitle">Rebuy gracza</h3>
        <button type="button" class="icon-button" id="adminCalculatorRebuyClose" aria-label="Zamknij okno">×</button>
      </div>
      <div class="modal-body">
        <div class="admin-table-scroll">
          <table class="admin-data-table" id="adminCalculatorRebuyTable"></table>
        </div>
        <div class="admin-table-actions" id="adminCalculatorRebuyActions"></div>
      </div>
    </div>
  `;
  document.body.appendChild(rebuyModal);

  const rebuyModalCloseButton = rebuyModal.querySelector("#adminCalculatorRebuyClose");
  const rebuyModalTable = rebuyModal.querySelector("#adminCalculatorRebuyTable");
  const rebuyModalActions = rebuyModal.querySelector("#adminCalculatorRebuyActions");

  const closeRebuyModal = () => {
    state.rebuyModal.mode = null;
    state.rebuyModal.rowId = null;
    rebuyModal.classList.remove("is-visible");
    rebuyModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const renderRebuyModal = () => {
    const row = getRebuyRow();
    if (!row || !rebuyModalTable || !rebuyModalActions) {
      closeRebuyModal();
      return;
    }

    const focusState = getFocusedAdminInputState(rebuyModal);

    const modeState = state.rebuyModal.mode === "cash" ? state.cash : state[state.rebuyModal.mode];
    ensureModeRebuyIndexes(modeState, state.rebuyModal.mode);
    ensureRowRebuyIndexes(row);

    let headerHtml = "<thead><tr>";
    row.rebuys.forEach((_, index) => {
      headerHtml += `<th>Rebuy${row.rebuyIndexes[index]}</th>`;
    });
    headerHtml += "</tr></thead>";
    rebuyModalTable.innerHTML = headerHtml;

    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");
    row.rebuys.forEach((value, index) => {
      const td = document.createElement("td");
      const input = document.createElement("input");
      applyIntegerInputHints(input);
      input.className = "admin-input";
      input.value = value;
      input.dataset.focusTarget = "admin-calculator-rebuy-modal";
      input.dataset.section = "rebuy-modal";
      input.dataset.tableId = state.rebuyModal.mode ?? state.mode;
      input.dataset.rowId = row.id;
      input.dataset.columnKey = `rebuy${index}`;
      input.addEventListener("input", () => {
        row.rebuys[index] = sanitizeInteger(input.value);
        input.value = row.rebuys[index];
        render();
        schedulePersistCalculatorModeState(state.rebuyModal.mode ?? state.mode);
      });
      td.appendChild(input);
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
    rebuyModalTable.appendChild(tbody);

    rebuyModalActions.innerHTML = "";

    const addButton = document.createElement("button");
    addButton.type = "button";
    addButton.className = "secondary";
    addButton.textContent = "Dodaj Rebuy";
    addButton.addEventListener("click", () => {
      const nextIndex = getNextGlobalRebuyIndex(modeState, state.rebuyModal.mode);
      row.rebuys.push("");
      row.rebuyIndexes.push(nextIndex);
      renderRebuyModal();
      render();
      schedulePersistCalculatorModeState(state.rebuyModal.mode ?? state.mode);
    });

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "danger admin-row-delete";
    removeButton.textContent = "Usuń Rebuy";
    removeButton.disabled = row.rebuys.length === 0;
    removeButton.addEventListener("click", () => {
      if (row.rebuys.length === 0) {
        return;
      }
      const removedIndex = row.rebuyIndexes.pop();
      row.rebuys.pop();
      compactRebuyIndexesAfterRemoval(modeState, state.rebuyModal.mode, removedIndex);
      renderRebuyModal();
      render();
      schedulePersistCalculatorModeState(state.rebuyModal.mode ?? state.mode);
    });

    rebuyModalActions.append(addButton, removeButton);

    restoreFocusedAdminInputState(rebuyModal, focusState);
  };

  const openRebuyModal = (rowId) => {
    state.rebuyModal.mode = state.rebuyModal.mode ?? state.mode;
    state.rebuyModal.rowId = rowId;
    rebuyModal.classList.add("is-visible");
    rebuyModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    renderRebuyModal();
  };

  rebuyModalCloseButton?.addEventListener("click", closeRebuyModal);
  rebuyModal.addEventListener("click", (event) => {
    if (event.target === rebuyModal) {
      closeRebuyModal();
    }
  });
  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && rebuyModal.classList.contains("is-visible")) {
      closeRebuyModal();
    }
  });

  const renderTable1 = () => {
    const modeState = getModeState();
    const metrics = getCalculatorMetrics();
    rootTable1.innerHTML = "";
    rootTable1.appendChild(createHeader("Tabela1"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-table1";
    table.innerHTML = `<thead><tr><th>Suma</th><th>Buy-In</th><th>Rebuy</th><th>Liczba Rebuy</th></tr></thead>`;
    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");

    tr.appendChild(createReadonlyCell(formatNumber(metrics.sumValue)));

    const buyInCell = document.createElement("td");
    const buyInInput = document.createElement("input");
    buyInInput.type = "text";
    buyInInput.className = "admin-input";
    buyInInput.value = modeState.table1Row.buyIn;
    buyInInput.dataset.focusTarget = "admin-calculator";
    buyInInput.dataset.section = "table1";
    buyInInput.dataset.tableId = state.mode;
    buyInInput.dataset.rowId = modeState.table1Row.id;
    buyInInput.dataset.columnKey = "buyIn";
    buyInInput.addEventListener("input", () => {
      modeState.table1Row.buyIn = sanitizeInteger(buyInInput.value);
      buyInInput.value = modeState.table1Row.buyIn;
      render();
      schedulePersistCalculatorModeState(state.mode);
    });
    buyInCell.appendChild(buyInInput);

    const rebuyCell = document.createElement("td");
    const rebuyInput = document.createElement("input");
    rebuyInput.type = "text";
    rebuyInput.className = "admin-input";
    rebuyInput.value = modeState.table1Row.rebuy;
    rebuyInput.dataset.focusTarget = "admin-calculator";
    rebuyInput.dataset.section = "table1";
    rebuyInput.dataset.tableId = state.mode;
    rebuyInput.dataset.rowId = modeState.table1Row.id;
    rebuyInput.dataset.columnKey = "rebuy";
    rebuyInput.addEventListener("input", () => {
      modeState.table1Row.rebuy = sanitizeInteger(rebuyInput.value);
      rebuyInput.value = modeState.table1Row.rebuy;
      render();
      schedulePersistCalculatorModeState(state.mode);
    });
    rebuyCell.appendChild(rebuyInput);

    tr.append(buyInCell, rebuyCell, createReadonlyCell(formatNumber(metrics.rebuyEntriesCount)));
    tbody.appendChild(tr);

    table.appendChild(tbody);
    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable1.appendChild(scroll);
  };

  const updateEliminatedOrder = (modeState, row, eliminatedChecked) => {
    const nextOrder = modeState.eliminatedOrder.filter((id) => id !== row.id);
    if (eliminatedChecked) {
      nextOrder.push(row.id);
    }
    modeState.eliminatedOrder = nextOrder;
  };

  const renderTable2 = () => {
    const modeState = getModeState();
    const metrics = getCalculatorMetrics();
    rootTable2.innerHTML = "";
    rootTable2.appendChild(createHeader("Tabela2"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-table2";
    table.innerHTML = `<thead><tr><th>LP</th><th>Gracz</th><th>Buy-In</th><th>Rebuy</th><th>Eliminated</th><th></th></tr></thead>`;
    const tbody = document.createElement("tbody");

    modeState.table2Rows.forEach((row, index) => {
      const tr = document.createElement("tr");
      const lpCell = document.createElement("td");
      lpCell.textContent = String(index + 1);

      const playerCell = document.createElement("td");
      const playerSelect = document.createElement("select");
      playerSelect.className = "admin-input";
      const defaultOption = document.createElement("option");
      defaultOption.value = "";
      defaultOption.textContent = "Wybierz gracza";
      playerSelect.appendChild(defaultOption);
      const currentIdentifier = row.playerId ? `id:${row.playerId}` : (row.playerName ? `name:${row.playerName}` : "");
      const availablePlayers = getAvailablePlayersForRow(modeState.table2Rows, row.id, state.playerOptions, currentIdentifier);
      availablePlayers.forEach((player) => {
        const option = document.createElement("option");
        option.value = player.id;
        option.textContent = player.name;
        playerSelect.appendChild(option);
      });
      playerSelect.value = row.playerId;
      playerSelect.dataset.focusTarget = "admin-calculator";
      playerSelect.dataset.section = "table2";
      playerSelect.dataset.tableId = state.mode;
      playerSelect.dataset.rowId = row.id;
      playerSelect.dataset.columnKey = "playerId";
      playerSelect.addEventListener("change", () => {
        const selectedPlayer = state.playerOptions.find((player) => player.id === playerSelect.value) ?? null;
        row.playerId = selectedPlayer?.id ?? "";
        row.playerName = selectedPlayer?.name ?? "";
        render();
        schedulePersistCalculatorModeState(state.mode);
      });
      playerCell.appendChild(playerSelect);

      const rebuyCell = document.createElement("td");
      const rebuyButton = document.createElement("button");
      rebuyButton.type = "button";
      rebuyButton.className = "secondary";
      rebuyButton.textContent = formatNumber(getRowRebuySum(row));
      rebuyButton.addEventListener("click", () => openRebuyModal(row.id));
      rebuyCell.appendChild(rebuyButton);

      const eliminatedCell = document.createElement("td");
      const eliminatedCheckbox = document.createElement("input");
      eliminatedCheckbox.type = "checkbox";
      eliminatedCheckbox.checked = Boolean(row.eliminated);
      eliminatedCheckbox.dataset.focusTarget = "admin-calculator";
      eliminatedCheckbox.dataset.section = "table2";
      eliminatedCheckbox.dataset.tableId = state.mode;
      eliminatedCheckbox.dataset.rowId = row.id;
      eliminatedCheckbox.dataset.columnKey = "eliminated";
      eliminatedCheckbox.addEventListener("change", () => {
        row.eliminated = eliminatedCheckbox.checked;
        updateEliminatedOrder(modeState, row, row.eliminated);
        render();
        schedulePersistCalculatorModeState(state.mode);
      });
      eliminatedCell.appendChild(eliminatedCheckbox);

      const actionsCell = document.createElement("td");
      const actionsWrap = document.createElement("div");
      actionsWrap.className = "admin-table-actions";

      if (index === modeState.table2Rows.length - 1) {
        const addButton = document.createElement("button");
        addButton.type = "button";
        addButton.className = "secondary";
        addButton.textContent = "Dodaj";
        addButton.addEventListener("click", () => {
          modeState.table2Rows.push({
            id: `table2-${Date.now()}-${modeState.table2Rows.length}`,
            playerId: "",
            playerName: "",
            eliminated: false,
            rebuys: [],
            rebuyIndexes: []
          });
          render();
          schedulePersistCalculatorModeState(state.mode);
        });
        actionsWrap.appendChild(addButton);
      }

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-row-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.disabled = modeState.table2Rows.length === 1;
      deleteButton.addEventListener("click", () => {
        modeState.table2Rows = modeState.table2Rows.filter((entry) => entry.id !== row.id);
        modeState.eliminatedOrder = modeState.eliminatedOrder.filter((id) => id !== row.id);
        if (!modeState.table2Rows.length) {
          modeState.table2Rows.push({ id: `table2-${Date.now()}-0`, playerId: "", playerName: "", eliminated: false, rebuys: [], rebuyIndexes: [] });
        }
        render();
        schedulePersistCalculatorModeState(state.mode);
      });
      actionsWrap.appendChild(deleteButton);
      actionsCell.appendChild(actionsWrap);

      tr.append(lpCell, playerCell, createReadonlyCell(formatNumber(metrics.buyInValue)), rebuyCell, eliminatedCell, actionsCell);
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable2.appendChild(scroll);
  };

  const renderTable3 = () => {
    const modeState = getModeState();
    const metrics = getCalculatorMetrics();
    rootTable3.innerHTML = "";
    rootTable3.appendChild(createHeader("Tabela3"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-table3";
    table.innerHTML = `<thead><tr><th>%</th><th>Rake</th><th>Wpisowe</th><th>Rebuy</th><th>Pot</th></tr></thead>`;
    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");

    const percentCell = document.createElement("td");
    const percentInput = document.createElement("input");
    percentInput.type = "text";
    percentInput.className = "admin-input";
    percentInput.value = formatPercentDisplay(modeState.table3Row.percent);
    percentInput.dataset.focusTarget = "admin-calculator";
    percentInput.dataset.section = "table3";
    percentInput.dataset.tableId = state.mode;
    percentInput.dataset.rowId = "0";
    percentInput.dataset.columnKey = "percent";
    percentInput.addEventListener("focus", () => {
      percentInput.value = modeState.table3Row.percent;
    });
    percentInput.addEventListener("input", () => {
      modeState.table3Row.percent = sanitizeInteger(percentInput.value);
      percentInput.value = modeState.table3Row.percent;
      render();
      schedulePersistCalculatorModeState(state.mode);
    });
    percentInput.addEventListener("blur", () => {
      percentInput.value = formatPercentDisplay(modeState.table3Row.percent);
    });
    percentCell.appendChild(percentInput);

    tr.append(
      percentCell,
      createReadonlyCell(formatNumber(metrics.rake)),
      createReadonlyCell(formatNumber(metrics.entryFee)),
      createReadonlyCell(formatNumber(metrics.rebuyAfterRake)),
      createReadonlyCell(formatNumber(metrics.pot))
    );
    tbody.appendChild(tr);
    table.appendChild(tbody);

    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable3.appendChild(scroll);
  };

  const renderTable4 = () => {
    rootTable4.innerHTML = "";
    rootTable4.appendChild(createHeader("Tabela4"));

    const modeState = getModeState();
    const table4Rows = getTable4Rows();
    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-table4";
    table.innerHTML = `<thead><tr><th>LP</th><th>Gracz</th><th>Wygrana</th></tr></thead>`;
    const tbody = document.createElement("tbody");

    for (let index = 0; index < modeState.table2Rows.length; index += 1) {
      const tr = document.createElement("tr");
      const lp = index + 1;
      const tableRow = table4Rows.find((row) => row.lp === lp);
      const lpCell = document.createElement("td");
      lpCell.textContent = String(lp);
      tr.append(
        lpCell,
        createReadonlyCell(tableRow?.playerName ?? ""),
        createReadonlyCell(formatNumber(tableRow?.win ?? 0))
      );
      tbody.appendChild(tr);
    }
    table.appendChild(tbody);

    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable4.appendChild(scroll);
  };

  const renderTable5 = () => {
    const modeState = getModeState();
    syncTable5ConfigWithRows(modeState);
    const table5Rows = getTable5Rows();
    const rebuyColumnsCount = getAllRebuyEntriesForMode(modeState, state.mode)
      .filter((entry) => entry.value !== "").length;

    rootTable5.innerHTML = "";
    rootTable5.appendChild(createHeader("Tabela5"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-table5";
    let headerHtml = "<thead><tr><th>LP</th><th>Podział puli</th><th>Kwota</th>";
    for (let i = 1; i <= rebuyColumnsCount; i += 1) {
      headerHtml += `<th data-rebuy-column="true">Rebuy${i}</th>`;
    }
    headerHtml += "<th>Mod</th><th>Suma</th></tr></thead>";
    table.innerHTML = headerHtml;

    const tbody = document.createElement("tbody");
    table5Rows.forEach((row) => {
      const tr = document.createElement("tr");
      const lpCell = document.createElement("td");
      lpCell.textContent = String(row.lp);

      const splitPercentCell = document.createElement("td");
      const splitPercentInput = document.createElement("input");
      splitPercentInput.type = "text";
      splitPercentInput.className = "admin-input";
      splitPercentInput.value = formatPercentDisplay(getTable5SplitPercentValue(modeState, row.lp - 1));
      splitPercentInput.dataset.focusTarget = "admin-calculator";
      splitPercentInput.dataset.section = "table5";
      splitPercentInput.dataset.tableId = state.mode;
      splitPercentInput.dataset.rowId = String(row.lp);
      splitPercentInput.dataset.columnKey = "splitPercent";
      splitPercentInput.addEventListener("focus", () => {
        splitPercentInput.value = getTable5SplitPercentValue(modeState, row.lp - 1);
      });
      splitPercentInput.addEventListener("input", () => {
        modeState.table5SplitPercents[row.lp - 1] = sanitizeInteger(splitPercentInput.value);
        splitPercentInput.value = modeState.table5SplitPercents[row.lp - 1];
        render();
        schedulePersistCalculatorModeState(state.mode);
      });
      splitPercentInput.addEventListener("blur", () => {
        splitPercentInput.value = formatPercentDisplay(getTable5SplitPercentValue(modeState, row.lp - 1));
      });
      splitPercentCell.appendChild(splitPercentInput);

      tr.append(
        lpCell,
        splitPercentCell,
        createReadonlyCell(formatNumber(row.amount))
      );

      for (let index = 0; index < rebuyColumnsCount; index += 1) {
        const rebuyValueCell = createReadonlyCell(
          row.rebuyValues[index] == null ? "" : formatNumber(row.rebuyValues[index])
        );
        rebuyValueCell.dataset.rebuyColumn = "true";
        tr.appendChild(rebuyValueCell);
      }

      const modCell = document.createElement("td");
      const modInput = document.createElement("input");
      modInput.type = "text";
      modInput.className = "admin-input";
      modInput.value = getTable5ModValue(modeState, row.lp - 1);
      modInput.dataset.focusTarget = "admin-calculator";
      modInput.dataset.section = "table5";
      modInput.dataset.tableId = state.mode;
      modInput.dataset.rowId = String(row.lp);
      modInput.dataset.columnKey = "mod";
      modInput.addEventListener("input", () => {
        modeState.table5Mods[row.lp - 1] = sanitizeSignedInteger(modInput.value);
        modInput.value = modeState.table5Mods[row.lp - 1];
        render();
        schedulePersistCalculatorModeState(state.mode);
      });
      modCell.appendChild(modInput);
      tr.appendChild(modCell);

      tr.appendChild(createReadonlyCell(formatNumber(row.total)));
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable5.appendChild(scroll);

    const splitPercentsSum = table5Rows.reduce((sum, row) => sum + row.splitPercent, 0);
    if (splitPercentsSum !== 100) {
      const mismatchWarning = document.createElement("p");
      mismatchWarning.className = "status-text status-text-danger";
      mismatchWarning.textContent = "Nie sumuje się do 100%";
      rootTable5.appendChild(mismatchWarning);
    }
  };

  const renderCashTable7 = () => {
    const metrics = getCashMetrics();
    rootTable1.innerHTML = "";
    rootTable1.appendChild(createHeader("Tabela7"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-cash-table7";
    table.innerHTML = "<thead><tr><th>Buy-In</th><th>Rebuy</th><th>Suma</th></tr></thead>";
    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");
    tr.append(
      createReadonlyCell(formatNumber(metrics.buyInAfterPercent)),
      createReadonlyCell(formatNumber(metrics.rebuyAfterPercent)),
      createReadonlyCell(formatNumber(metrics.totalBuyIn + metrics.totalRebuy))
    );
    tbody.appendChild(tr);
    table.appendChild(tbody);

    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable1.appendChild(scroll);
  };

  const renderCashTable8 = () => {
    const metrics = getCashMetrics();
    rootTable2.innerHTML = "";
    rootTable2.appendChild(createHeader("Tabela8"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-cash-table8";
    table.innerHTML = "<thead><tr><th>%</th><th>Rake</th><th>Pot</th></tr></thead>";
    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");

    const rakeCell = document.createElement("td");
    const rakeInput = document.createElement("input");
    rakeInput.type = "text";
    rakeInput.className = "admin-input";
    rakeInput.value = formatPercentDisplay(state.cash.table8Row.rake);
    rakeInput.dataset.focusTarget = "admin-calculator";
    rakeInput.dataset.section = "table8";
    rakeInput.dataset.tableId = "cash";
    rakeInput.dataset.rowId = "0";
    rakeInput.dataset.columnKey = "rake";
    rakeInput.addEventListener("focus", () => {
      rakeInput.value = state.cash.table8Row.rake;
    });
    rakeInput.addEventListener("input", () => {
      state.cash.table8Row.rake = sanitizeInteger(rakeInput.value);
      rakeInput.value = state.cash.table8Row.rake;
      render();
      schedulePersistCalculatorModeState("cash");
    });
    rakeInput.addEventListener("blur", () => {
      rakeInput.value = formatPercentDisplay(state.cash.table8Row.rake);
    });
    rakeCell.appendChild(rakeInput);

    const rakeValueCell = createReadonlyCell(formatNumber(metrics.rakeValue));

    tr.append(rakeCell, rakeValueCell, createReadonlyCell(formatNumber(metrics.pot)));
    tbody.appendChild(tr);
    table.appendChild(tbody);

    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable2.appendChild(scroll);
  };

  const renderCashTable9 = () => {
    rootTable3.innerHTML = "";
    rootTable3.appendChild(createHeader("Tabela9"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-cash-table9";
    table.innerHTML = "<thead><tr><th>Gracz</th><th><button type=\"button\" class=\"secondary\" data-cash-buyin-bulk>Buy-In</button></th><th>Rebuy</th><th>Wypłata</th><th>+/-</th><th></th></tr></thead>";
    const tbody = document.createElement("tbody");

    const bulkBuyInButton = table.querySelector("[data-cash-buyin-bulk]");
    bulkBuyInButton?.addEventListener("click", () => {
      const promptValue = window.prompt("Podaj wartość Buy-In dla wszystkich graczy.", "0");
      if (promptValue === null) {
        return;
      }
      const sanitizedValue = sanitizeInteger(promptValue) || "0";
      state.cash.table9Rows.forEach((entry) => {
        entry.buyIn = sanitizedValue;
      });
      render();
      schedulePersistCalculatorModeState("cash");
    });

    state.cash.table9Rows.forEach((row, index) => {
      const tr = document.createElement("tr");

      const playerCell = document.createElement("td");
      const playerSelect = document.createElement("select");
      playerSelect.className = "admin-input";
      const defaultOption = document.createElement("option");
      defaultOption.value = "";
      defaultOption.textContent = "Wybierz gracza";
      playerSelect.appendChild(defaultOption);
      const currentIdentifier = row.playerId ? `id:${row.playerId}` : (row.playerName ? `name:${row.playerName}` : "");
      const availablePlayers = getAvailablePlayersForRow(state.cash.table9Rows, row.id, state.playerOptions, currentIdentifier);
      availablePlayers.forEach((player) => {
        const option = document.createElement("option");
        option.value = player.id;
        option.textContent = player.name;
        playerSelect.appendChild(option);
      });
      playerSelect.value = row.playerId;
      playerSelect.dataset.focusTarget = "admin-calculator";
      playerSelect.dataset.section = "table9";
      playerSelect.dataset.tableId = "cash";
      playerSelect.dataset.rowId = row.id;
      playerSelect.dataset.columnKey = "playerId";
      playerSelect.addEventListener("change", () => {
        const selectedPlayer = state.playerOptions.find((player) => player.id === playerSelect.value) ?? null;
        row.playerId = selectedPlayer?.id ?? "";
        row.playerName = selectedPlayer?.name ?? "";
        render();
        schedulePersistCalculatorModeState("cash");
      });
      playerCell.appendChild(playerSelect);

      const buyInCell = document.createElement("td");
      const buyInInput = document.createElement("input");
      applyIntegerInputHints(buyInInput);
      buyInInput.className = "admin-input";
      buyInInput.value = row.buyIn;
      buyInInput.dataset.focusTarget = "admin-calculator";
      buyInInput.dataset.section = "table9";
      buyInInput.dataset.tableId = "cash";
      buyInInput.dataset.rowId = row.id;
      buyInInput.dataset.columnKey = "buyIn";
      buyInInput.addEventListener("input", () => {
        row.buyIn = sanitizeInteger(buyInInput.value);
        buyInInput.value = row.buyIn;
        render();
        schedulePersistCalculatorModeState("cash");
      });
      buyInCell.appendChild(buyInInput);

      const rebuyCell = document.createElement("td");
      const rebuyButton = document.createElement("button");
      rebuyButton.type = "button";
      rebuyButton.className = "secondary";
      rebuyButton.textContent = formatNumber(getRowRebuySum(row));
      rebuyButton.addEventListener("click", () => {
        state.rebuyModal.mode = "cash";
        openRebuyModal(row.id);
      });
      rebuyCell.appendChild(rebuyButton);

      const payoutCell = document.createElement("td");
      const payoutInput = document.createElement("input");
      applyIntegerInputHints(payoutInput);
      payoutInput.className = "admin-input";
      payoutInput.value = row.payout;
      payoutInput.dataset.focusTarget = "admin-calculator";
      payoutInput.dataset.section = "table9";
      payoutInput.dataset.tableId = "cash";
      payoutInput.dataset.rowId = row.id;
      payoutInput.dataset.columnKey = "payout";
      payoutInput.addEventListener("input", () => {
        row.payout = sanitizeInteger(payoutInput.value);
        payoutInput.value = row.payout;
        render();
        schedulePersistCalculatorModeState("cash");
      });
      payoutCell.appendChild(payoutInput);

      const plusMinus = parseInteger(row.payout) - (parseInteger(row.buyIn) + getRowRebuySum(row));

      const actionsCell = document.createElement("td");
      const actionsWrap = document.createElement("div");
      actionsWrap.className = "admin-table-actions";

      if (index === state.cash.table9Rows.length - 1) {
        const addButton = document.createElement("button");
        addButton.type = "button";
        addButton.className = "secondary";
        addButton.textContent = "Dodaj";
        addButton.addEventListener("click", () => {
          state.cash.table9Rows.push({
            id: `table9-${Date.now()}-${state.cash.table9Rows.length}`,
            playerId: "",
            playerName: "",
            buyIn: "0",
            payout: "0",
            rebuys: [],
            rebuyIndexes: []
          });
          render();
          schedulePersistCalculatorModeState("cash");
        });
        actionsWrap.appendChild(addButton);
      }

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-row-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.disabled = state.cash.table9Rows.length === 1;
      deleteButton.addEventListener("click", () => {
        state.cash.table9Rows = state.cash.table9Rows.filter((entry) => entry.id !== row.id);
        if (!state.cash.table9Rows.length) {
          state.cash.table9Rows.push({ id: `table9-${Date.now()}-0`, playerId: "", playerName: "", buyIn: "0", payout: "0", rebuys: [], rebuyIndexes: [] });
        }
        render();
        schedulePersistCalculatorModeState("cash");
      });
      actionsWrap.appendChild(deleteButton);
      actionsCell.appendChild(actionsWrap);

      tr.append(
        playerCell,
        buyInCell,
        rebuyCell,
        payoutCell,
        createReadonlyCell(formatNumber(plusMinus)),
        actionsCell
      );
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable3.appendChild(scroll);
  };

  const renderCashTable10 = () => {
    rootTable4.innerHTML = "";
    rootTable4.appendChild(createHeader("Tabela10"));

    const table = document.createElement("table");
    table.className = "admin-data-table admin-calculator-cash-table10";
    table.innerHTML = "<thead><tr><th>Lp</th><th>Gracz</th><th>Wypłata</th><th>+/-</th><th>% Puli</th></tr></thead>";
    const tbody = document.createElement("tbody");

    getCashTable10Rows().forEach((row, index) => {
      const tr = document.createElement("tr");
      tr.append(
        createReadonlyCell(String(index + 1)),
        createReadonlyCell(row.playerName),
        createReadonlyCell(formatNumber(row.payout)),
        createReadonlyCell(formatNumber(row.plusMinus)),
        createReadonlyCell(`${Math.round(row.poolPercent)}%`)
      );
      tbody.appendChild(tr);
    });

    table.appendChild(tbody);
    const scroll = createScroll();
    scroll.appendChild(table);
    rootTable4.appendChild(scroll);
    rootTable5.innerHTML = "";
  };

  const getOrganizationMetrics = () => {
    const modeState = state.organization;
    const percentValue = parseInteger(modeState.table1.percent);
    const baseValue = parseInteger(modeState.table1.base);
    const organizationValue = Math.ceil(baseValue * (percentValue / 100));
    const potValue = Math.ceil(baseValue - organizationValue);
    return { percentValue, baseValue, organizationValue, potValue };
  };

  const ensureOrganizationRows = () => {
    if (!Array.isArray(state.organization.table2Rows) || !state.organization.table2Rows.length) {
      state.organization.table2Rows = [{ id: `org-table2-${Date.now()}-0`, percent: "" }];
    }
  };

  const ensureChipsRows = (modeState) => {
    if (!Array.isArray(modeState.tableAARows) || !modeState.tableAARows.length) {
      modeState.tableAARows = [{ id: `chips-aa-${Date.now()}-0`, nominal: "", count: "" }];
    }
    modeState.tableACRows = modeState.tableAARows.map((row, index) => {
      const current = modeState.tableACRows?.[index];
      return {
        id: typeof current?.id === "string" && current.id.trim() ? current.id.trim() : `chips-ac-${Date.now()}-${index}`,
        count: sanitizeInteger(current?.count)
      };
    });
  };

  const renderOrganizationTables = () => {
    const modeState = state.organization;
    ensureOrganizationRows();
    const metrics = getOrganizationMetrics();

    rootTable1.innerHTML = "";
    rootTable1.appendChild(createHeader("TABELA1"));
    const table1 = document.createElement("table");
    table1.className = "admin-data-table";
    table1.innerHTML = "<thead><tr><th>KALKULATOR</th><th>ORGANIZACJA</th><th>POT</th></tr></thead>";
    const tbody1 = document.createElement("tbody");
    const row1 = document.createElement("tr");
    const percentCell = document.createElement("td");
    const percentInput = document.createElement("input");
    applyIntegerInputHints(percentInput);
    percentInput.className = "admin-input";
    percentInput.value = formatPercentDisplay(modeState.table1.percent);
    percentInput.dataset.focusTarget = "admin-calculator";
    percentInput.dataset.section = "organization-table1";
    percentInput.dataset.tableId = ORGANIZATION_MODE;
    percentInput.dataset.rowId = "1";
    percentInput.dataset.columnKey = "percent";
    percentInput.addEventListener("focus", () => { percentInput.value = modeState.table1.percent; });
    percentInput.addEventListener("input", () => {
      modeState.table1.percent = sanitizeInteger(percentInput.value);
      percentInput.value = modeState.table1.percent;
      render();
      schedulePersistCalculatorModeState(ORGANIZATION_MODE);
    });
    percentInput.addEventListener("blur", () => { percentInput.value = formatPercentDisplay(modeState.table1.percent); });
    percentCell.appendChild(percentInput);
    row1.append(percentCell, createReadonlyCell(formatNumber(metrics.organizationValue)), createReadonlyCell(formatNumber(metrics.potValue)));
    tbody1.appendChild(row1);

    const row2 = document.createElement("tr");
    const baseCell = document.createElement("td");
    const baseInput = document.createElement("input");
    applyIntegerInputHints(baseInput);
    baseInput.className = "admin-input";
    baseInput.value = modeState.table1.base;
    baseInput.dataset.focusTarget = "admin-calculator";
    baseInput.dataset.section = "organization-table1";
    baseInput.dataset.tableId = ORGANIZATION_MODE;
    baseInput.dataset.rowId = "2";
    baseInput.dataset.columnKey = "base";
    baseInput.addEventListener("input", () => {
      modeState.table1.base = sanitizeInteger(baseInput.value);
      baseInput.value = modeState.table1.base;
      render();
      schedulePersistCalculatorModeState(ORGANIZATION_MODE);
    });
    baseCell.appendChild(baseInput);
    const emptyOrganizationCell = document.createElement("td");
    const emptyPotCell = document.createElement("td");
    row2.append(baseCell, emptyOrganizationCell, emptyPotCell);
    tbody1.appendChild(row2);
    table1.appendChild(tbody1);
    const scroll1 = createScroll();
    scroll1.appendChild(table1);
    rootTable1.appendChild(scroll1);

    rootTable2.innerHTML = "";
    rootTable2.appendChild(createHeader("TABELA2"));
    const table2 = document.createElement("table");
    table2.className = "admin-data-table";
    table2.innerHTML = `<thead><tr><th>${formatNumber(metrics.organizationValue)}</th><th>PODZIAŁ</th><th></th></tr></thead>`;
    const tbody2 = document.createElement("tbody");
    modeState.table2Rows.forEach((row) => {
      const tr = document.createElement("tr");
      const percentValue = parseInteger(row.percent);
      const percentRowCell = document.createElement("td");
      const percentRowInput = document.createElement("input");
      applyIntegerInputHints(percentRowInput);
      percentRowInput.className = "admin-input";
      percentRowInput.value = formatPercentDisplay(row.percent);
      percentRowInput.dataset.focusTarget = "admin-calculator";
      percentRowInput.dataset.section = "organization-table2";
      percentRowInput.dataset.tableId = ORGANIZATION_MODE;
      percentRowInput.dataset.rowId = row.id;
      percentRowInput.dataset.columnKey = "percent";
      percentRowInput.addEventListener("focus", () => { percentRowInput.value = row.percent; });
      percentRowInput.addEventListener("input", () => {
        row.percent = sanitizeInteger(percentRowInput.value);
        percentRowInput.value = row.percent;
        render();
        schedulePersistCalculatorModeState(ORGANIZATION_MODE);
      });
      percentRowInput.addEventListener("blur", () => { percentRowInput.value = formatPercentDisplay(row.percent); });
      percentRowCell.appendChild(percentRowInput);

      const actions = document.createElement("td");
      const actionsWrap = document.createElement("div");
      actionsWrap.className = "admin-table-actions admin-table-actions--row-end";
      const delBtn = document.createElement("button");
      delBtn.type = "button";
      delBtn.className = "danger admin-row-delete";
      delBtn.textContent = "Usuń";
      delBtn.disabled = modeState.table2Rows.length === 1;
      delBtn.addEventListener("click", () => {
        modeState.table2Rows = modeState.table2Rows.filter((entry) => entry.id !== row.id);
        ensureOrganizationRows();
        render();
        schedulePersistCalculatorModeState(ORGANIZATION_MODE);
      });
      actionsWrap.appendChild(delBtn);
      actions.appendChild(actionsWrap);
      tr.append(percentRowCell, createReadonlyCell(formatNumber(metrics.organizationValue * (percentValue / 100))), actions);
      tbody2.appendChild(tr);
    });
    table2.appendChild(tbody2);
    const scroll2 = createScroll();
    scroll2.appendChild(table2);
    rootTable2.appendChild(scroll2);
    const table2FooterActions = document.createElement("div");
    table2FooterActions.className = "admin-table-footer-actions";
    const table2AddButton = document.createElement("button");
    table2AddButton.type = "button";
    table2AddButton.className = "secondary";
    table2AddButton.textContent = "Dodaj";
    table2AddButton.addEventListener("click", () => {
      modeState.table2Rows.push({ id: `org-table2-${Date.now()}-${modeState.table2Rows.length}`, percent: "" });
      render();
      schedulePersistCalculatorModeState(ORGANIZATION_MODE);
    });
    table2FooterActions.appendChild(table2AddButton);
    rootTable2.appendChild(table2FooterActions);
    rootTable3.innerHTML = "";
    rootTable4.innerHTML = "";
    rootTable5.innerHTML = "";
  };

  const renderChipsTables = () => {
    const modeState = getModeState();
    ensureChipsRows(modeState);
    const playersCount = parseInteger(modeState.tableAB.playersCount);
    const stackTotal = modeState.tableAARows.reduce((sum, row) => sum + Math.ceil(parseInteger(row.nominal) * parseInteger(row.count)), 0);

    rootTable1.innerHTML = "";
    rootTable1.appendChild(createHeader("TABELAA"));
    const tableAA = document.createElement("table");
    tableAA.className = "admin-data-table";
    tableAA.innerHTML = "<thead><tr><th>NOMINAŁ</th><th>SZTUK</th><th>STACK</th><th></th></tr></thead>";
    const tbodyAA = document.createElement("tbody");
    modeState.tableAARows.forEach((row) => {
      const tr = document.createElement("tr");
      const nominalInput = document.createElement("input");
      applyIntegerInputHints(nominalInput);
      nominalInput.className = "admin-input";
      nominalInput.value = row.nominal;
      nominalInput.dataset.focusTarget = "admin-calculator";
      nominalInput.dataset.section = "chips-aa";
      nominalInput.dataset.tableId = state.mode;
      nominalInput.dataset.rowId = row.id;
      nominalInput.dataset.columnKey = "nominal";
      nominalInput.addEventListener("input", () => { row.nominal = sanitizeInteger(nominalInput.value); nominalInput.value = row.nominal; render(); schedulePersistCalculatorModeState(state.mode); });
      const countInput = document.createElement("input");
      applyIntegerInputHints(countInput);
      countInput.className = "admin-input";
      countInput.value = row.count;
      countInput.dataset.focusTarget = "admin-calculator";
      countInput.dataset.section = "chips-aa";
      countInput.dataset.tableId = state.mode;
      countInput.dataset.rowId = row.id;
      countInput.dataset.columnKey = "count";
      countInput.addEventListener("input", () => { row.count = sanitizeInteger(countInput.value); countInput.value = row.count; render(); schedulePersistCalculatorModeState(state.mode); });
      const nominalCell = document.createElement("td"); nominalCell.appendChild(nominalInput);
      const countCell = document.createElement("td"); countCell.appendChild(countInput);
      const actionsCell = document.createElement("td");
      const wrap = document.createElement("div"); wrap.className = "admin-table-actions admin-table-actions--row-end";
      const delBtn = document.createElement("button"); delBtn.type = "button"; delBtn.className = "danger admin-row-delete"; delBtn.textContent = "Usuń"; delBtn.disabled = modeState.tableAARows.length === 1;
      delBtn.addEventListener("click", () => { modeState.tableAARows = modeState.tableAARows.filter((entry) => entry.id !== row.id); ensureChipsRows(modeState); render(); schedulePersistCalculatorModeState(state.mode); });
      wrap.appendChild(delBtn); actionsCell.appendChild(wrap);
      tr.append(nominalCell, countCell, createReadonlyCell(formatNumber(parseInteger(row.nominal) * parseInteger(row.count))), actionsCell);
      tbodyAA.appendChild(tr);
    });
    tableAA.appendChild(tbodyAA);
    const scrollAA = createScroll(); scrollAA.appendChild(tableAA); rootTable1.appendChild(scrollAA);
    const tableAAFooterActions = document.createElement("div");
    tableAAFooterActions.className = "admin-table-footer-actions";
    const tableAAAddButton = document.createElement("button");
    tableAAAddButton.type = "button";
    tableAAAddButton.className = "secondary";
    tableAAAddButton.textContent = "Dodaj";
    tableAAAddButton.addEventListener("click", () => {
      modeState.tableAARows.push({ id: `chips-aa-${Date.now()}-${modeState.tableAARows.length}`, nominal: "", count: "" });
      render();
      schedulePersistCalculatorModeState(state.mode);
    });
    tableAAFooterActions.appendChild(tableAAAddButton);
    rootTable1.appendChild(tableAAFooterActions);
    const stackSummary = document.createElement("p");
    stackSummary.className = "admin-table-info";
    stackSummary.textContent = `Łącznie Stack: ${formatNumber(stackTotal)}`;
    rootTable1.appendChild(stackSummary);

    rootTable2.innerHTML = "";
    rootTable2.appendChild(createHeader("TABELAB"));
    const tableAB = document.createElement("table");
    tableAB.className = "admin-data-table";
    tableAB.innerHTML = "<thead><tr><th>L.GRACZY</th><th>STACK GRACZA</th><th>ŁĄCZNY STACK</th></tr></thead>";
    const tbodyAB = document.createElement("tbody");
    const trAB = document.createElement("tr");
    const playersInput = document.createElement("input");
    applyIntegerInputHints(playersInput);
    playersInput.className = "admin-input";
    playersInput.value = modeState.tableAB.playersCount;
    playersInput.dataset.focusTarget = "admin-calculator";
    playersInput.dataset.section = "chips-ab";
    playersInput.dataset.tableId = state.mode;
    playersInput.dataset.rowId = "0";
    playersInput.dataset.columnKey = "playersCount";
    playersInput.addEventListener("input", () => { modeState.tableAB.playersCount = sanitizeInteger(playersInput.value); playersInput.value = modeState.tableAB.playersCount; render(); schedulePersistCalculatorModeState(state.mode); });
    const playerStackInput = document.createElement("input");
    applyIntegerInputHints(playerStackInput);
    playerStackInput.className = "admin-input";
    playerStackInput.value = modeState.tableAB.playerStack;
    playerStackInput.dataset.focusTarget = "admin-calculator";
    playerStackInput.dataset.section = "chips-ab";
    playerStackInput.dataset.tableId = state.mode;
    playerStackInput.dataset.rowId = "0";
    playerStackInput.dataset.columnKey = "playerStack";
    playerStackInput.addEventListener("input", () => { modeState.tableAB.playerStack = sanitizeInteger(playerStackInput.value); playerStackInput.value = modeState.tableAB.playerStack; render(); schedulePersistCalculatorModeState(state.mode); });
    const playersCell = document.createElement("td"); playersCell.appendChild(playersInput);
    const stackCell = document.createElement("td"); stackCell.appendChild(playerStackInput);
    trAB.append(playersCell, stackCell, createReadonlyCell(formatNumber(playersCount * parseInteger(modeState.tableAB.playerStack))));
    tbodyAB.appendChild(trAB);
    tableAB.appendChild(tbodyAB);
    const scrollAB = createScroll(); scrollAB.appendChild(tableAB); rootTable2.appendChild(scrollAB);

    rootTable3.innerHTML = "";
    rootTable3.appendChild(createHeader("TABELAC"));
    const tableAC = document.createElement("table");
    tableAC.className = "admin-data-table";
    tableAC.innerHTML = "<thead><tr><th>POZOSTAŁE ŻETONY</th><th>NOMINAŁ</th><th>SZTUK</th><th>SUMA</th><th>DLA WSZYSTKICH W SZT.</th></tr></thead>";
    const tbodyAC = document.createElement("tbody");
    modeState.tableAARows.forEach((row, index) => {
      const acRow = modeState.tableACRows[index] ?? { id: `chips-ac-${Date.now()}-${index}`, count: "" };
      const sztukValue = parseInteger(acRow.count);
      const suma = Math.ceil(parseInteger(row.nominal) * sztukValue);
      const forAll = Math.ceil(sztukValue * playersCount);
      const stack = Math.ceil(parseInteger(row.nominal) * parseInteger(row.count));
      const tr = document.createElement("tr");
      const sztukInput = document.createElement("input");
      applyIntegerInputHints(sztukInput);
      sztukInput.className = "admin-input";
      sztukInput.value = acRow.count;
      sztukInput.dataset.focusTarget = "admin-calculator";
      sztukInput.dataset.section = "chips-ac";
      sztukInput.dataset.tableId = state.mode;
      sztukInput.dataset.rowId = acRow.id;
      sztukInput.dataset.columnKey = "count";
      sztukInput.addEventListener("input", () => { acRow.count = sanitizeInteger(sztukInput.value); sztukInput.value = acRow.count; modeState.tableACRows[index] = acRow; render(); schedulePersistCalculatorModeState(state.mode); });
      const sztukCell = document.createElement("td"); sztukCell.appendChild(sztukInput);
      tr.append(createReadonlyCell(formatNumber(stack - forAll)), createReadonlyCell(formatNumber(parseInteger(row.nominal))), sztukCell, createReadonlyCell(formatNumber(suma)), createReadonlyCell(formatNumber(forAll)));
      tbodyAC.appendChild(tr);
    });
    tableAC.appendChild(tbodyAC);
    const scrollAC = createScroll(); scrollAC.appendChild(tableAC); rootTable3.appendChild(scrollAC);
    rootTable4.innerHTML = "";
    rootTable5.innerHTML = "";
  };

  const render = () => {
    const focusState = getFocusedAdminInputState(calculatorContent);
    if (state.mode === "cash") {
      renderCashTable7();
      renderCashTable8();
      renderCashTable9();
      renderCashTable10();
      restoreFocusedAdminInputState(calculatorContent, focusState);

      if (rebuyModal.classList.contains("is-visible")) {
        renderRebuyModal();
      }
      return;
    }

    if (state.mode === ORGANIZATION_MODE) {
      renderOrganizationTables();
      restoreFocusedAdminInputState(calculatorContent, focusState);
      return;
    }

    if (CHIPS_MODES.has(state.mode)) {
      renderChipsTables();
      restoreFocusedAdminInputState(calculatorContent, focusState);
      return;
    }

    renderTable1();
    renderTable2();
    renderTable3();
    renderTable4();
    renderTable5();
    restoreFocusedAdminInputState(calculatorContent, focusState);

    if (rebuyModal.classList.contains("is-visible")) {
      renderRebuyModal();
    }
  };

  modeButtons.forEach((button) => {
    button.addEventListener("click", () => {
      state.mode = ALL_CALCULATOR_MODES.includes(button.dataset.calculatorMode)
        ? button.dataset.calculatorMode
        : "tournament1";
      modeButtons.forEach((entry) => {
        entry.classList.toggle("is-active", entry === button);
      });
      if (rebuyModal.classList.contains("is-visible")) {
        closeRebuyModal();
      }
      render();
    });
  });

  if (!firebaseApp) {
    if (status) {
      status.textContent = "Brak połączenia z Firebase. Lista graczy będzie pusta.";
    }
    render();
    return;
  }

  ALL_CALCULATOR_MODES.forEach((mode) => {
    getCalculatorDocRef(mode).onSnapshot((snapshot) => {
      if (!snapshot.exists) {
        return;
      }
      if (state.mode === mode && (isEditingSection(["table1", "table2", "table3", "table5", "table9", "organization-table1", "organization-table2", "chips-aa", "chips-ab", "chips-ac"]) || hasPendingDebounceWithPrefix(`admin-calculator-${mode}`))) {
        return;
      }
      state[mode] = normalizeCalculatorModeState(mode, snapshot.data());
      render();
    }, () => {
      if (status) {
        status.textContent = "Nie udało się pobrać zapisanych danych kalkulatora.";
      }
    });
  });

  firebaseApp.firestore().collection(PLAYER_ACCESS_COLLECTION).doc(PLAYER_ACCESS_DOCUMENT).onSnapshot((snapshot) => {
    const players = Array.isArray(snapshot.data()?.players) ? snapshot.data().players : [];
    state.playerOptions = players
      .map((player, index) => ({
        id: typeof player?.id === "string" && player.id.trim() ? player.id.trim() : `player-${index + 1}`,
        name: normalizePlayerName(player?.name)
      }))
      .filter((player) => player.id && player.name);
    if (status) {
      status.textContent = `Załadowano ${state.playerOptions.length} graczy do list wyboru.`;
    }
    render();
  }, () => {
    if (status) {
      status.textContent = "Nie udało się pobrać listy graczy.";
    }
    render();
  });
};

const initAdminPanelRefresh = () => {
  const refreshButton = document.querySelector("#adminPanelRefresh");
  const panelStatus = document.querySelector("#adminPanelRefreshStatus");
  if (!refreshButton) {
    return;
  }

  const setPanelStatus = (message) => {
    if (panelStatus) {
      panelStatus.textContent = message;
    }
  };

  refreshButton.addEventListener("click", async () => {
    const activePanel = document.querySelector(".admin-panel-content.is-active");
    const activeTabId = activePanel?.id;

    if (!activeTabId) {
      setPanelStatus("Nie udało się rozpoznać aktywnej zakładki.");
      return;
    }

    const refreshHandler = adminRefreshHandlers.get(activeTabId);
    if (!refreshHandler) {
      setPanelStatus("Ta zakładka nie ma danych do odświeżenia.");
      return;
    }

    setPanelStatus("Odświeżanie danych...");
    refreshButton.disabled = true;

    try {
      await refreshHandler();
      setPanelStatus("Dane zostały odświeżone.");
    } catch (error) {
      setPanelStatus("Nie udało się odświeżyć danych.");
    } finally {
      refreshButton.disabled = false;
    }
  });
};

const initAdminPlayers = () => {
  const body = document.querySelector("#adminPlayersBody");
  const status = document.querySelector("#adminPlayersStatus");
  const summary = document.querySelector("#adminPlayersSummary");
  const addButton = document.querySelector("#adminAddPlayer");
  const modal = document.querySelector("#playerPermissionsModal");
  const modalList = document.querySelector("#playerPermissionsList");
  const modalStatus = document.querySelector("#playerPermissionsStatus");
  const closeButton = document.querySelector("#playerPermissionsClose");
  const yearsModal = document.querySelector("#playerStatsYearsModal");
  const yearsModalList = document.querySelector("#playerStatsYearsList");
  const yearsModalStatus = document.querySelector("#playerStatsYearsStatus");
  const yearsModalCloseButton = document.querySelector("#playerStatsYearsClose");

  if (!body || !status || !summary || !addButton || !modal || !modalList || !modalStatus) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    addButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby zarządzać graczami.";
    return;
  }

  const db = firebaseApp.firestore();

  let availableStatisticsYears = [];

  const getPinOwnerId = (pin, excludedId) => {
    if (!pin) {
      return null;
    }
    const match = adminPlayersState.players.find((player) => player.pin === pin && player.id !== excludedId);
    return match ? match.id : null;
  };

  const refreshPlayersData = async () => {
    const snapshot = await db.collection(PLAYER_ACCESS_COLLECTION).doc(PLAYER_ACCESS_DOCUMENT).get({
      source: "server"
    });
    const data = snapshot.data();
    const rawPlayers = Array.isArray(data?.players) ? data.players : [];
    adminPlayersState.players = rawPlayers.map(normalizePlayerRecord);
    rebuildAdminPlayersPinMap();
    renderPlayers();
    if (modal.classList.contains("is-visible")) {
      renderPermissions();
      if (yearsModal && yearsModal.classList.contains("is-visible")) {
        renderStatsYearsPermissions();
      }
    }
  };

  registerAdminRefreshHandler("adminPlayersTab", refreshPlayersData);

  const savePlayers = async () => {
    try {
      await db.collection(PLAYER_ACCESS_COLLECTION).doc(PLAYER_ACCESS_DOCUMENT).set({
        players: adminPlayersState.players,
        updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp()
      });
      status.textContent = "Lista graczy zapisana.";
    } catch (error) {
      status.textContent = "Nie udało się zapisać listy graczy.";
    }
  };

  const getEditingPlayer = () => adminPlayersState.players.find((entry) => entry.id === adminPlayersState.editingPlayerId);

  const openModal = (playerId) => {
    adminPlayersState.editingPlayerId = playerId;
    modal.classList.add("is-visible");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    renderPermissions();
  };

  const closeModal = () => {
    closeYearsModal();
    adminPlayersState.editingPlayerId = null;
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    modalStatus.textContent = "";
    document.body.classList.remove("modal-open");
  };

  const openYearsModal = () => {
    if (!yearsModal) {
      return;
    }
    yearsModal.classList.add("is-visible");
    yearsModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };

  const closeYearsModal = () => {
    if (!yearsModal) {
      return;
    }
    yearsModal.classList.remove("is-visible");
    yearsModal.setAttribute("aria-hidden", "true");
    if (!modal.classList.contains("is-visible")) {
      document.body.classList.remove("modal-open");
    }
    if (yearsModalStatus) {
      yearsModalStatus.textContent = "";
    }
  };

  const updatePlayerField = (playerId, field, value) => {
    const player = adminPlayersState.players.find((entry) => entry.id === playerId);
    if (!player) {
      return;
    }

    if (field === "pin") {
      const pinValue = sanitizePin(value);
      if (isPinValid(pinValue) && getPinOwnerId(pinValue, playerId)) {
        status.textContent = "Ten PIN jest już przypisany do innego gracza.";
        return;
      }
      player.pin = pinValue;
      rebuildAdminPlayersPinMap();
    } else {
      player[field] = value;
    }

    scheduleDebouncedUpdate(`players:${playerId}:${field}`, () => {
      void savePlayers();
    });
  };

  const generateUniquePlayerPin = (excludedId) => {
    const existingPins = new Set(
      adminPlayersState.players
        .filter((player) => player.id !== excludedId && isPinValid(player.pin))
        .map((player) => player.pin)
    );

    let candidate = generateRandomPin();
    while (existingPins.has(candidate)) {
      candidate = generateRandomPin();
    }
    return candidate;
  };

  const renderStatsYearsPermissions = () => {
    if (!yearsModalList || !yearsModalStatus) {
      return;
    }
    yearsModalList.innerHTML = "";
    const player = getEditingPlayer();
    if (!player) {
      yearsModalStatus.textContent = "Nie znaleziono gracza.";
      return;
    }

    if (!availableStatisticsYears.length) {
      yearsModalStatus.textContent = "Brak dostępnych lat statystyk. Dodaj gry, aby lata pojawiły się automatycznie.";
      return;
    }

    yearsModalStatus.textContent = "";
    const selectedSet = new Set(normalizeStatsYearsAccess(player.statsYearsAccess));
    availableStatisticsYears.forEach((year) => {
      const label = document.createElement("label");
      label.className = "permissions-item";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = selectedSet.has(year);
      checkbox.addEventListener("change", () => {
        const targetPlayer = getEditingPlayer();
        if (!targetPlayer) {
          return;
        }
        const nextSet = new Set(normalizeStatsYearsAccess(targetPlayer.statsYearsAccess));
        if (checkbox.checked) {
          nextSet.add(year);
        } else {
          nextSet.delete(year);
        }
        targetPlayer.statsYearsAccess = normalizeStatsYearsAccess(Array.from(nextSet));
        renderPermissions();
        void savePlayers();
      });

      const text = document.createElement("span");
      text.textContent = String(year);
      label.appendChild(checkbox);
      label.appendChild(text);
      yearsModalList.appendChild(label);
    });
  };

  const renderPermissions = () => {
    modalList.innerHTML = "";
    const player = getEditingPlayer();
    if (!player) {
      modalStatus.textContent = "Nie znaleziono gracza.";
      return;
    }

    AVAILABLE_PLAYER_TABS.forEach((tab) => {
      const label = document.createElement("label");
      label.className = "permissions-item";

      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.checked = player.permissions.includes(tab.key);
      checkbox.addEventListener("change", () => {
        const targetPlayer = getEditingPlayer();
        if (!targetPlayer) {
          return;
        }
        if (checkbox.checked) {
          targetPlayer.permissions = Array.from(new Set([...targetPlayer.permissions, tab.key]));
        } else {
          targetPlayer.permissions = targetPlayer.permissions.filter((permission) => permission !== tab.key);
          if (tab.key === "statsTab") {
            targetPlayer.statsYearsAccess = [];
            closeYearsModal();
          }
        }
        renderPlayers();
        renderPermissions();
        void savePlayers();
      });

      const text = document.createElement("span");
      text.textContent = tab.label;

      label.appendChild(checkbox);
      label.appendChild(text);

      if (tab.key === "statsTab") {
        const yearsButton = document.createElement("button");
        yearsButton.type = "button";
        yearsButton.className = "secondary permissions-years-button";
        yearsButton.textContent = "Lata";
        yearsButton.disabled = !checkbox.checked;
        yearsButton.addEventListener("click", () => {
          openYearsModal();
          renderStatsYearsPermissions();
        });
        label.appendChild(yearsButton);
      }

      modalList.appendChild(label);
    });
  };

  const renderPlayers = () => {
    const focusState = getFocusedAdminInputState(body);
    body.innerHTML = "";
    adminPlayersState.players.forEach((player) => {
      const row = document.createElement("tr");

      const appCell = document.createElement("td");
      appCell.className = "players-app-cell";
      const appCheckbox = document.createElement("input");
      appCheckbox.type = "checkbox";
      appCheckbox.className = "players-app-checkbox";
      appCheckbox.checked = Boolean(player.appEnabled);
      appCheckbox.setAttribute("aria-label", `Dostęp aplikacji dla gracza ${player.name || player.id}`);
      appCheckbox.addEventListener("change", () => {
        updatePlayerField(player.id, "appEnabled", appCheckbox.checked);
      });
      appCell.appendChild(appCheckbox);

      const nameCell = document.createElement("td");
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.className = "admin-input";
      nameInput.dataset.focusTarget = "player-field";
      nameInput.dataset.section = "players";
      nameInput.dataset.rowId = player.id;
      nameInput.dataset.columnKey = "name";
      nameInput.placeholder = "Np. Jan Kowalski";
      nameInput.value = player.name;
      nameInput.addEventListener("input", () => {
        updatePlayerField(player.id, "name", nameInput.value);
      });
      nameCell.appendChild(nameInput);

      const pinCell = document.createElement("td");
      const pinControl = document.createElement("div");
      pinControl.className = "pin-control";
      const pinInput = document.createElement("input");
      pinInput.type = "tel";
      pinInput.className = "admin-input";
      pinInput.dataset.focusTarget = "player-field";
      pinInput.dataset.section = "players";
      pinInput.dataset.rowId = player.id;
      pinInput.dataset.columnKey = "pin";
      pinInput.inputMode = "numeric";
      pinInput.maxLength = PIN_LENGTH;
      pinInput.placeholder = "5 cyfr";
      pinInput.value = player.pin;
      pinInput.addEventListener("input", () => {
        const pinValue = sanitizePin(pinInput.value);
        pinInput.value = pinValue;

        if (pinValue.length > 0 && !isPinValid(pinValue)) {
          pinInput.setCustomValidity("PIN musi mieć dokładnie 5 cyfr.");
        } else {
          pinInput.setCustomValidity("");
        }

        const duplicateOwnerId = getPinOwnerId(pinValue, player.id);
        if (duplicateOwnerId) {
          pinInput.value = "";
          pinInput.setCustomValidity("PIN musi być unikalny.");
          pinInput.reportValidity();
          updatePlayerField(player.id, "pin", "");
          return;
        }

        if (isPinValid(pinValue)) {
          updatePlayerField(player.id, "pin", pinValue);
        } else if (!pinValue) {
          updatePlayerField(player.id, "pin", "");
        }
      });

      const pinRandomButton = document.createElement("button");
      pinRandomButton.type = "button";
      pinRandomButton.className = "secondary admin-pin-random";
      pinRandomButton.textContent = "Losuj";
      pinRandomButton.addEventListener("click", () => {
        const randomPin = generateUniquePlayerPin(player.id);
        pinInput.value = randomPin;
        pinInput.setCustomValidity("");
        updatePlayerField(player.id, "pin", randomPin);
      });

      pinControl.appendChild(pinInput);
      pinControl.appendChild(pinRandomButton);
      pinCell.appendChild(pinControl);

      const permissionsCell = document.createElement("td");
      const tags = document.createElement("div");
      tags.className = "permissions-tags";
      if (player.permissions.length) {
        player.permissions.forEach((permission) => {
          const tab = AVAILABLE_PLAYER_TABS.find((entry) => entry.key === permission);
          const badge = document.createElement("span");
          badge.className = "permission-badge";
          if (permission === "statsTab") {
            const yearsCount = normalizeStatsYearsAccess(player.statsYearsAccess).length;
            badge.textContent = `${tab ? tab.label : permission}${yearsCount ? ` (${yearsCount} lat)` : " (0 lat)"}`;
          } else {
            badge.textContent = tab ? tab.label : permission;
          }
          tags.appendChild(badge);
        });
      } else {
        const empty = document.createElement("span");
        empty.className = "permission-badge is-empty";
        empty.textContent = "Brak dodatkowych uprawnień";
        tags.appendChild(empty);
      }
      const editButton = document.createElement("button");
      editButton.type = "button";
      editButton.className = "secondary admin-permissions-edit";
      editButton.textContent = "Edytuj";
      editButton.addEventListener("click", () => {
        openModal(player.id);
      });
      permissionsCell.appendChild(tags);
      permissionsCell.appendChild(editButton);

      const actionsCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-row-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.addEventListener("click", async () => {
        adminPlayersState.players = adminPlayersState.players.filter((entry) => entry.id !== player.id);
        rebuildAdminPlayersPinMap();
        renderPlayers();
        await savePlayers();
      });
      actionsCell.appendChild(deleteButton);

      row.appendChild(appCell);
      row.appendChild(nameCell);
      row.appendChild(pinCell);
      row.appendChild(permissionsCell);
      row.appendChild(actionsCell);
      body.appendChild(row);
    });

    restoreFocusedAdminInputState(body, focusState);
    summary.textContent = `Liczba dodanych graczy: ${adminPlayersState.players.length}`;
  };

  addButton.addEventListener("click", async () => {
    adminPlayersState.players.push({
      id: `player-${Date.now()}`,
      name: "",
      pin: "",
      appEnabled: false,
      permissions: [],
      statsYearsAccess: []
    });
    renderPlayers();
    await savePlayers();
  });

  if (closeButton) {
    closeButton.addEventListener("click", closeModal);
  }

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });

  db.collection(PLAYER_ACCESS_COLLECTION)
    .doc(PLAYER_ACCESS_DOCUMENT)
    .onSnapshot(
      (snapshot) => {
        if (isEditingSection(["players"]) || hasPendingDebounceWithPrefix("players:")) {
          return;
        }
        const data = snapshot.data();
        const rawPlayers = Array.isArray(data?.players) ? data.players : [];
        adminPlayersState.players = rawPlayers.map(normalizePlayerRecord);
        rebuildAdminPlayersPinMap();
        renderPlayers();
        synchronizeStatisticsAccessState();
        window.dispatchEvent(new CustomEvent("statistics-access-updated"));
      },
      () => {
        status.textContent = "Nie udało się pobrać listy graczy.";
      }
    );

  const gamesCollectionName = getGamesCollectionName();
  db.collection(gamesCollectionName).orderBy("createdAt", "asc").onSnapshot((snapshot) => {
    const years = normalizeYearList(
      snapshot.docs
        .map((doc) => extractYearFromDate(doc.data()?.gameDate))
        .filter((year) => Number.isInteger(year))
    );
    availableStatisticsYears = years;
    if (yearsModal?.classList.contains("is-visible")) {
      renderStatsYearsPermissions();
    }
  });

  if (yearsModalCloseButton) {
    yearsModalCloseButton.addEventListener("click", closeYearsModal);
  }

  yearsModal?.addEventListener("click", (event) => {
    if (event.target === yearsModal) {
      closeYearsModal();
    }
  });
};

const initAdminMessaging = () => {
  const input = document.querySelector("#adminMessageInput");
  const sendButton = document.querySelector("#adminMessageSend");
  const status = document.querySelector("#adminMessageStatus");

  if (!input || !sendButton || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();

  if (!firebaseApp) {
    sendButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby wysyłać wiadomości.";
    return;
  }

  const db = firebaseApp.firestore();

  const refreshNewsData = async () => {
    await db.collection(ADMIN_MESSAGES_COLLECTION).doc(ADMIN_MESSAGES_DOCUMENT).get({ source: "server" });
  };

  registerAdminRefreshHandler("adminNewsTab", refreshNewsData);

  sendButton.addEventListener("click", async () => {
    const message = input.value.trim();

    if (!message) {
      status.textContent = "Wpisz treść wiadomości przed wysłaniem.";
      return;
    }

    sendButton.disabled = true;
    status.textContent = "Wysyłanie wiadomości...";

    try {
      await db.collection(ADMIN_MESSAGES_COLLECTION).doc(ADMIN_MESSAGES_DOCUMENT).set({
        message,
        createdAt: firebaseApp.firestore.FieldValue.serverTimestamp(),
        source: "web-admin"
      });
      input.value = "";
      status.textContent = "Wiadomość wysłana do graczy.";
    } catch (error) {
      status.textContent = "Nie udało się wysłać wiadomości. Sprawdź konfigurację.";
    } finally {
      sendButton.disabled = false;
    }
  });
};

const initAdminChat = () => {
  const list = document.querySelector("#adminChatList");
  const cleanupButton = document.querySelector("#adminChatCleanup");
  const status = document.querySelector("#adminChatStatus");

  if (!list || !cleanupButton || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    cleanupButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby moderować czat.";
    return;
  }

  const db = firebaseApp.firestore();

  const renderAdminMessages = (documents) => {
    const sortedDocuments = sortChatDocumentsByCreatedAtAsc(documents);
    list.innerHTML = "";
    if (!sortedDocuments.length) {
      const empty = document.createElement("p");
      empty.className = "chat-empty";
      empty.textContent = "Brak wiadomości czatu do moderacji.";
      list.appendChild(empty);
      return;
    }

    sortedDocuments.forEach((doc) => {
      const data = doc.data();
      const row = document.createElement("article");
      row.className = "admin-chat-item";

      const meta = document.createElement("div");
      meta.className = "admin-chat-meta";
      meta.textContent = `${typeof data.authorName === "string" ? data.authorName : "Gracz"} • ${formatChatTimestamp(data.createdAt)}`;

      const text = document.createElement("p");
      text.className = "admin-chat-text";
      text.textContent = typeof data.text === "string" ? data.text : "";

      const actions = document.createElement("div");
      actions.className = "admin-chat-item-actions";

      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-chat-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.addEventListener("click", async () => {
        deleteButton.disabled = true;
        status.textContent = "Usuwanie wiadomości...";
        try {
          await db.collection(CHAT_COLLECTION).doc(doc.id).delete();
          status.textContent = "Wiadomość usunięta.";
        } catch (error) {
          deleteButton.disabled = false;
          status.textContent = "Nie udało się usunąć wiadomości.";
        }
      });

      actions.appendChild(deleteButton);
      row.appendChild(meta);
      row.appendChild(text);
      row.appendChild(actions);
      list.appendChild(row);
    });

    scrollContainerToBottom(list);
  };

  const refreshChatData = async () => {
    await db.collection(CHAT_COLLECTION).orderBy("createdAt", "asc").limit(200).get({ source: "server" });
  };

  registerAdminRefreshHandler("adminChatTab", refreshChatData);

  if (typeof chatState.adminUnsubscribe === "function") {
    chatState.adminUnsubscribe();
  }

  chatState.adminUnsubscribe = db.collection(CHAT_COLLECTION)
    .orderBy("createdAt", "asc")
    .limit(200)
    .onSnapshot(
      (snapshot) => {
        renderAdminMessages(snapshot.docs);
      },
      () => {
        status.textContent = "Nie udało się pobrać wiadomości czatu.";
      }
    );

  cleanupButton.addEventListener("click", async () => {
    cleanupButton.disabled = true;
    status.textContent = "Czyszczenie wiadomości starszych niż 30 dni...";

    let deletedCount = 0;
    try {
      const now = firebaseApp.firestore.Timestamp.now();
      while (true) {
        const expiredSnapshot = await db.collection(CHAT_COLLECTION)
          .where("expireAt", "<=", now)
          .limit(200)
          .get();

        if (expiredSnapshot.empty) {
          break;
        }

        const batch = db.batch();
        expiredSnapshot.docs.forEach((doc) => {
          batch.delete(doc.ref);
        });
        await batch.commit();
        deletedCount += expiredSnapshot.size;
      }
      status.textContent = `Usunięto ${deletedCount} wiadomości starszych niż 30 dni.`;
    } catch (error) {
      status.textContent = "Nie udało się wyczyścić starych wiadomości.";
    } finally {
      cleanupButton.disabled = false;
    }
  });
};

const initStatisticsView = ({
  yearsListSelector,
  statsBodySelector,
  playersStatsBodySelector,
  rankingBodySelector,
  statusSelector,
  exportButtonSelector,
  selectedYearStorageKey,
  isAdminView,
  yearButtonsClassName,
  weightButtonsSelector
}) => {
  const yearsList = document.querySelector(yearsListSelector);
  const statsBody = document.querySelector(statsBodySelector);
  const playersStatsBody = document.querySelector(playersStatsBodySelector);
  const rankingBody = rankingBodySelector ? document.querySelector(rankingBodySelector) : null;
  const status = document.querySelector(statusSelector);
  const exportButton = document.querySelector(exportButtonSelector);
  const firebaseApp = getFirebaseApp();

  if (!yearsList || !statsBody || !playersStatsBody || !status || !exportButton) {
    return;
  }

  if (!firebaseApp) {
    status.textContent = "Uzupełnij konfigurację Firebase, aby wyświetlać statystyki.";
    exportButton.disabled = true;
    return;
  }

  const db = firebaseApp.firestore();
  const gamesCollectionName = getGamesCollectionName();
  const gameDetailsCollectionName = getGameDetailsCollectionName();
  const manualStatsFields = ["weight1", "weight2", "weight3", "weight4", "weight5", "weight6"];
  const state = {
    years: [],
    selectedYear: loadSavedSelectedGamesYear(selectedYearStorageKey),
    games: [],
    detailsByGame: new Map(),
    detailUnsubscribers: new Map(),
    manualStatsByYear: new Map(),
    visibleColumnsByYear: new Map()
  };
  const playersStatsHeaderCells = playersStatsBody.closest("table")?.querySelectorAll("thead th") ?? [];
  const adminColumnVisibilityCheckboxes = new Map();

  const getDefaultManualFieldValue = (field, value) => getDefaultStatsManualFieldValue(field, value);
  const getStatsKey = (entry = {}) => {
    const playerId = typeof entry?.playerId === "string" ? entry.playerId.trim() : "";
    if (playerId) {
      return `id:${playerId}`;
    }
    const playerName = normalizePlayerName(entry?.playerName);
    return playerName ? `name:${playerName}` : "";
  };

  const getVisibleColumnsForYear = (year) => {
    const yearKey = String(year ?? "");
    const stored = state.visibleColumnsByYear.get(yearKey);
    if (!Array.isArray(stored)) {
      return DEFAULT_VISIBLE_STATS_COLUMNS;
    }
    const available = new Set(STATS_COLUMN_CONFIG.map((column) => column.key));
    return stored.filter((key) => available.has(key));
  };

  const persistYearConfig = (year) => {
    if (!Number.isInteger(year)) {
      return Promise.resolve();
    }

    const yearKey = String(year);
    const rows = Array.from((state.manualStatsByYear.get(yearKey) ?? new Map()).values());
    const serializedRows = rows
      .map((entry) => ({
        playerId: entry.playerId ?? "",
        playerName: entry.playerName,
        weight1: getDefaultManualFieldValue("weight1", entry.weight1),
        weight2: getDefaultManualFieldValue("weight2", entry.weight2),
        points: entry.points ?? "",
        weight3: getDefaultManualFieldValue("weight3", entry.weight3),
        weight4: getDefaultManualFieldValue("weight4", entry.weight4),
        weight5: getDefaultManualFieldValue("weight5", entry.weight5),
        weight6: getDefaultManualFieldValue("weight6", entry.weight6)
      }))
      .sort((a, b) => a.playerName.localeCompare(b.playerName, "pl"));

    return db.collection(ADMIN_GAMES_STATS_COLLECTION).doc(yearKey).set({
      rows: serializedRows,
      visibleColumns: getVisibleColumnsForYear(year)
    }, { merge: true });
  };

  const getGamesForSelectedYear = () => {
    if (!state.selectedYear) {
      return [];
    }

    return state.games
      .filter((game) => extractYearFromDate(game.gameDate) === state.selectedYear)
      .sort(compareByGameDateAsc);
  };

  const getDetailRows = (gameId) => {
    const rows = state.detailsByGame.get(gameId) ?? [];
    return rows.map((row) => {
      const entryFee = parseIntegerOrZero(row.entryFee);
      const rebuy = parseIntegerOrZero(row.rebuy);
      const payout = parseIntegerOrZero(row.payout);
      const normalizedEntryFee = sanitizeIntegerInput(typeof row.entryFee === "number" ? `${row.entryFee}` : row.entryFee ?? "");
      return {
        ...row,
        entryFee,
        rebuy,
        payout,
        profit: payout - (entryFee + rebuy),
        hasCompletedEntryFee: Boolean(normalizedEntryFee) && normalizedEntryFee !== "-",
        championship: Boolean(row.championship)
      };
    });
  };

  const hasIncludedSummaryOrStatsData = (row) => {
    const normalizedEntryFee = sanitizeIntegerInput(typeof row.entryFee === "number" ? `${row.entryFee}` : row.entryFee ?? "");
    const normalizedPoints = sanitizeIntegerInput(typeof row.points === "number" ? `${row.points}` : row.points ?? "");
    const hasEntryFee = Boolean(normalizedEntryFee) && normalizedEntryFee !== "-" && parseIntegerOrZero(normalizedEntryFee) > 0;
    const hasPoints = Boolean(normalizedPoints) && normalizedPoints !== "-";
    return hasEntryFee || hasPoints;
  };

  const getPlayersStatistics = () => {
    const games = getGamesForSelectedYear();
    const gameCount = games.length;
    const totalPool = games.reduce((sum, game) => sum + getDetailRows(game.id)
      .filter((row) => hasIncludedSummaryOrStatsData(row))
      .reduce((acc, row) => acc + row.entryFee + row.rebuy, 0), 0);
    const playersMap = new Map();

    games.forEach((game) => {
      const rows = getDetailRows(game.id);
      const gamePool = rows
        .filter((row) => hasIncludedSummaryOrStatsData(row))
        .reduce((acc, row) => acc + row.entryFee + row.rebuy, 0);
      const counted = new Set();

      rows.forEach((row) => {
        const playerName = normalizePlayerName(row.playerName);
        const playerId = typeof row.playerId === "string" ? row.playerId.trim() : "";
        const statsKey = getStatsKey({ playerId, playerName });
        if (!statsKey || !hasIncludedSummaryOrStatsData(row)) {
          return;
        }

        const hasCompletedEntryFee = row.hasCompletedEntryFee === true;

        if (!playersMap.has(statsKey)) {
          playersMap.set(statsKey, {
            statsKey,
            playerId,
            playerName,
            championshipCount: 0,
            meetingsCount: 0,
            pointsSum: 0,
            plusMinusSum: 0,
            payoutSum: 0,
            depositsSum: 0,
            playedGamesPoolSum: 0
          });
        }

        const item = playersMap.get(statsKey);
        if (hasCompletedEntryFee) {
          item.meetingsCount += 1;
        }
        item.championshipCount += row.championship ? 1 : 0;
        item.pointsSum += parseIntegerOrZero(row.points);
        item.plusMinusSum += row.profit;
        item.payoutSum += row.payout;
        item.depositsSum += row.entryFee + row.rebuy;

        if (hasCompletedEntryFee && !counted.has(statsKey)) {
          item.playedGamesPoolSum += gamePool;
          counted.add(statsKey);
        }
      });
    });

    return {
      gameCount,
      totalPool,
      playerRows: Array.from(playersMap.values())
        .map((row) => ({
          ...row,
          participationPercent: gameCount === 0 ? 0 : Math.ceil((row.meetingsCount / gameCount) * 100),
          percentAllGames: row.playedGamesPoolSum === 0 ? 0 : Math.ceil((row.payoutSum / row.playedGamesPoolSum) * 100),
          percentPlayedGames: totalPool === 0 ? 0 : Math.ceil((row.payoutSum / totalPool) * 100)
        }))
        .sort(comparePlayerStatsByPlusMinusDesc)
    };
  };

  const getComputedResultValue = (row, manualEntry = {}) => getComputedStatsResultValue(row, manualEntry, getDefaultManualFieldValue);

  const getCurrentVisibleYears = () => {
    const availableYears = normalizeYearList(
      state.games
        .map((game) => extractYearFromDate(game.gameDate))
        .filter((year) => Number.isInteger(year))
    );

    if (isAdminView) {
      return availableYears;
    }

    const verifiedPlayer = getStatisticsVerifiedPlayer();
    return getAllowedStatisticsYearsForPlayer(verifiedPlayer, availableYears);
  };

  const renderYears = () => {
    yearsList.innerHTML = "";
    if (!state.years.length) {
      const info = document.createElement("p");
      info.className = "status-text";
      if (isAdminView) {
        info.textContent = "Brak lat. Dodaj pierwszą grę, aby rok pojawił się automatycznie.";
      } else {
        const verifiedPlayer = getStatisticsVerifiedPlayer();
        const baseYears = normalizeYearList(
          state.games
            .map((game) => extractYearFromDate(game.gameDate))
            .filter((year) => Number.isInteger(year))
        );
        const hasAssignedYears = normalizeStatsYearsAccess(verifiedPlayer?.statsYearsAccess).length > 0;
        info.textContent = baseYears.length && !hasAssignedYears
          ? "Brak przypisanych lat do podglądu statystyk."
          : "Brak dostępnych lat statystyk dla Twojego konta.";
      }
      yearsList.appendChild(info);
      return;
    }

    state.years.forEach((year) => {
      const button = document.createElement("button");
      button.type = "button";
      button.className = `${yearButtonsClassName} ${state.selectedYear === year ? "is-active" : ""}`.trim();
      button.textContent = String(year);
      button.addEventListener("click", () => {
        state.selectedYear = year;
        saveSelectedGamesYear(year, selectedYearStorageKey);
        renderYears();
        renderStats();
      });
      yearsList.appendChild(button);
    });
  };

  const renderStats = () => {
    statsBody.innerHTML = "";
    playersStatsBody.innerHTML = "";
    renderRankingTable(rankingBody, []);

    if (!state.selectedYear) {
      if (!isAdminView) {
        const verifiedPlayer = getStatisticsVerifiedPlayer();
        const hasAssignedYears = normalizeStatsYearsAccess(verifiedPlayer?.statsYearsAccess).length > 0;
        status.textContent = hasAssignedYears
          ? "Brak dostępnych lat statystyk dla Twojego konta."
          : "Brak przypisanych lat do podglądu statystyk.";
      } else {
        status.textContent = "Wybierz rok z panelu po lewej stronie.";
      }
      return;
    }

    const statistics = getPlayersStatistics();
    const visibleColumns = isAdminView ? STATS_COLUMN_CONFIG.map((entry) => entry.key) : getVisibleColumnsForYear(state.selectedYear);

    if (isAdminView) {
      const visibleInSelectedYear = getVisibleColumnsForYear(state.selectedYear);
      STATS_COLUMN_CONFIG.forEach((column) => {
        const checkbox = adminColumnVisibilityCheckboxes.get(column.key);
        if (checkbox) {
          checkbox.checked = visibleInSelectedYear.includes(column.key);
        }
      });
    }

    if (!isAdminView) {
      playersStatsHeaderCells.forEach((cell, index) => {
        const column = STATS_COLUMN_CONFIG[index];
        if (!column) {
          return;
        }
        cell.style.display = visibleColumns.includes(column.key) ? "" : "none";
      });
    }

    status.textContent = `Wybrany rok: ${state.selectedYear}. Liczba gier: ${statistics.gameCount}.`;
    [["Liczba gier", statistics.gameCount], ["Łączna pula", statistics.totalPool]].forEach(([label, value]) => {
      const tr = document.createElement("tr");
      const labelCell = document.createElement("td");
      labelCell.textContent = String(label);
      const valueCell = document.createElement("td");
      valueCell.textContent = String(value);
      tr.append(labelCell, valueCell);
      statsBody.appendChild(tr);
    });

    if (!statistics.playerRows.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = visibleColumns.length || STATS_COLUMN_CONFIG.length;
      td.textContent = "Brak graczy z uzupełnionym wpisowym w wybranym roku.";
      tr.appendChild(td);
      playersStatsBody.appendChild(tr);
      renderRankingTable(rankingBody, []);
      return;
    }

    const yearKey = String(state.selectedYear);
    if (!state.manualStatsByYear.has(yearKey)) {
      state.manualStatsByYear.set(yearKey, new Map());
    }
    const yearMap = state.manualStatsByYear.get(yearKey);

    if (isAdminView) {
      const activeVisibleColumns = new Set(getVisibleColumnsForYear(state.selectedYear));
      const headerCheckboxes = playersStatsBody.closest("table")?.querySelectorAll(".stats-column-visibility-checkbox") ?? [];
      headerCheckboxes.forEach((checkbox, index) => {
        const column = STATS_COLUMN_CONFIG[index];
        if (!column) {
          return;
        }
        checkbox.checked = activeVisibleColumns.has(column.key);
      });
    }

    const rankingRows = buildRankingRowsFromStatistics(statistics.playerRows, yearMap, getDefaultManualFieldValue);

    statistics.playerRows.forEach((row) => {
      const tr = document.createElement("tr");
      const manualEntry = yearMap.get(row.statsKey) ?? {};

      STATS_COLUMN_CONFIG.forEach((column) => {
        if (!visibleColumns.includes(column.key)) {
          return;
        }

        const td = document.createElement("td");
        if (column.editable && isAdminView) {
          const input = document.createElement("input");
          input.type = "text";
          input.className = "admin-input";
          input.value = String(column.value(row, manualEntry, getDefaultManualFieldValue, getComputedResultValue));
          input.addEventListener("input", () => {
            input.value = sanitizeIntegerInput(input.value);
            if (!yearMap.has(row.statsKey)) {
              yearMap.set(row.statsKey, { playerId: row.playerId ?? "", playerName: row.playerName });
            }
            const playerEntry = yearMap.get(row.statsKey);
            manualStatsFields.forEach((field) => {
              if (playerEntry[field] == null) {
                playerEntry[field] = getDefaultManualFieldValue(field, "");
              }
            });
            playerEntry[column.key] = input.value;
            scheduleDebouncedUpdate(`stats-shared-${yearKey}-${row.statsKey}-${column.key}`, () => persistYearConfig(state.selectedYear));
            renderStats();
          });
          td.appendChild(input);
        } else {
          td.textContent = String(column.value(row, manualEntry, getDefaultManualFieldValue, getComputedResultValue));
        }
        tr.appendChild(td);
      });

      playersStatsBody.appendChild(tr);
    });

    renderRankingTable(rankingBody, rankingRows);
  };

  const synchronizeYears = () => {
    state.years = getCurrentVisibleYears();
    if (!state.selectedYear || !state.years.includes(state.selectedYear)) {
      state.selectedYear = state.years[0] ?? null;
    }
    saveSelectedGamesYear(state.selectedYear, selectedYearStorageKey);
    renderYears();
    renderStats();
  };

  db.collection(ADMIN_GAMES_STATS_COLLECTION).onSnapshot((snapshot) => {
    state.manualStatsByYear.clear();
    state.visibleColumnsByYear.clear();
    const missingVisibilityConfigYears = [];

    snapshot.forEach((doc) => {
      const yearKey = String(doc.id);
      const data = doc.data() ?? {};
      const rows = Array.isArray(data.rows) ? data.rows : [];
      const hasVisibleColumns = Array.isArray(data.visibleColumns);
      const visibleColumns = hasVisibleColumns ? data.visibleColumns : DEFAULT_VISIBLE_STATS_COLUMNS;

      if (!hasVisibleColumns) {
        missingVisibilityConfigYears.push(yearKey);
      }

      state.visibleColumnsByYear.set(yearKey, visibleColumns);
      const yearMap = new Map();
      rows.forEach((entry) => {
        const playerName = normalizePlayerName(entry?.playerName);
        const playerId = typeof entry?.playerId === "string" ? entry.playerId.trim() : "";
        const statsKey = getStatsKey({ playerId, playerName });
        if (!statsKey) {
          return;
        }
        const parsed = { playerId, playerName };
        manualStatsFields.forEach((field) => {
          parsed[field] = getDefaultManualFieldValue(field, entry[field]);
        });
        yearMap.set(statsKey, parsed);
      });
      state.manualStatsByYear.set(yearKey, yearMap);
    });

    if (missingVisibilityConfigYears.length) {
      Promise.allSettled(missingVisibilityConfigYears.map((yearKey) => db.collection(ADMIN_GAMES_STATS_COLLECTION).doc(yearKey).set({
        visibleColumns: DEFAULT_VISIBLE_STATS_COLUMNS
      }, { merge: true }))).then((results) => {
        const hasRejected = results.some((result) => result.status === "rejected");
        if (hasRejected) {
          status.textContent = "Nie udało się zapisać domyślnej konfiguracji kolumn dla części lat.";
        }
      });
    }

    renderStats();
  });

  db.collection(gamesCollectionName).orderBy("createdAt", "asc").onSnapshot((snapshot) => {
    state.games = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
    state.games.forEach((game) => {
      void clearLegacyNotesField({ firebaseApp, db, collectionName: gamesCollectionName, game });
    });
    const activeIds = new Set(state.games.map((game) => game.id));

    state.detailUnsubscribers.forEach((unsubscribe, gameId) => {
      if (!activeIds.has(gameId)) {
        unsubscribe();
        state.detailUnsubscribers.delete(gameId);
        state.detailsByGame.delete(gameId);
      }
    });

    state.games.forEach((game) => {
      if (state.detailUnsubscribers.has(game.id)) {
        return;
      }
      const unsubscribe = db.collection(gamesCollectionName).doc(game.id).collection(gameDetailsCollectionName).orderBy("createdAt", "asc").onSnapshot((rowsSnapshot) => {
        state.detailsByGame.set(game.id, rowsSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
        renderStats();
      });
      state.detailUnsubscribers.set(game.id, unsubscribe);
    });

    synchronizeYears();
  });

  if (isAdminView) {
    const headerCells = playersStatsBody.closest("table")?.querySelectorAll("thead th") ?? [];
    headerCells.forEach((cell, index) => {
      const column = STATS_COLUMN_CONFIG[index];
      if (!column) {
        return;
      }
      const checkbox = document.createElement("input");
      checkbox.type = "checkbox";
      checkbox.className = "stats-column-visibility-checkbox";
      checkbox.checked = getVisibleColumnsForYear(state.selectedYear).includes(column.key);
      adminColumnVisibilityCheckboxes.set(column.key, checkbox);
      checkbox.addEventListener("change", () => {
        if (!state.selectedYear) {
          return;
        }
        const yearKey = String(state.selectedYear);
        const visible = new Set(getVisibleColumnsForYear(state.selectedYear));
        if (checkbox.checked) {
          visible.add(column.key);
        } else {
          visible.delete(column.key);
        }
        state.visibleColumnsByYear.set(yearKey, STATS_COLUMN_CONFIG.map((entry) => entry.key).filter((key) => visible.has(key)));
        renderStats();
        void persistYearConfig(state.selectedYear).catch(() => {
          status.textContent = "Nie udało się zapisać widoczności kolumn. Spróbuj ponownie.";
        });
      });
      const wrapper = document.createElement("div");
      wrapper.className = "stats-column-header";
      while (cell.firstChild) {
        wrapper.appendChild(cell.firstChild);
      }
      wrapper.appendChild(checkbox);
      cell.appendChild(wrapper);
    });

    const weightButtons = document.querySelectorAll(weightButtonsSelector);
    weightButtons.forEach((button) => {
      button.addEventListener("click", () => {
        const weightKey = button.dataset.weightKey;
        const promptValue = window.prompt(`Podaj wartość liczbową dla kolumny ${button.textContent}.`, "1");
        if (!WEIGHT_STATS_FIELDS.includes(weightKey) || promptValue === null || !state.selectedYear) {
          return;
        }
        const normalized = sanitizeIntegerInput(promptValue);
        if (!normalized || normalized === "-") {
          status.textContent = "Podaj poprawną wartość liczbową dla wagi.";
          return;
        }
        const statistics = getPlayersStatistics();
        const yearKey = String(state.selectedYear);
        if (!state.manualStatsByYear.has(yearKey)) {
          state.manualStatsByYear.set(yearKey, new Map());
        }
        const yearMap = state.manualStatsByYear.get(yearKey);
        statistics.playerRows.forEach((row) => {
          const playerEntry = ensureYearMapEntry(yearMap, row.statsKey, row.playerName, row.playerId);
          manualStatsFields.forEach((field) => {
            if (playerEntry[field] == null) {
              playerEntry[field] = getDefaultManualFieldValue(field, "");
            }
          });
          playerEntry[weightKey] = normalized;
        });
        renderStats();
        void persistYearConfig(state.selectedYear);
      });
    });
  }


  if (!isAdminView) {
    window.addEventListener("statistics-access-updated", () => {
      synchronizeYears();
    });
  }

  exportButton.addEventListener("click", () => {
    if (!window.XLSX || !state.selectedYear) {
      status.textContent = "Eksport XLSX jest chwilowo niedostępny.";
      return;
    }

    const statistics = getPlayersStatistics();
    const yearKey = String(state.selectedYear);
    const yearMap = state.manualStatsByYear.get(yearKey) ?? new Map();
    const visibleColumns = isAdminView ? STATS_COLUMN_CONFIG.map((column) => column.key) : getVisibleColumnsForYear(state.selectedYear);
    const headers = STATS_COLUMN_CONFIG.filter((column) => visibleColumns.includes(column.key)).map((column) => column.label);
    const dataRows = statistics.playerRows.map((row) => {
      const manualEntry = yearMap.get(row.statsKey) ?? {};
      return STATS_COLUMN_CONFIG
        .filter((column) => visibleColumns.includes(column.key))
        .map((column) => column.value(row, manualEntry, getDefaultManualFieldValue, getComputedResultValue));
    });

    const worksheet = window.XLSX.utils.aoa_to_sheet([headers, ...dataRows]);
    const workbook = window.XLSX.utils.book_new();
    window.XLSX.utils.book_append_sheet(workbook, worksheet, "Statystyki");

    const now = new Date();
    const hour = `${String(now.getHours()).padStart(2, "0")}-${String(now.getMinutes()).padStart(2, "0")}-${String(now.getSeconds()).padStart(2, "0")}`;
    const date = `${now.getFullYear()}-${String(now.getMonth() + 1).padStart(2, "0")}-${String(now.getDate()).padStart(2, "0")}`;
    const fileName = `${hour}_${date}_Statystyki_${state.selectedYear}.xlsx`;
    window.XLSX.writeFile(workbook, fileName);
  });
};

const initStatisticsViews = () => {
  registerAdminRefreshHandler("adminStatisticsTab", async () => {});

  initStatisticsView({
    yearsListSelector: "#adminStatisticsYearsList",
    statsBodySelector: "#adminStatisticsStatsBody",
    playersStatsBodySelector: "#adminStatisticsPlayersStatsBody",
    rankingBodySelector: "#adminStatisticsRankingBody",
    statusSelector: "#adminStatisticsStatus",
    exportButtonSelector: "#adminStatisticsExport",
    selectedYearStorageKey: ADMIN_STATISTICS_SELECTED_YEAR_STORAGE_KEY,
    isAdminView: true,
    yearButtonsClassName: "admin-games-year-button",
    weightButtonsSelector: ".admin-statistics-weight-bulk-button"
  });

  initStatisticsView({
    yearsListSelector: "#statisticsYearsList",
    statsBodySelector: "#statisticsStatsBody",
    playersStatsBodySelector: "#statisticsPlayersStatsBody",
    rankingBodySelector: "#statisticsRankingBody",
    statusSelector: "#statisticsStatus",
    exportButtonSelector: "#statisticsExport",
    selectedYearStorageKey: USER_STATISTICS_SELECTED_YEAR_STORAGE_KEY,
    isAdminView: false,
    yearButtonsClassName: "admin-games-year-button",
    weightButtonsSelector: ""
  });
};

const initAdminGames = () => {
  const yearsList = document.querySelector("#adminGamesYearsList");
  const addGameButton = document.querySelector("#adminGamesAddGame");
  const gamesTableBody = document.querySelector("#adminGamesTableBody");
  const summariesContainer = document.querySelector("#adminGamesSummaries");
  const statsBody = document.querySelector("#adminGamesStatsBody");
  const playersStatsBody = document.querySelector("#adminGamesPlayersStatsBody");
  const rankingBody = document.querySelector("#adminGamesRankingBody");
  const status = document.querySelector("#adminGamesStatus");
  const modal = document.querySelector("#gameDetailsModal");
  const modalMeta = document.querySelector("#gameDetailsMeta");
  const modalBody = document.querySelector("#gameDetailsBody");
  const modalClose = document.querySelector("#gameDetailsClose");
  const modalAddRowButton = document.querySelector("#gameDetailsAddRow");
  const modalEntryFeeBulkButton = document.querySelector("#gameDetailsModal .game-entry-fee-bulk-button");

  if (!yearsList || !gamesTableBody || !summariesContainer || !statsBody || !playersStatsBody || !rankingBody || !status || !addGameButton) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    status.textContent = "Uzupełnij konfigurację Firebase, aby zarządzać grami.";
    addGameButton.disabled = true;
    return;
  }

  const db = firebaseApp.firestore();
  const gamesCollectionName = getGamesCollectionName();
  const gameDetailsCollectionName = getGameDetailsCollectionName();
  const manualStatsFields = ["weight1", "weight2", "weight3", "weight4", "weight5", "weight6"];
  const adminGamesPlayersStatsTable = playersStatsBody.closest("table");
  const weightHeaderButtons = Array.from(adminGamesPlayersStatsTable?.querySelectorAll(".admin-weight-bulk-button") ?? []);

  const state = {
    years: [],
    selectedYear: loadSavedSelectedGamesYear(),
    games: [],
    detailsByGame: new Map(),
    detailsUnsubscribers: new Map(),
    confirmationsByGame: new Map(),
    confirmationUnsubscribers: new Map(),
    activeGameIdInModal: null,
    playerOptions: [],
    manualStatsByYear: new Map()
  };

  const summaryNotesModal = getSummaryNotesModalController();
  const confirmationsStatusModal = getConfirmationsStatusModalController();

  const openConfirmationsStatusModal = (gameId) => {
    const game = state.games.find((entry) => entry.id === gameId);
    if (!game) {
      return;
    }
    const rows = state.detailsByGame.get(gameId) ?? [];
    const confirmations = state.confirmationsByGame.get(gameId) ?? [];
    confirmationsStatusModal.open({
      contextId: `${gamesCollectionName}:${gameId}`,
      title: `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`,
      rows,
      confirmations
    });
  };

  const detailRebuyModal = document.createElement("div");
  detailRebuyModal.className = "modal-overlay";
  detailRebuyModal.setAttribute("aria-hidden", "true");
  detailRebuyModal.innerHTML = `
    <div class="modal-card modal-card-sm" role="dialog" aria-modal="true" aria-labelledby="gameDetailsAdminRebuyTitle">
      <div class="modal-card-header modal-header-close-right">
        <h3 id="gameDetailsAdminRebuyTitle">Rebuy gracza</h3>
        <button type="button" class="icon-button" data-game-rebuy-close aria-label="Zamknij okno">×</button>
      </div>
      <div class="admin-table-scroll">
        <table class="admin-data-table game-details-rebuy-table" data-game-rebuy-table></table>
      </div>
      <div class="admin-table-actions" data-game-rebuy-actions></div>
    </div>
  `;
  document.body.appendChild(detailRebuyModal);
  const detailRebuyModalTable = detailRebuyModal.querySelector("[data-game-rebuy-table]");
  const detailRebuyModalActions = detailRebuyModal.querySelector("[data-game-rebuy-actions]");
  const detailRebuyModalClose = detailRebuyModal.querySelector("[data-game-rebuy-close]");
  let activeRebuyDetail = null;

  const closeDetailRebuyModal = () => {
    activeRebuyDetail = null;
    detailRebuyModal.classList.remove("is-visible");
    detailRebuyModal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const getDetailRowRebuyState = (row) => {
    const legacyRebuy = sanitizeIntegerInput(row.rebuy ?? "");
    const values = Array.isArray(row.rebuys) && row.rebuys.length > 0
      ? row.rebuys.map((value) => sanitizeIntegerInput(value))
      : (legacyRebuy ? [legacyRebuy] : []);
    const indexes = Array.isArray(row.rebuyIndexes) && row.rebuyIndexes.length === values.length
      ? row.rebuyIndexes
        .map((value) => Number.parseInt(String(value), 10))
        .map((value, index) => (Number.isFinite(value) && value > 0 ? value : index + 1))
      : values.map((_, index) => index + 1);
    const maxIndex = indexes.reduce((maxValue, value) => Math.max(maxValue, value), 0);
    const nextIndex = maxIndex + 1;

    return { values, indexes, nextIndex };
  };

  const getDetailRowRebuySum = (row) => getDetailRowRebuyState(row).values.reduce((sum, value) => sum + parseIntegerOrZero(value), 0);

  const persistDetailRowRebuyValues = async (gameId, rowId, rebuyState) => {
    const sanitizedValues = rebuyState.values.map((value) => sanitizeIntegerInput(value));
    const sanitizedIndexes = rebuyState.indexes
      .map((value) => Number.parseInt(String(value), 10))
      .filter((value) => Number.isFinite(value) && value > 0);
    const maxIndex = sanitizedIndexes.reduce((maxValue, value) => Math.max(maxValue, value), 0);
    const nextIndex = maxIndex + 1;
    const rebuySum = sanitizedValues.reduce((sum, value) => sum + parseIntegerOrZero(value), 0);
    await db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(rowId).update({
      rebuys: sanitizedValues,
      rebuyIndexes: sanitizedIndexes,
      rebuyNextIndex: nextIndex,
      rebuy: sanitizedValues.length ? String(rebuySum) : ""
    });
  };

  const renderDetailRebuyModal = () => {
    if (!activeRebuyDetail || !detailRebuyModalTable || !detailRebuyModalActions) {
      return;
    }
    const row = (state.detailsByGame.get(activeRebuyDetail.gameId) ?? []).find((entry) => entry.id === activeRebuyDetail.rowId);
    if (!row) {
      closeDetailRebuyModal();
      return;
    }
    const rowRebuyState = getDetailRowRebuyState(row);
    let headerHtml = "<thead><tr>";
    rowRebuyState.indexes.forEach((columnIndex) => {
      headerHtml += `<th>Rebuy${columnIndex}</th>`;
    });
    headerHtml += "</tr></thead>";
    detailRebuyModalTable.innerHTML = headerHtml;

    const tbody = document.createElement("tbody");
    const tr = document.createElement("tr");
    rowRebuyState.values.forEach((value, index) => {
      const td = document.createElement("td");
      const input = document.createElement("input");
      applyIntegerInputHints(input);
      input.className = "admin-input";
      input.value = value;
      input.addEventListener("input", () => {
        rowRebuyState.values[index] = sanitizeIntegerInput(input.value);
        input.value = rowRebuyState.values[index];
        scheduleDebouncedUpdate(`admin-detail-rebuy-${activeRebuyDetail.gameId}-${row.id}`, () => (
          persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState)
        ));
      });
      td.appendChild(input);
      tr.appendChild(td);
    });
    tbody.appendChild(tr);
    detailRebuyModalTable.appendChild(tbody);

    detailRebuyModalActions.innerHTML = "";
    const addButton = document.createElement("button");
    addButton.type = "button";
    addButton.className = "secondary";
    addButton.textContent = "Dodaj Rebuy";
    addButton.addEventListener("click", async () => {
      rowRebuyState.values.push("");
      rowRebuyState.indexes.push(rowRebuyState.nextIndex);
      rowRebuyState.nextIndex += 1;
      await persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState);
      renderDetailRebuyModal();
    });

    const removeButton = document.createElement("button");
    removeButton.type = "button";
    removeButton.className = "danger";
    removeButton.textContent = "Usuń Rebuy";
    removeButton.disabled = rowRebuyState.values.length === 0;
    removeButton.addEventListener("click", async () => {
      if (rowRebuyState.values.length === 0) {
        return;
      }
      rowRebuyState.values = rowRebuyState.values.slice(0, -1);
      rowRebuyState.indexes = rowRebuyState.indexes.slice(0, -1);
      await persistDetailRowRebuyValues(activeRebuyDetail.gameId, row.id, rowRebuyState);
      renderDetailRebuyModal();
    });

    detailRebuyModalActions.append(addButton, removeButton);
  };

  const openDetailRebuyModal = (gameId, rowId) => {
    activeRebuyDetail = { gameId, rowId };
    detailRebuyModal.classList.add("is-visible");
    detailRebuyModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    renderDetailRebuyModal();
  };

  const closeModal = () => {
    if (!modal) {
      return;
    }
    closeDetailRebuyModal();
    state.activeGameIdInModal = null;
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const getGamesForSelectedYear = () => {
    if (!state.selectedYear) {
      return [];
    }
    return state.games
      .filter((game) => extractYearFromDate(game.gameDate) === state.selectedYear)
      .sort(compareByGameDateAsc);
  };

  const syncYearsAfterLocalGameUpdate = (gameId, nextValues) => {
    const targetGame = state.games.find((game) => game.id === gameId);
    if (!targetGame) {
      return;
    }
    Object.assign(targetGame, nextValues);
    synchronizeYearsFromGames();
  };

  const getDetailRows = (gameId) => {
    const rows = state.detailsByGame.get(gameId) ?? [];
    return rows.map((row) => {
      const entryFee = parseIntegerOrZero(row.entryFee);
      const rebuy = parseIntegerOrZero(row.rebuy);
      const payout = parseIntegerOrZero(row.payout);
      const profit = payout - (entryFee + rebuy);
      const normalizedEntryFee = sanitizeIntegerInput(typeof row.entryFee === "number" ? `${row.entryFee}` : row.entryFee ?? "");
      return {
        ...row,
        entryFee,
        rebuy,
        payout,
        profit,
        hasCompletedEntryFee: Boolean(normalizedEntryFee) && normalizedEntryFee !== "-",
        points: parseIntegerOrZero(row.points),
        championship: Boolean(row.championship)
      };
    });
  };

  const hasIncludedSummaryOrStatsData = (row) => {
    const normalizedEntryFee = sanitizeIntegerInput(typeof row.entryFee === "number" ? `${row.entryFee}` : row.entryFee ?? "");
    const normalizedPoints = sanitizeIntegerInput(typeof row.points === "number" ? `${row.points}` : row.points ?? "");
    const hasEntryFee = Boolean(normalizedEntryFee) && normalizedEntryFee !== "-" && parseIntegerOrZero(normalizedEntryFee) > 0;
    const hasPoints = Boolean(normalizedPoints) && normalizedPoints !== "-";
    return hasEntryFee || hasPoints;
  };

  const getGameSummaryMetrics = (gameId) => {
    const rows = getDetailRows(gameId).filter((row) => hasIncludedSummaryOrStatsData(row));
    const pool = rows.reduce((sum, row) => sum + row.entryFee + row.rebuy, 0);
    const payoutSum = rows.reduce((sum, row) => sum + row.payout, 0);
    const sortedRows = [...rows].sort((a, b) => b.profit - a.profit);

    return {
      pool,
      payoutSum,
      hasPayoutMismatch: payoutSum !== pool,
      rows: sortedRows.map((row) => ({
        ...row,
        poolSharePercent: pool === 0 ? 0 : Math.round((row.payout / pool) * 100)
      }))
    };
  };

  const getManualStatsForYear = (year) => {
    const yearKey = String(year ?? "");
    return state.manualStatsByYear.get(yearKey) ?? new Map();
  };

  const getDefaultManualFieldValue = (field, value) => getDefaultStatsManualFieldValue(field, value);

  const serializeManualStats = (year) => {
    const yearStats = getManualStatsForYear(year);
    return Array.from(yearStats.values())
      .map((entry) => ({
        playerId: entry.playerId ?? "",
        playerName: entry.playerName,
        weight1: getDefaultManualFieldValue("weight1", entry.weight1),
        weight2: getDefaultManualFieldValue("weight2", entry.weight2),
        points: entry.points ?? "",
        weight3: getDefaultManualFieldValue("weight3", entry.weight3),
        weight4: getDefaultManualFieldValue("weight4", entry.weight4),
        weight5: getDefaultManualFieldValue("weight5", entry.weight5),
        weight6: getDefaultManualFieldValue("weight6", entry.weight6)
      }))
      .sort((a, b) => a.playerName.localeCompare(b.playerName, "pl"));
  };

  const ensureYearMapEntry = (yearMap, playerKey, playerName, playerId = "") => {
    if (!yearMap.has(playerKey)) {
      const emptyRow = { playerId, playerName };
      manualStatsFields.forEach((field) => {
        emptyRow[field] = getDefaultManualFieldValue(field, "");
      });
      yearMap.set(playerKey, emptyRow);
    }
    return yearMap.get(playerKey);
  };

  const applyBulkWeightValue = async (weightKey, nextValue) => {
    if (!state.selectedYear) {
      status.textContent = "Wybierz rok, aby ustawić wagę.";
      return;
    }

    const statistics = getPlayersStatistics();
    if (!statistics.playerRows.length) {
      status.textContent = "Brak graczy w wybranym roku do aktualizacji wag.";
      return;
    }

    const yearKey = String(state.selectedYear);
    if (!state.manualStatsByYear.has(yearKey)) {
      state.manualStatsByYear.set(yearKey, new Map());
    }
    const yearMap = state.manualStatsByYear.get(yearKey);
    statistics.playerRows.forEach((row) => {
      const playerEntry = ensureYearMapEntry(yearMap, row.statsKey, row.playerName, row.playerId);
      playerEntry[weightKey] = nextValue;
    });

    renderStatsTable();
    await persistManualStats(state.selectedYear);
    status.textContent = `Zaktualizowano ${weightKey.toUpperCase()} dla ${statistics.playerRows.length} graczy.`;
  };

  const persistManualStats = (year) => {
    if (!year) {
      return Promise.resolve();
    }
    return db.collection(ADMIN_GAMES_STATS_COLLECTION).doc(String(year)).set({ rows: serializeManualStats(year) }, { merge: true });
  };

  const getPlayersStatistics = () => {
    const games = getGamesForSelectedYear();
    const gameCount = games.length;
    const totalPool = games.reduce((sum, game) => sum + getGameSummaryMetrics(game.id).pool, 0);
    const playersMap = new Map();

    games.forEach((game) => {
      const rows = getDetailRows(game.id);
      const gamePool = getGameSummaryMetrics(game.id).pool;
      const playersCountedInGame = new Set();

      rows.forEach((row) => {
        const playerName = normalizePlayerName(row.playerName);
        const playerId = typeof row.playerId === "string" ? row.playerId.trim() : "";
        const statsKey = getStatsKey({ playerId, playerName });
        if (!statsKey || !hasIncludedSummaryOrStatsData(row)) {
          return;
        }

        const hasCompletedEntryFee = row.hasCompletedEntryFee === true;

        if (!playersMap.has(statsKey)) {
          playersMap.set(statsKey, {
            statsKey,
            playerId,
            playerName,
            championshipCount: 0,
            meetingsCount: 0,
            pointsSum: 0,
            plusMinusSum: 0,
            payoutSum: 0,
            depositsSum: 0,
            playedGamesPoolSum: 0
          });
        }

        const playerStats = playersMap.get(statsKey);
        if (hasCompletedEntryFee) {
          playerStats.meetingsCount += 1;
        }
        playerStats.championshipCount += row.championship ? 1 : 0;
        playerStats.pointsSum += row.points;
        playerStats.plusMinusSum += row.profit;
        playerStats.payoutSum += row.payout;
        playerStats.depositsSum += row.entryFee + row.rebuy;

        if (hasCompletedEntryFee && !playersCountedInGame.has(statsKey)) {
          playerStats.playedGamesPoolSum += gamePool;
          playersCountedInGame.add(statsKey);
        }
      });
    });

    const playerRows = Array.from(playersMap.values())
      .map((row) => ({
        ...row,
        participationPercent: gameCount === 0 ? 0 : Math.ceil((row.meetingsCount / gameCount) * 100),
        percentAllGames: row.playedGamesPoolSum === 0 ? 0 : Math.ceil((row.payoutSum / row.playedGamesPoolSum) * 100),
        percentPlayedGames: totalPool === 0 ? 0 : Math.ceil((row.payoutSum / totalPool) * 100)
      }))
      .sort(comparePlayerStatsByPlusMinusDesc);

    return {
      gameCount,
      totalPool,
      playerRows
    };
  };

  const getComputedResultValue = (row, manualEntry = {}) => getComputedStatsResultValue(row, manualEntry, getDefaultManualFieldValue);


  const renderYears = () => {
    yearsList.innerHTML = "";

    if (!state.years.length) {
      const info = document.createElement("p");
      info.className = "status-text";
      info.textContent = "Brak lat. Dodaj pierwszą grę w tabeli, aby rok pojawił się automatycznie.";
      yearsList.appendChild(info);
      return;
    }

    state.years.forEach((year) => {
      const yearButton = document.createElement("button");
      yearButton.type = "button";
      yearButton.className = `admin-games-year-button ${state.selectedYear === year ? "is-active" : ""}`.trim();
      yearButton.textContent = String(year);
      yearButton.addEventListener("click", () => {
        state.selectedYear = year;
        saveSelectedGamesYear(state.selectedYear);
        renderYears();
        renderGamesTable();
        renderSummaries();
        renderStatsTable();
      });
      yearsList.appendChild(yearButton);
    });
  };

  const renderGamesTable = () => {
    const focusState = getFocusedAdminInputState(gamesTableBody);
    gamesTableBody.innerHTML = "";

    if (!state.selectedYear) {
      status.textContent = "Wybierz rok z listy po lewej stronie.";
      return;
    }

    const games = getGamesForSelectedYear();
    status.textContent = `Wybrany rok: ${state.selectedYear}. Liczba gier: ${games.length}.`;

    if (!games.length) {
      const emptyRow = document.createElement("tr");
      const emptyCell = document.createElement("td");
      emptyCell.colSpan = 6;
      emptyCell.textContent = "Brak gier z datą w wybranym roku.";
      emptyRow.appendChild(emptyCell);
      gamesTableBody.appendChild(emptyRow);
      return;
    }

    games.forEach((game) => {
      const row = document.createElement("tr");

      const gameTypeCell = document.createElement("td");
      const gameTypeSelect = document.createElement("select");
      gameTypeSelect.className = "admin-input";
      gameTypeSelect.dataset.focusTarget = "game-list";
      gameTypeSelect.dataset.section = "games-table";
      gameTypeSelect.dataset.tableId = game.id;
      gameTypeSelect.dataset.columnKey = "gameType";
      ["Cashout", "Turniej"].forEach((label) => {
        const option = document.createElement("option");
        option.value = label;
        option.textContent = label;
        gameTypeSelect.appendChild(option);
      });
      gameTypeSelect.value = game.gameType === "Turniej" ? "Turniej" : "Cashout";
      gameTypeSelect.addEventListener("change", () => {
        void db.collection(gamesCollectionName).doc(game.id).update({ gameType: gameTypeSelect.value });
      });
      gameTypeCell.appendChild(gameTypeSelect);

      const dateCell = document.createElement("td");
      const dateInput = document.createElement("input");
      dateInput.type = "date";
      dateInput.className = "admin-input";
      dateInput.dataset.focusTarget = "game-list";
      dateInput.dataset.section = "games-table";
      dateInput.dataset.tableId = game.id;
      dateInput.dataset.columnKey = "gameDate";
      dateInput.value = game.gameDate ?? getFormattedCurrentDate();
      dateInput.addEventListener("change", () => {
        const nextDate = dateInput.value || getFormattedCurrentDate();
        const currentName = typeof game.name === "string" ? game.name.trim() : "";
        const updatePayload = { gameDate: nextDate };
        if (!currentName || parseDefaultTableNumber(currentName)) {
          const otherGames = state.games.filter((entry) => entry.id !== game.id);
          updatePayload.name = getNextGameNameForDate(otherGames, nextDate);
        }
        syncYearsAfterLocalGameUpdate(game.id, updatePayload);
        void db.collection(gamesCollectionName).doc(game.id).update(updatePayload);
      });
      dateCell.appendChild(dateInput);

      const nameCell = document.createElement("td");
      const nameWrap = document.createElement("div");
      nameWrap.className = "admin-games-name-control";
      const nameInput = document.createElement("input");
      nameInput.type = "text";
      nameInput.className = "admin-input";
      nameInput.dataset.focusTarget = "game-list";
      nameInput.dataset.section = "games-table";
      nameInput.dataset.tableId = game.id;
      nameInput.dataset.columnKey = "name";
      nameInput.value = game.name ?? "";
      nameInput.placeholder = "Nazwa gry";
      nameInput.addEventListener("input", () => {
        const value = nameInput.value;
        scheduleDebouncedUpdate(`game-name-${game.id}`, () => {
          void db.collection(gamesCollectionName).doc(game.id).update({ name: value });
        });
      });
      const detailsButton = document.createElement("button");
      detailsButton.type = "button";
      detailsButton.className = "secondary";
      detailsButton.textContent = "Szczegóły";
      detailsButton.addEventListener("click", () => openModal(game.id));
      nameWrap.append(nameInput, detailsButton);
      nameCell.appendChild(nameWrap);

      const closedCell = document.createElement("td");
      const closedInput = document.createElement("input");
      closedInput.type = "checkbox";
      closedInput.checked = Boolean(game.isClosed);
      closedInput.addEventListener("change", () => {
        void db.collection(gamesCollectionName).doc(game.id).update({ isClosed: closedInput.checked });
      });
      closedCell.appendChild(closedInput);

      const confirmationsCell = document.createElement("td");
      const detailRows = state.detailsByGame.get(game.id) ?? [];
      const confirmations = state.confirmationsByGame.get(game.id) ?? [];
      const confirmationsWrap = document.createElement("div");
      confirmationsWrap.className = "admin-confirmations-count-control";
      const confirmationsLabel = document.createElement("span");
      confirmationsLabel.textContent = getConfirmedCountLabel(detailRows, confirmations);
      const confirmationsButton = document.createElement("button");
      confirmationsButton.type = "button";
      confirmationsButton.className = "secondary";
      confirmationsButton.textContent = "Statusy";
      confirmationsButton.addEventListener("click", () => openConfirmationsStatusModal(game.id));
      confirmationsWrap.append(confirmationsLabel, confirmationsButton);
      confirmationsCell.appendChild(confirmationsWrap);

      const deleteCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger";
      deleteButton.textContent = "Usuń";
      deleteButton.addEventListener("click", async () => {
        const gameRef = db.collection(gamesCollectionName).doc(game.id);
        const detailsSnapshot = await gameRef.collection(gameDetailsCollectionName).get();
        const confirmationsSnapshot = await gameRef.collection(GAME_CONFIRMATIONS_COLLECTION).get();
        const batch = db.batch();
        detailsSnapshot.forEach((doc) => {
          batch.delete(doc.ref);
        });
        confirmationsSnapshot.forEach((doc) => {
          batch.delete(doc.ref);
        });
        batch.delete(gameRef);
        await batch.commit();
      });
      deleteCell.appendChild(deleteButton);

      row.append(gameTypeCell, dateCell, nameCell, closedCell, confirmationsCell, deleteCell);
      gamesTableBody.appendChild(row);
    });

    restoreFocusedAdminInputState(gamesTableBody, focusState);
  };

  const renderSummaries = () => {
    const previousScrollLeftByGameId = new Map();
    summariesContainer.querySelectorAll("[data-summary-game-id]").forEach((element) => {
      previousScrollLeftByGameId.set(element.dataset.summaryGameId ?? "", element.scrollLeft);
    });
    summariesContainer.innerHTML = "";
    const games = getGamesForSelectedYear();

    games.forEach((game) => {
      const wrapper = document.createElement("section");
      wrapper.className = "admin-games-section admin-game-summary";

      const heading = document.createElement("div");
      heading.className = "admin-game-summary-heading";

      const notesButton = document.createElement("button");
      notesButton.type = "button";
      notesButton.className = "secondary";
      notesButton.textContent = "Notatki po grze";
      notesButton.addEventListener("click", () => {
        summaryNotesModal.open({
          gameId: game.id,
          gameName: game.name || "Bez nazwy",
          notes: getPostGameNotes(game),
          canWrite: true,
          onSave: async ({ notes }) => {
            await db.collection(gamesCollectionName).doc(game.id).update({
              postGameNotes: notes,
              notes: firebaseApp.firestore.FieldValue.delete()
            });
            const target = state.games.find((entry) => entry.id === game.id);
            if (target) {
              target.postGameNotes = notes;
            }
          },
          notesLabel: "Notatki po grze",
          clearButtonLabel: "Usuń",
          clearToDefault: false,
          textareaPlaceholder: "Wpisz notatki po grze...",
          triggerButton: notesButton
        });
      });

      const title = document.createElement("h3");
      title.textContent = `Podsumowanie gry ${game.name || "Bez nazwy"}`;
      heading.append(notesButton, title);

      const metrics = getGameSummaryMetrics(game.id);
      const mismatchWarning = document.createElement("p");
      mismatchWarning.className = "status-text status-text-danger";
      mismatchWarning.textContent = "Nie zgadza się suma wypłat oraz wpisowych i rebuy/add-on";

      const poolInfo = document.createElement("p");
      poolInfo.className = "status-text";
      poolInfo.textContent = `Pula: ${metrics.pool}`;

      const gameTypeInfo = document.createElement("p");
      gameTypeInfo.className = "status-text";
      gameTypeInfo.textContent = `Rodzaj gry: ${game.gameType || "-"}`;

      const tableScroll = document.createElement("div");
      tableScroll.className = "admin-table-scroll";
      tableScroll.dataset.summaryGameId = game.id;
      const table = document.createElement("table");
      table.className = "admin-data-table";
      table.innerHTML = `
        <thead>
          <tr>
            <th>Gracz</th>
            <th>Wpisowe</th>
            <th>Rebuy/Add-on</th>
            <th>Wypłata</th>
            <th>+/-</th>
            <th>% puli</th>
            <th>Punkty</th>
            <th>Mistrzostwo</th>
          </tr>
        </thead>
      `;
      const tbody = document.createElement("tbody");

      if (!metrics.rows.length) {
        const emptyRow = document.createElement("tr");
        const emptyCell = document.createElement("td");
        emptyCell.colSpan = 8;
        emptyCell.textContent = "Brak danych do podsumowania.";
        emptyRow.appendChild(emptyCell);
        tbody.appendChild(emptyRow);
      } else {
        metrics.rows.forEach((row) => {
          const tr = document.createElement("tr");
          tr.innerHTML = `
            <td>${row.playerName || ""}</td>
            <td>${row.entryFee}</td>
            <td>${row.rebuy}</td>
            <td>${row.payout}</td>
            <td>${row.profit}</td>
            <td>${row.poolSharePercent}</td>
            <td>${row.points}</td>
            <td>${row.championship ? "✓" : ""}</td>
          `;
          tbody.appendChild(tr);
        });
      }

      table.appendChild(tbody);
      tableScroll.appendChild(table);
      tableScroll.scrollLeft = previousScrollLeftByGameId.get(game.id) ?? 0;

      if (metrics.hasPayoutMismatch) {
        wrapper.append(heading, mismatchWarning, gameTypeInfo, poolInfo, tableScroll);
      } else {
        wrapper.append(heading, gameTypeInfo, poolInfo, tableScroll);
      }
      summariesContainer.appendChild(wrapper);
    });
  };

  const renderStatsTable = () => {
    statsBody.innerHTML = "";
    playersStatsBody.innerHTML = "";

    const statistics = getPlayersStatistics();
    const gameCount = statistics.gameCount;
    const totalPool = statistics.totalPool;

    const summaryRows = [
      ["Liczba gier", String(gameCount)],
      ["Łączna pula", String(totalPool)]
    ];

    summaryRows.forEach(([label, value]) => {
      const tr = document.createElement("tr");
      const labelCell = document.createElement("td");
      labelCell.textContent = label;
      const valueCell = document.createElement("td");
      valueCell.textContent = value;
      tr.append(labelCell, valueCell);
      statsBody.appendChild(tr);
    });

    const currentYearStats = getManualStatsForYear(state.selectedYear);

    const createReadOnlyCell = (value) => {
      const td = document.createElement("td");
      td.textContent = String(value);
      return td;
    };

    const updateResultsAndRanking = (statisticsRows, yearMap) => {
      const rankingRows = buildRankingRowsFromStatistics(statisticsRows, yearMap, getDefaultManualFieldValue);
      rankingRows.forEach((rankingRow) => {
        const resultCell = playersStatsBody.querySelector(`[data-result-player="${window.CSS.escape(rankingRow.statsKey)}"]`);
        if (resultCell) {
          resultCell.textContent = String(rankingRow.resultValue);
        }
      });
      renderRankingTable(rankingBody, rankingRows);
    };

    const createEditableCell = (playerRow, key) => {
      const td = document.createElement("td");
      const input = document.createElement("input");
      input.type = "text";
      input.className = "admin-input";
      input.dataset.focusTarget = "admin-games-stats";
      input.dataset.section = "games-stats";
      input.dataset.tableId = String(state.selectedYear ?? "");
      input.dataset.rowId = playerRow.statsKey;
      input.dataset.columnKey = key;
      const stored = currentYearStats.get(playerRow.statsKey);
      input.value = getDefaultManualFieldValue(key, stored?.[key]);
      input.addEventListener("input", () => {
        input.value = sanitizeIntegerInput(input.value);
        if (!state.selectedYear) {
          return;
        }
        if (!state.manualStatsByYear.has(String(state.selectedYear))) {
          state.manualStatsByYear.set(String(state.selectedYear), new Map());
        }
        const yearMap = state.manualStatsByYear.get(String(state.selectedYear));
        const playerEntry = ensureYearMapEntry(yearMap, playerRow.statsKey, playerRow.playerName, playerRow.playerId);
        playerEntry[key] = input.value;

        scheduleDebouncedUpdate(`admin-games-stats-${state.selectedYear}-${playerRow.statsKey}-${key}`, () => persistManualStats(state.selectedYear));
        updateResultsAndRanking(statistics.playerRows, yearMap);
      });
      td.appendChild(input);
      return td;
    };

    if (!statistics.playerRows.length) {
      const tr = document.createElement("tr");
      const td = document.createElement("td");
      td.colSpan = 18;
      td.textContent = "Brak graczy z uzupełnionym wpisowym w wybranym roku.";
      tr.appendChild(td);
      playersStatsBody.appendChild(tr);
      renderRankingTable(rankingBody, []);
      return;
    }

    statistics.playerRows.forEach((row) => {
      const tr = document.createElement("tr");
      const manualEntry = currentYearStats.get(row.statsKey) ?? {};
      const resultValue = getComputedResultValue(row, manualEntry);

      const resultCell = createReadOnlyCell(resultValue);
      resultCell.dataset.resultPlayer = row.statsKey;

      tr.append(
        createReadOnlyCell(row.playerName),
        createReadOnlyCell(row.championshipCount),
        createEditableCell(row, "weight1"),
        createReadOnlyCell(row.meetingsCount),
        createEditableCell(row, "weight2"),
        createReadOnlyCell(`${row.participationPercent}%`),
        createReadOnlyCell(row.pointsSum),
        createEditableCell(row, "weight3"),
        createReadOnlyCell(row.plusMinusSum),
        createEditableCell(row, "weight4"),
        createReadOnlyCell(row.payoutSum),
        createEditableCell(row, "weight5"),
        createReadOnlyCell(row.depositsSum),
        createEditableCell(row, "weight6"),
        createReadOnlyCell(row.playedGamesPoolSum),
        createReadOnlyCell(`${row.percentAllGames}%`),
        createReadOnlyCell(`${row.percentPlayedGames}%`),
        resultCell
      );
      playersStatsBody.appendChild(tr);
    });

    renderRankingTable(rankingBody, buildRankingRowsFromStatistics(statistics.playerRows, currentYearStats, getDefaultManualFieldValue));
  };

  const renderModal = (gameId) => {
    if (!modalBody || !modalMeta) {
      return;
    }
    const game = state.games.find((entry) => entry.id === gameId);
    if (!game) {
      return;
    }

    const focusState = getFocusedAdminInputState(modalBody);
    modalMeta.textContent = `Nazwa: ${game.name || "-"} | Rodzaj gry: ${game.gameType || "-"} | Data: ${game.gameDate || "-"}`;
    modalBody.innerHTML = "";

    const rows = state.detailsByGame.get(gameId) ?? [];
    const confirmations = state.confirmationsByGame.get(gameId) ?? [];
    const gamePool = rows.reduce((sum, row) => sum + parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy), 0);
    modalMeta.textContent = `${modalMeta.textContent} | Pula: ${gamePool} | Ilość graczy: ${rows.length}`;
    rows.forEach((row, index) => { 
      const tr = document.createElement("tr");

      const lpCell = document.createElement("td");
      lpCell.textContent = String(index + 1);

      const playerCell = document.createElement("td");
      const playerSelect = document.createElement("select");
      playerSelect.className = "admin-input";
      playerSelect.dataset.focusTarget = "game-details-row";
      playerSelect.dataset.section = "games-modal";
      playerSelect.dataset.tableId = gameId;
      playerSelect.dataset.rowId = row.id;
      playerSelect.dataset.columnKey = "playerId";
      const currentPlayerName = normalizePlayerName(row.playerName);
      const currentPlayerId = typeof row.playerId === "string" ? row.playerId.trim() : "";
      const currentIdentifier = currentPlayerId ? `id:${currentPlayerId}` : (currentPlayerName ? `name:${currentPlayerName}` : "");
      const options = [...state.playerOptions];
      const availableOptions = getAvailablePlayersForRow(rows, row.id, options, currentIdentifier);
      const emptyOption = document.createElement("option");
      emptyOption.value = "";
      emptyOption.textContent = "Wybierz gracza";
      playerSelect.appendChild(emptyOption);
      if (currentIdentifier && !availableOptions.some((option) => `id:${option.id}` === currentIdentifier)) {
        const legacyOption = document.createElement("option");
        legacyOption.value = currentPlayerId;
        legacyOption.textContent = `${currentPlayerName} (usunięty)`;
        legacyOption.disabled = true;
        legacyOption.selected = true;
        playerSelect.appendChild(legacyOption);
      }
      availableOptions.forEach((player) => {
        const option = document.createElement("option");
        option.value = player.id;
        option.textContent = player.name;
        playerSelect.appendChild(option);
      });
      playerSelect.value = currentPlayerId;
      playerSelect.addEventListener("change", () => {
        const selectedPlayer = options.find((option) => option.id === playerSelect.value) ?? null;
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({
          playerId: selectedPlayer?.id ?? "",
          playerName: selectedPlayer?.name ?? ""
        });
      });
      playerCell.appendChild(playerSelect);

      const createNumericCell = (key) => {
        const td = document.createElement("td");
        const input = document.createElement("input");
        applyIntegerInputHints(input);
        input.className = "admin-input";
        input.dataset.focusTarget = "game-details-row";
        input.dataset.section = "games-modal";
        input.dataset.tableId = gameId;
        input.dataset.rowId = row.id;
        input.dataset.columnKey = key;
        const rawValue = row[key] ?? "";
        input.value = rawValue;
        input.addEventListener("input", () => {
          input.value = sanitizeIntegerInput(input.value);
          scheduleDebouncedUpdate(`detail-${gameId}-${row.id}-${key}`, () => {
            void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({ [key]: input.value });
          });
        });
        td.appendChild(input);
        return td;
      };

      const entryFeeCell = createNumericCell("entryFee");
      const rebuyCell = document.createElement("td");
      const rebuyButton = document.createElement("button");
      rebuyButton.type = "button";
      rebuyButton.className = "secondary";
      rebuyButton.textContent = formatNumber(getDetailRowRebuySum(row));
      rebuyButton.addEventListener("click", () => {
        openDetailRebuyModal(gameId, row.id);
      });
      rebuyCell.appendChild(rebuyButton);
      const payoutCell = createNumericCell("payout");

      const profitCell = document.createElement("td");
      profitCell.textContent = String(parseIntegerOrZero(row.payout) - (parseIntegerOrZero(row.entryFee) + parseIntegerOrZero(row.rebuy)));

      const pointsCell = createNumericCell("points");

      const championshipCell = document.createElement("td");
      const championshipInput = document.createElement("input");
      championshipInput.type = "checkbox";
      championshipInput.dataset.focusTarget = "game-details-row";
      championshipInput.dataset.section = "games-modal";
      championshipInput.dataset.tableId = gameId;
      championshipInput.dataset.rowId = row.id;
      championshipInput.dataset.columnKey = "championship";
      championshipInput.checked = Boolean(row.championship);
      championshipInput.addEventListener("change", () => {
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).update({ championship: championshipInput.checked });
      });
      championshipCell.appendChild(championshipInput);

      const deleteCell = document.createElement("td");
      const deleteButton = document.createElement("button");
      deleteButton.type = "button";
      deleteButton.className = "danger admin-row-delete";
      deleteButton.textContent = "Usuń";
      deleteButton.addEventListener("click", () => {
        void db.collection(gamesCollectionName).doc(gameId).collection(gameDetailsCollectionName).doc(row.id).delete();
      });
      deleteCell.appendChild(deleteButton);

      tr.append(lpCell, playerCell, entryFeeCell, rebuyCell, payoutCell, profitCell, pointsCell, championshipCell, deleteCell);
      modalBody.appendChild(tr);
    });

    restoreFocusedAdminInputState(modalBody, focusState);
  };

  const openModal = (gameId) => {
    if (!modal) {
      return;
    }
    state.activeGameIdInModal = gameId;
    renderModal(gameId);
    modal.classList.add("is-visible");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };

  const synchronizeYearsFromGames = () => {
    const yearsFromGames = state.games
      .map((game) => extractYearFromDate(game.gameDate))
      .filter((year) => Number.isInteger(year));

    state.years = normalizeYearList(yearsFromGames);

    if (!state.selectedYear || !state.years.includes(state.selectedYear)) {
      state.selectedYear = state.years[0] ?? null;
    }

    saveSelectedGamesYear(state.selectedYear);
    renderYears();
    renderGamesTable();
    renderSummaries();
    renderStatsTable();
  };

  db.collection(ADMIN_GAMES_STATS_COLLECTION).onSnapshot((snapshot) => {
    state.manualStatsByYear.clear();
    snapshot.forEach((doc) => {
      const yearKey = String(doc.id);
      const rows = Array.isArray(doc.data()?.rows) ? doc.data().rows : [];
      const yearMap = new Map();
      rows.forEach((entry) => {
        const playerName = normalizePlayerName(entry?.playerName);
        const playerId = typeof entry?.playerId === "string" ? entry.playerId.trim() : "";
        const statsKey = getStatsKey({ playerId, playerName });
        if (!statsKey) {
          return;
        }
        const parsedEntry = { playerId, playerName };
        manualStatsFields.forEach((field) => {
          parsedEntry[field] = getDefaultManualFieldValue(field, entry[field]);
        });
        yearMap.set(statsKey, parsedEntry);
      });
      state.manualStatsByYear.set(yearKey, yearMap);
    });
    renderStatsTable();
  });

  weightHeaderButtons.forEach((button) => {
    button.addEventListener("click", () => {
      const weightKey = button.dataset.weightKey;
      if (!WEIGHT_STATS_FIELDS.includes(weightKey)) {
        return;
      }
      const promptValue = window.prompt(`Podaj wartość liczbową dla kolumny ${button.textContent}.`, "1");
      if (promptValue === null) {
        return;
      }
      const normalizedValue = sanitizeIntegerInput(promptValue);
      if (!normalizedValue || normalizedValue === "-") {
        status.textContent = "Podaj poprawną wartość liczbową dla wagi.";
        return;
      }
      void applyBulkWeightValue(weightKey, normalizedValue);
    });
  });

  db.collection(PLAYER_ACCESS_COLLECTION).doc(PLAYER_ACCESS_DOCUMENT).onSnapshot((snapshot) => {
    const players = Array.isArray(snapshot.data()?.players) ? snapshot.data().players : [];
    state.playerOptions = players
      .map((player, index) => ({
        id: typeof player?.id === "string" && player.id.trim() ? player.id.trim() : `player-${index + 1}`,
        name: normalizePlayerName(player?.name)
      }))
      .filter((player) => player.id && player.name);
    if (state.activeGameIdInModal) {
      renderModal(state.activeGameIdInModal);
    }
  });

  db.collection(gamesCollectionName)
    .orderBy("createdAt", "asc")
    .onSnapshot((snapshot) => {
      state.games = snapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() }));
      state.games.forEach((game) => {
        void clearLegacyNotesField({ firebaseApp, db, collectionName: gamesCollectionName, game });
      });

      const activeIds = new Set(state.games.map((game) => game.id));
      state.detailsUnsubscribers.forEach((unsubscribe, gameId) => {
        if (!activeIds.has(gameId)) {
          unsubscribe();
          state.detailsUnsubscribers.delete(gameId);
          state.detailsByGame.delete(gameId);
        }
      });
      state.confirmationUnsubscribers.forEach((unsubscribe, gameId) => {
        if (!activeIds.has(gameId)) {
          unsubscribe();
          state.confirmationUnsubscribers.delete(gameId);
          state.confirmationsByGame.delete(gameId);
        }
      });

      state.games.forEach((game) => {
        if (!state.detailsUnsubscribers.has(game.id)) {
          const unsubscribe = db.collection(gamesCollectionName).doc(game.id).collection(gameDetailsCollectionName).orderBy("createdAt", "asc").onSnapshot((rowSnapshot) => {
            state.detailsByGame.set(game.id, rowSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
            if (state.activeGameIdInModal === game.id) {
              renderModal(game.id);
            }
            if (confirmationsStatusModal.isOpenFor(`${gamesCollectionName}:${game.id}`)) {
              openConfirmationsStatusModal(game.id);
            }
            renderGamesTable();
            renderSummaries();
            renderStatsTable();
          });
          state.detailsUnsubscribers.set(game.id, unsubscribe);
        }

        if (!state.confirmationUnsubscribers.has(game.id)) {
          const confirmationUnsubscribe = db.collection(gamesCollectionName).doc(game.id).collection(GAME_CONFIRMATIONS_COLLECTION).onSnapshot((confirmationSnapshot) => {
            state.confirmationsByGame.set(game.id, confirmationSnapshot.docs.map((doc) => ({ id: doc.id, ...doc.data() })));
            if (state.activeGameIdInModal === game.id) {
              renderModal(game.id);
            }
            renderGamesTable();
          });
          state.confirmationUnsubscribers.set(game.id, confirmationUnsubscribe);
        }
      });

      synchronizeYearsFromGames();
    });

  addGameButton.addEventListener("click", async () => {
    addGameButton.disabled = true;
    status.textContent = "Dodawanie gry...";
    try {
      const newGamePayload = getValidatedNewGamePayload({
        games: state.games,
        additionalPayload: {
          isClosed: false,
          preGameNotes: DEFAULT_GAME_NOTES_TEMPLATE,
          postGameNotes: "",
          createdAt: firebaseApp.firestore.FieldValue.serverTimestamp()
        }
      });

      if (!newGamePayload) {
        status.textContent = "Nie można utworzyć gry bez pól: Rodzaj gry, Data i Nazwa.";
        return;
      }

      await db.collection(gamesCollectionName).add(newGamePayload);
      status.textContent = `Dodano grę "${newGamePayload.name}" z datą ${newGamePayload.gameDate}.`;
    } catch (error) {
      const errorCode = error?.code;
      if (errorCode === "permission-denied") {
        status.textContent =
          `Brak uprawnień do zapisu w kolekcji ${gamesCollectionName}. Sprawdź reguły Firestore i wielkość liter.`;
      } else {
        const details = formatFirestoreError(error);
        status.textContent = details
          ? `Nie udało się dodać gry. ${details}`
          : "Nie udało się dodać gry.";
      }
    } finally {
      addGameButton.disabled = false;
    }
  });

  if (modalClose) {
    modalClose.addEventListener("click", closeModal);
  }
  if (modalAddRowButton) {
    modalAddRowButton.addEventListener("click", async () => {
      if (!state.activeGameIdInModal) {
        return;
      }
      await db.collection(gamesCollectionName).doc(state.activeGameIdInModal).collection(gameDetailsCollectionName).add({
        playerName: "",
        entryFee: "",
        rebuy: "",
        payout: "0",
        points: "",
        championship: false,
        createdAt: firebaseApp.firestore.FieldValue.serverTimestamp()
      });
    });
  }

  if (modalEntryFeeBulkButton) {
    modalEntryFeeBulkButton.addEventListener("click", async () => {
      if (!state.activeGameIdInModal) {
        status.textContent = "Otwórz szczegóły gry, aby zbiorczo ustawić wpisowe.";
        return;
      }
      const promptValue = window.prompt("Podaj wartość wpisowego dla wszystkich graczy.", "0");
      if (promptValue === null) {
        return;
      }
      const normalized = sanitizeIntegerInput(promptValue);
      if (!normalized || normalized === "-") {
        status.textContent = "Podaj poprawną wartość liczbową wpisowego.";
        return;
      }
      const rows = state.detailsByGame.get(state.activeGameIdInModal) ?? [];
      await Promise.all(rows.map((row) => db.collection(gamesCollectionName)
        .doc(state.activeGameIdInModal)
        .collection(gameDetailsCollectionName)
        .doc(row.id)
        .update({ entryFee: normalized })));
      status.textContent = `Ustawiono wpisowe ${normalized} dla ${rows.length} wierszy.`;
    });
  }




  detailRebuyModalClose?.addEventListener("click", closeDetailRebuyModal);
  detailRebuyModal.addEventListener("click", (event) => {
    if (event.target === detailRebuyModal) {
      closeDetailRebuyModal();
    }
  });

  if (modal) {
    modal.addEventListener("click", (event) => {
      if (event.target === modal) {
        closeModal();
      }
    });
    document.addEventListener("keydown", (event) => {
      if (event.key === "Escape" && detailRebuyModal.classList.contains("is-visible")) {
        closeDetailRebuyModal();
        return;
      }
      if (event.key === "Escape" && modal.classList.contains("is-visible")) {
        closeModal();
      }
    });
  }

  registerAdminRefreshHandler("adminGamesTab", async () => {
    renderGamesTable();
    renderSummaries();
    renderStatsTable();
  });
  registerAdminRefreshHandler("adminUserGamesTab", async () => {
    renderGamesTable();
    renderSummaries();
  });
};

const initLatestMessage = () => {
  const output = document.querySelector("#latestMessageOutput");
  const status = document.querySelector("#latestMessageStatus");

  if (!output || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();

  if (!firebaseApp) {
    output.value = "Brak połączenia z Firebase.";
    status.textContent = "Uzupełnij konfigurację Firebase, aby zobaczyć wiadomości.";
    return;
  }

  const db = firebaseApp.firestore();

  db.collection(ADMIN_MESSAGES_COLLECTION)
    .doc(ADMIN_MESSAGES_DOCUMENT)
    .onSnapshot(
      (snapshot) => {
        if (!snapshot.exists) {
          output.value = "Brak wiadomości od administratora.";
          status.textContent = "";
          return;
        }

        const data = snapshot.data();
        const message = typeof data.message === "string" ? data.message : "";

        output.value = message || "Brak wiadomości od administratora.";
        status.textContent = "";
      },
      () => {
        output.value = "Nie udało się pobrać wiadomości.";
        status.textContent = "Sprawdź reguły Firestore i konfigurację projektu.";
      }
    );
};

const initAdminRules = () => {
  const input = document.querySelector("#adminRulesInput");
  const saveButton = document.querySelector("#adminRulesSave");
  const status = document.querySelector("#adminRulesStatus");

  if (!input || !saveButton || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();

  if (!firebaseApp) {
    input.disabled = true;
    saveButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby edytować regulamin.";
    return;
  }

  const db = firebaseApp.firestore();
  const rulesDocRef = db.collection(PLAYER_ACCESS_COLLECTION).doc(RULES_DOCUMENT);
  let isSaving = false;
  let hasLocalEdits = false;

  registerAdminRefreshHandler("adminRulesTab", async () => {
    await rulesDocRef.get({ source: "server" });
  });

  rulesDocRef.onSnapshot(
    (snapshot) => {
      const data = snapshot.data();
      const rulesText = typeof data?.text === "string" ? data.text : RULES_DEFAULT_TEXT;
      if (document.activeElement === input && hasLocalEdits && !isSaving) {
        return;
      }
      input.value = rulesText;
      status.textContent = data?.text ? "Regulamin jest aktualny." : "Brak zapisanej treści regulaminu.";
      saveButton.disabled = false;
      isSaving = false;
    },
    () => {
      status.textContent = "Nie udało się pobrać regulaminu. Sprawdź konfigurację Firestore.";
    }
  );

  input.addEventListener("input", () => {
    hasLocalEdits = true;
  });

  input.addEventListener("blur", () => {
    hasLocalEdits = false;
  });

  saveButton.addEventListener("click", () => {
    if (isSaving) {
      return;
    }

    hasLocalEdits = false;
    status.textContent = "Zapisywanie regulaminu...";
    isSaving = true;
    saveButton.disabled = true;

    void rulesDocRef.set({
      text: input.value,
      updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp(),
      source: "web-admin"
    }, { merge: true })
      .catch(() => {
        isSaving = false;
        saveButton.disabled = false;
        status.textContent = "Nie udało się zapisać regulaminu.";
      });
  });
};

const initAdminNotes = () => {
  const input = document.querySelector("#adminNotesInput");
  const saveButton = document.querySelector("#adminNotesSave");
  const status = document.querySelector("#adminNotesStatus");

  if (!input || !saveButton || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();
  if (!firebaseApp) {
    input.disabled = true;
    saveButton.disabled = true;
    status.textContent = "Uzupełnij konfigurację Firebase, aby edytować notatki.";
    return;
  }

  const db = firebaseApp.firestore();
  const notesDocRef = db.collection(ADMIN_NOTES_COLLECTION).doc(MAIN_ADMIN_NOTES_DOCUMENT);
  let isSaving = false;
  let hasLocalEdits = false;

  registerAdminRefreshHandler("adminNotesTab", async () => {
    await notesDocRef.get({ source: "server" });
  });

  notesDocRef.onSnapshot(
    (snapshot) => {
      const data = snapshot.data();
      const notesText = typeof data?.text === "string" ? data.text : "";
      if (document.activeElement === input && hasLocalEdits && !isSaving) {
        return;
      }
      input.value = notesText;
      status.textContent = notesText ? "Notatki są aktualne." : "Brak zapisanej treści notatek.";
      saveButton.disabled = false;
      isSaving = false;
    },
    () => {
      status.textContent = "Nie udało się pobrać notatek. Sprawdź konfigurację Firestore.";
    }
  );

  input.addEventListener("input", () => {
    hasLocalEdits = true;
  });

  input.addEventListener("blur", () => {
    hasLocalEdits = false;
  });

  saveButton.addEventListener("click", () => {
    if (isSaving) {
      return;
    }

    hasLocalEdits = false;
    status.textContent = "Zapisywanie notatek...";
    isSaving = true;
    saveButton.disabled = true;

    void notesDocRef.set({
      text: input.value,
      updatedAt: firebaseApp.firestore.FieldValue.serverTimestamp(),
      updatedBy: "web-admin",
      module: "main"
    }, { merge: true })
      .catch(() => {
        isSaving = false;
        saveButton.disabled = false;
        status.textContent = "Nie udało się zapisać notatek.";
      });
  });
};

const initRulesDisplay = () => {
  const output = document.querySelector("#rulesOutput");
  const status = document.querySelector("#rulesStatus");

  if (!output || !status) {
    return;
  }

  const firebaseApp = getFirebaseApp();

  if (!firebaseApp) {
    output.value = "Brak połączenia z Firebase.";
    status.textContent = "Uzupełnij konfigurację Firebase, aby zobaczyć regulamin.";
    return;
  }

  firebaseApp.firestore()
    .collection(PLAYER_ACCESS_COLLECTION)
    .doc(RULES_DOCUMENT)
    .onSnapshot(
      (snapshot) => {
        const data = snapshot.data();
        const rulesText = typeof data?.text === "string" ? data.text.trim() : "";
        output.value = rulesText || "Administrator jeszcze nie dodał regulaminu.";
        status.textContent = "";
      },
      () => {
        output.value = "Nie udało się pobrać regulaminu.";
        status.textContent = "Sprawdź reguły Firestore i konfigurację projektu.";
      }
    );
};

const initInstructionModal = () => {
  const openButton = document.querySelector("#adminInstructionButton");
  const modal = document.querySelector("#instructionModal");
  const closeButton = document.querySelector("#instructionClose");
  const content = document.querySelector("#instructionContent");
  const status = document.querySelector("#instructionStatus");

  if (!openButton || !modal || !content || !status) {
    return;
  }

  const instructionUrl = "https://cutelittlegoat.github.io/Karty/Main/docs/README.md";
  let cachedText = "";
  let isLoading = false;

  const setStatus = (message) => {
    status.textContent = message;
  };

  const loadInstruction = async () => {
    if (isLoading) {
      return;
    }

    if (cachedText) {
      return;
    }

    isLoading = true;
    setStatus("Pobieranie instrukcji...");

    try {
      const response = await fetch(instructionUrl, { cache: "default" });
      if (!response.ok) {
        throw new Error("Network response was not ok.");
      }
      cachedText = await response.text();
      content.textContent = cachedText;
      setStatus("Instrukcja została pobrana.");
    } catch (error) {
      setStatus("Nie udało się pobrać instrukcji. Zamknij i otwórz okno ponownie.");
    } finally {
      isLoading = false;
    }
  };

  const openModal = () => {
    modal.classList.add("is-visible");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    if (!cachedText) {
      void loadInstruction();
    }
  };

  const closeModal = () => {
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  openButtons.forEach((openButton) => openButton.addEventListener("click", openModal));

  if (closeButton) {
    closeButton.addEventListener("click", closeModal);
  }

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal.classList.contains("is-visible")) {
      closeModal();
    }
  });
};

const initCustomsEmergencyModal = () => {
  const openButtons = Array.from(document.querySelectorAll("#customsEmergencyButton"));
  const modal = document.querySelector("#customsEmergencyModal");
  const closeButton = document.querySelector("#customsEmergencyClose");

  if (!openButtons.length || !modal) {
    return;
  }

  const closeModal = () => {
    modal.classList.remove("is-visible");
    modal.setAttribute("aria-hidden", "true");
    document.body.classList.remove("modal-open");
  };

  const openModal = () => {
    modal.classList.add("is-visible");
    modal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
  };

  openButtons.forEach((openButton) => openButton.addEventListener("click", openModal));

  if (closeButton) {
    closeButton.addEventListener("click", closeModal);
  }

  modal.addEventListener("click", (event) => {
    if (event.target === modal) {
      closeModal();
    }
  });

  document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && modal.classList.contains("is-visible")) {
      closeModal();
    }
  });
};

const bootstrap = async () => {
  const isAdmin = await resolveAdminMode();
  document.body.classList.toggle("is-admin", isAdmin);
  initSharedPlayerAccess();
  initAdminPanelTabs();
  initAdminPanelRefresh();
  initUserTabs();
  initAdminMessaging();
  initAdminChat();
  initAdminRules();
  initAdminNotes();
  initAdminGames();
  initAdminUserGames();
  initAdminConfirmations();
  initAdminPlayers();
  initAdminCalculator();
  initPinGate();
  initNextGamesView();
  initChatTab();
  initUserConfirmations();
  initUserGamesTab();
  initStatisticsTab();
  initPlayerUserGames();
  initStatisticsViews();
  initLatestMessage();
  initRulesDisplay();
  initInstructionModal();
  initCustomsEmergencyModal();
};

void bootstrap();
